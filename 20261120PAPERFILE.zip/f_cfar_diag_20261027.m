function result=f_cfar_diag_20261027(cfg)
% Standalone CFAR-only diagnostic. Reuses original 1542 local algorithms.
if nargin<1, cfg=struct(); end
if ~isfield(cfg,'numMC'), cfg.numMC=5; end
if ~isfield(cfg,'snr'), cfg.snr=[-10 0 10 20 25 Inf]; end
if ~isfield(cfg,'spacing'), cfg.spacing=[0.5 1 3]; end
if ~isfield(cfg,'outputRoot'), cfg.outputRoot=fullfile(fileparts(mfilename('fullpath')),'Figures','cfardiag20261027'); end
validateattributes(cfg.numMC,{'numeric'},{'scalar','integer','positive'});
folder=fullfile(cfg.outputRoot,datestr(now,'yyyymmdd_HHMMSS'));
if exist(folder,'dir'), error('Output:Exists','Output folder already exists.'); end
mkdir(folder);
opts=struct('seed',1919810,'verbose',false,'doTensor',false,'mdToBody_dB',-8,...
    'M',16,'NR',96,'ND',128,'cfarMaxCandidates',inf);
opts=timed_fill_default_opts(fill_wrapper_defaults(opts));
opts.raw=struct('calibrationFrames',128,'calibrationValidationFrames',16);
fprintf('Preparing original 1542 noise-only CFAR calibration...\n');
opts=model_defaults_1542_local(raw_fill_default_opts_local(opts));
opts.periodicRule.modelWindow=opts.raw.cfarDopplerWindow;
opts.spacing=struct('baseBounds',[3 0.6 3],'centers',[-30 30 48;0 48 64;30 66 80],...
    'uavAmplitudeRange',[0.55 0.90],'objectAmplitudeRange',[1.25 2.20]);
opts.offGrid.enable=false;
jobs=struct('name',{},'spacing',{},'snr',{},'mc',{});
cases=["single_integer","single_offgrid",repmat("cluster",1,numel(cfg.spacing))]; ss=[1 1 cfg.spacing];
for ci=1:numel(cases)
 for snr=cfg.snr
  for mc=1:cfg.numMC
   jobs(end+1)=struct('name',cases(ci),'spacing',ss(ci),'snr',snr,'mc',mc); %#ok<AGROW>
  end
 end
end
for mc=1:cfg.numMC, jobs(end+1)=struct('name',"noise_only",'spacing',1,'snr',NaN,'mc',mc); end
trials=table(); targets=table(); candidates=table(); controls=table();
for ji=1:numel(jobs)
 job=jobs(ji); rng(opts.seed+job.mc-1,'twister'); trialOpts=opts; trialOpts.spacing.scale=job.spacing;
 [X,truth,scene]=diag_synthesize(job,trialOpts);
 Y=raw_process_tensor_local(X,opts,'cfar'); RV=squeeze(sum(abs(Y).^2,1));
 [ca,~]=timed_cfar_2d_candidates(RV,diag_ca_options(opts));
 [os,~]=os_candidates_from_map_local(RV,opts,opts.M,false(size(RV)));
 pools={ca,os}; methods=["CA-CFAR","OS-CFAR"];
 truthProbe=false(height(truth),1); idealProbe=truthProbe;
 for u=1:height(truth)
  rr=round(truth.RangeBin(u)); dd=round(truth.DopplerBin(u)); a=timed_steering_ula(opts.M,truth.AngleDeg(u));
  g=(a'*reshape(Y(:,rr,:),opts.M,opts.ND)).';
  truthProbe(u)=model_decision_1542_local(g,opts.periodicRule,dd);
  z=fftshift(fft(raw_window_local(opts.ND,opts.raw.cfarDopplerWindow).*scene.g(:,u)))/sqrt(opts.ND);
  [idealProbe(u),~,~,~,~,reason,dg]=model_decision_1542_local(z,opts.periodicRule,dd);
  controls=[controls;table(ji,job.name,job.spacing,job.snr,job.mc,u,truthProbe(u),idealProbe(u),string(reason),...
   dg.toneError,dg.harmonicError,dg.BICGain,dg.relativeImprovement,dg.sidebandEnergy,...
   'VariableNames',{'Job','Case','Spacing','SNR','MC','UAV','TruthLocalPass','IdealFactorPass',...
   'IdealReason','IdealE0','IdealE1','IdealB','IdealGain','IdealSideFraction'})]; %#ok<AGROW>
 end
 for mi=1:2
  timer=tic; [~,T]=timed_run_traditional_chain(Y,opts.theta_grid,opts,pools{mi}); seconds=toc(timer);
  accepted=T(logical(T.IsUAV),:);
  body=evaluate_detection_metrics_local(accepted,truth,opts.successThreshold,false);
  legacy=evaluate_detection_metrics_local(accepted,truth,opts.successThreshold,true);
  hitRD=false(height(truth),1); hit3=hitRD; pass=hitRD;
  for u=1:height(truth)
   rd=abs(T.RangeBin-truth.RangeBin(u))<1.5 & abs(T.DopplerBin-truth.DopplerBin(u))<2;
   xyz=rd & abs(T.AngleDeg-truth.AngleDeg(u))<2;
   hitRD(u)=any(rd); hit3(u)=any(xyz); pass(u)=any(xyz & T.IsUAV);
   [ratio,threshold,lmax,anyPeak]=diag_reference_test(RV,truth(u,:),opts,mi);
   targets=[targets;table(ji,job.name,job.spacing,job.snr,job.mc,methods(mi),u,...
    hitRD(u),hit3(u),pass(u),truthProbe(u),idealProbe(u),ratio,threshold,lmax,anyPeak,...
    'VariableNames',{'Job','Case','Spacing','SNR','MC','Method','UAV','BodyRDCovered',...
    'Body3DCovered','BodyAccepted','TruthLocalPass','IdealFactorPass','NearestBodyThresholdRatio',...
    'NearestBodyThreshold','NearestBodyLocalMax','AnyBodyWindowThresholdPeak'})]; %#ok<AGROW>
  end
  for c=1:height(T)
   a=timed_steering_ula(opts.M,T.AngleDeg(c)); g=(a'*reshape(Y(:,T.RangeBin(c),:),opts.M,opts.ND)).';
   [again,~,~,~,~,reason,dg]=model_decision_1542_local(g,opts.periodicRule,T.DopplerBin(c));
   assert(again==T.IsUAV(c),'Classification diagnostic mismatch.');
   candidates=[candidates;table(ji,job.name,job.spacing,job.snr,job.mc,methods(mi),c,...
    T.AngleDeg(c),T.RangeBin(c),T.DopplerBin(c),again,string(reason),...
    dg.toneError,dg.harmonicError,dg.BICGain,dg.relativeImprovement,dg.sidebandEnergy,...
    'VariableNames',{'Job','Case','Spacing','SNR','MC','Method','Candidate','AngleDeg','RangeBin',...
    'DopplerBin','IsUAV','Reason','E0','E1','BICGain','RelativeImprovement','SideFraction'})]; %#ok<AGROW>
  end
  trials=[trials;table(ji,job.name,job.spacing,job.snr,job.mc,methods(mi),height(truth),height(T),...
   height(accepted),sum(hitRD),sum(hit3),sum(pass),sum(truthProbe),sum(idealProbe),...
   body.truePositive,body.falseAlarm,legacy.truePositive,legacy.falseAlarm,seconds,...
   'VariableNames',{'Job','Case','Spacing','SNR','MC','Method','TrueUAV','Candidates','Outputs',...
   'CoveredRD','Covered3D','AcceptedCovered','TruthLocalPass','IdealFactorPass',...
   'TPBody','FPBody','TPLegacy','FPLegacy','ClassificationSeconds'})]; %#ok<AGROW>
 end
 if mod(ji,10)==0 || ji==numel(jobs)
  fprintf('CFAR diagnostic %d/%d: %s s=%.2f SNR=%g MC=%d\n',ji,numel(jobs),job.name,job.spacing,job.snr,job.mc);
  save(fullfile(folder,'checkpoint.mat'),'trials','targets','candidates','controls','cfg','opts','-v7');
 end
end
summary=diag_aggregate(trials);
tables={trials,targets,candidates,controls,summary}; names={'trials','targets','candidates','controls','summary'};
for j=1:numel(tables), writetable(tables{j},fullfile(folder,[names{j} '.csv'])); end
save(fullfile(folder,'results.mat'),'summary','trials','targets','candidates','controls','cfg','opts','-v7');
diag_plot(summary,folder); diag_readme(folder,cfg);
result=struct('folder',folder,'summary',summary); disp(summary); fprintf('\nResults: %s\n',folder);
end

function o=diag_ca_options(opts)
o=struct('guardR',2,'guardD',2,'trainR',6,'trainD',8,'Pfa',1e-4,'maxCandidates',inf,...
 'minRangeDistance',2,'minDopplerDistance',3,'thresholdScale',opts.rawCFARCalibration.caScale);
end

function [X,T,scene]=diag_synthesize(job,opts)
if job.name=="cluster"
 opts.clusterUAVCounts=[1 2 3]; scene=timed_f_make_sim_scene_local(6,3,0,opts);
elseif startsWith(job.name,"single")
 if job.name=="single_integer", r=48; d=64; else, r=48.37; d=64.31; end
 scene=struct('theta_u_list',0,'Ru_list',r,'d0_u_list',d,'fr_u_list',6,'alpha_u_list',0.75,...
  'theta_c_list',[],'Rc_list',[],'Dc_list',[],'alpha_c_list',[],...
  'uav_sideband_amps',timed_make_bessel_sideband_amps(1,0.8,3,-8));
else
 scene=struct('theta_u_list',[],'Ru_list',[],'d0_u_list',[],'fr_u_list',[],'alpha_u_list',[],...
  'theta_c_list',[],'Rc_list',[],'Dc_list',[],'alpha_c_list',[]);
end
nu=numel(scene.Ru_list); X=zeros(opts.M,opts.raw.nFast,opts.ND); scene.g=zeros(opts.ND,nu);
for u=1:nu
 bins=scene.d0_u_list(u)+[0 -1 1 -2 2 -3 3]*scene.fr_u_list(u); g=zeros(opts.ND,1);
 for h=1:7, g=g+scene.uav_sideband_amps(h)*raw_doppler_tone_local(opts.ND,bins(h)); end
 g=g/norm(g); scene.g(:,u)=g;
 X=X+timed_outer3(scene.alpha_u_list(u)*timed_steering_ula(opts.M,scene.theta_u_list(u)),...
  raw_range_tone_local(opts.raw.nFast,scene.Ru_list(u)),g);
end
for c=1:numel(scene.Rc_list)
 X=X+timed_outer3(scene.alpha_c_list(c)*timed_steering_ula(opts.M,scene.theta_c_list(c)),...
  raw_range_tone_local(opts.raw.nFast,scene.Rc_list(c)),raw_doppler_tone_local(opts.ND,scene.Dc_list(c)));
end
T=table((1:nu).',scene.theta_u_list(:),scene.Ru_list(:),scene.d0_u_list(:),scene.fr_u_list(:),...
 'VariableNames',{'ID','AngleDeg','RangeBin','DopplerBin','MicroDopplerSpacing'});
stream=RandStream('mt19937ar','Seed',opts.seed+10000000+job.mc-1);
z=(randn(stream,size(X))+1j*randn(stream,size(X)))/sqrt(2);
if job.name=="noise_only", X=z;
elseif isfinite(job.snr), X=X+sqrt(mean(abs(X).^2,'all')/10^(job.snr/10))*z; end
end

function [ratio,threshold,lmax,anyPeak]=diag_reference_test(P,t,opts,mi)
rr=round(t.RangeBin); dd=round(t.DopplerBin);
[threshold,lmax]=diag_threshold_at(P,rr,dd,opts,mi); ratio=P(rr,dd)/max(threshold,realmin); anyPeak=false;
for r=max(9,ceil(t.RangeBin-1.5)):min(size(P,1)-8,floor(t.RangeBin+1.5))
 for d=max(11,ceil(t.DopplerBin-2)):min(size(P,2)-10,floor(t.DopplerBin+2))
  if abs(r-t.RangeBin)>=1.5 || abs(d-t.DopplerBin)>=2, continue; end
  [th,lm]=diag_threshold_at(P,r,d,opts,mi); anyPeak=anyPeak || (lm && P(r,d)>th);
 end
end
end

function [threshold,lmax]=diag_threshold_at(P,r,d,opts,mi)
if r<9 || r>size(P,1)-8 || d<11 || d>size(P,2)-10
 threshold=NaN; lmax=false; return;
end
block=P(r-8:r+8,d-10:d+10); mask=true(17,21); mask(7:11,9:13)=false; ref=block(mask);
if mi==1, threshold=opts.rawCFARCalibration.caScale*mean(ref);
else, ref=sort(ref); threshold=opts.rawCFARCalibration.osScale*ref(ceil(0.75*numel(ref))); end
lmax=timed_is_local_max(P,r,d);
end

function S=diag_aggregate(T)
S=table(); keys=T(:,{'Case','Spacing','SNR','Method'});
keys.SNR(isnan(keys.SNR))=-realmax;
group=unique(keys,'rows'); group.SNR(group.SNR==-realmax)=NaN;
for j=1:height(group)
 g=group(j,:); sel=T.Case==g.Case & T.Spacing==g.Spacing & T.Method==g.Method & ...
  (T.SNR==g.SNR | (isnan(T.SNR)&isnan(g.SNR))); x=T(sel,:);
 n=sum(x.TrueUAV); tp=sum(x.TPBody); fp=sum(x.FPBody);
 row=[g,table(height(x),n,diag_div(sum(x.CoveredRD),n),diag_div(sum(x.Covered3D),n),...
  diag_div(sum(x.AcceptedCovered),sum(x.Covered3D)),diag_div(tp,n),diag_div(sum(x.TPLegacy),n),...
  diag_div(tp,tp+fp),diag_div(2*tp,n+tp+fp),mean(x.FPBody),mean(x.FPLegacy),mean(x.Candidates),...
  diag_div(sum(x.TruthLocalPass),n),diag_div(sum(x.IdealFactorPass),n),...
  'VariableNames',{'Trials','TruthTotal','BodyRDCoverage','Body3DCoverage','PassGiven3DCoverage',...
  'PdBody','PdLegacy','PrecisionBody','F1Body','FABody','FALegacy','MeanCandidates',...
  'TruthLocalPassRate','IdealFactorPassRate'})]; S=[S;row]; %#ok<AGROW>
end
end

function x=diag_div(a,b)
if b==0, x=NaN; else, x=a/b; end
end

function diag_plot(S,folder)
fields={'BodyRDCoverage','Body3DCoverage','PassGiven3DCoverage','PdBody','PdLegacy','FABody'};
titles={'Body candidate RD coverage','Body candidate 3D coverage','UAV pass given body coverage',...
 'Final Pd: body matching','Final Pd: legacy sideband matching','False UAV outputs: body matching'};
sp=unique(S.Spacing(S.Case=="cluster")); colors=lines(numel(sp));
fig=figure('Visible','off','Color','w','Position',[80 80 1400 760]);
for f=1:6
 subplot(2,3,f); hold on;
 for j=1:numel(sp)
  for method=["CA-CFAR","OS-CFAR"]
   rows=sortrows(S(S.Case=="cluster" & S.Spacing==sp(j) & S.Method==method,:),'SNR');
   xx=rows.SNR; xx(isinf(xx))=30;
   if method=="CA-CFAR", style='--o'; else, style='-s'; end
   plot(xx,rows.(fields{f}),style,'Color',colors(j,:),'DisplayName',sprintf('%s s=%g',method,sp(j)),'MarkerSize',4);
  end
 end
 title(titles{f}); xlabel('SNR (dB)'); grid on;
 xticks([-10 0 10 20 25 30]); xticklabels({'-10','0','10','20','25','No noise'});
 if f<6, ylim([0 1.05]); end
 if f==1, legend('Location','best','FontSize',8); end
end
savefig(fig,fullfile(folder,'01_stages.fig')); exportgraphics(fig,fullfile(folder,'01_stages.png'),'Resolution',160); close(fig);
fig=figure('Visible','off','Color','w','Position',[100 100 1200 400]);
for j=1:3
 subplot(1,3,j); hold on; fn={'PdBody','TruthLocalPassRate','IdealFactorPassRate'};
 for cas=["single_integer","single_offgrid"]
  for method=["CA-CFAR","OS-CFAR"]
   rows=sortrows(S(S.Case==cas & S.Method==method,:),'SNR'); xx=rows.SNR; xx(isinf(xx))=30;
   plot(xx,rows.(fn{j}),'-o','DisplayName',char(cas+" "+method));
  end
 end
 title(fn{j},'Interpreter','none'); ylim([0 1.05]); grid on;
 xticks([-10 0 10 20 25 30]); xticklabels({'-10','0','10','20','25','No noise'});
 if j==1, legend('Location','best','Interpreter','none','FontSize',7); end
end
savefig(fig,fullfile(folder,'02_controls.fig')); exportgraphics(fig,fullfile(folder,'02_controls.png'),'Resolution',160); close(fig);
end

function diag_readme(folder,cfg)
fid=fopen(fullfile(folder,'README.txt'),'w'); clean=onCleanup(@() fclose(fid));
fprintf(fid,'CFAR-only diagnostic. Original 1542 helpers. NO CPD or MUSIC. MC=%d.\n',cfg.numMC);
fprintf(fid,'Cases: integer/off-grid single UAV; 6-UAV+3-object clusters; noise only.\n');
fprintf(fid,'No noise: identical signal with exactly zero additive noise.\n');
fprintf(fid,'01_stages: RD -> 3D candidate coverage -> conditional classification -> final Pd.\n');
fprintf(fid,'Coverage is per-truth existence, NOT one-to-one. Final Pd is original greedy one-to-one.\n');
fprintf(fid,'PdBody matches body only. PdLegacy permits original body-or-sideband matching.\n');
fprintf(fid,'TruthLocalPass: true angle, nearest range bin, forced nearest body bin in actual mixture.\n');
fprintf(fid,'IdealFactorPass: isolated noiseless slow-time factor, same Hann/model/forced center.\n');
fprintf(fid,'Truth is used ONLY for probes/evaluation, never to choose detector candidates.\n');
fprintf(fid,'targets.csv: thresholds/local-max before NMS, candidate coverage after NMS.\n');
fprintf(fid,'candidates.csv: continuous model diagnostics; controls.csv: ideal and truth-directed probes.\n');
fprintf(fid,'NaN conditional metrics mean zero denominator. Thresholds are unchanged.\n');
fprintf(fid,'ClassificationSeconds excludes FFT and candidate extraction; not an end-to-end benchmark.\n');
fprintf(fid,'Noise-only calibration: 128 training and 16 validation frames.\n');
end

% Original 1542 local helpers (mechanically copied, unchanged).
function m = evaluate_detection_metrics_local(estTable, trueUAV, thr, sidebandAware)
trueTarget = height(trueUAV);
if isempty(estTable)
    estimateCount = 0;
else
    estimateCount = height(estTable);
end
usedTruth = false(trueTarget,1);
truePositive = 0;
angleSqErr = [];
rangeSqErr = [];
dopplerSqErr = [];

for ii = 1:estimateCount
    da = abs(estTable.AngleDeg(ii) - trueUAV.AngleDeg);
    dr = abs(estTable.RangeBin(ii) - trueUAV.RangeBin);
    dd = zeros(trueTarget,1);
    for uu = 1:trueTarget
        if sidebandAware && ismember('MicroDopplerSpacing', trueUAV.Properties.VariableNames)
            centers = trueUAV.DopplerBin(uu) + (-3:3) * trueUAV.MicroDopplerSpacing(uu);
            dd(uu) = min(abs(estTable.DopplerBin(ii) - centers));
        else
            dd(uu) = abs(estTable.DopplerBin(ii) - trueUAV.DopplerBin(uu));
        end
    end
    valid = da < thr.angleDeg & dr < thr.rangeBin & dd < thr.dopplerBin & ~usedTruth;
    if any(valid)
        score = da/max(thr.angleDeg,eps) + dr/max(thr.rangeBin,eps) + dd/max(thr.dopplerBin,eps);
        score(~valid) = inf;
        [~, idx] = min(score);
        usedTruth(idx) = true;
        truePositive = truePositive + 1;
        angleSqErr(end+1,1) = da(idx)^2; %#ok<AGROW>
        rangeSqErr(end+1,1) = dr(idx)^2; %#ok<AGROW>
        dopplerSqErr(end+1,1) = dd(idx)^2; %#ok<AGROW>
    end
end

falseAlarm = estimateCount - truePositive;
missed = trueTarget - truePositive;
m.trueTarget = trueTarget;
m.estimateCount = estimateCount;
m.truePositive = truePositive;
m.falseAlarm = falseAlarm;
m.missed = missed;
m.Pd = safe_divide_local(truePositive, trueTarget);
m.Pm = safe_divide_local(missed, trueTarget);
m.precision = safe_divide_local(truePositive, estimateCount);
m.recall = m.Pd;
m.F1 = safe_divide_local(2*m.precision*m.recall, m.precision + m.recall);
m.angleSqErr = angleSqErr;
m.rangeSqErr = rangeSqErr;
m.dopplerSqErr = dopplerSqErr;
m.angleRMSE = sqrt(mean_or_nan_local(angleSqErr));
m.rangeRMSE = sqrt(mean_or_nan_local(rangeSqErr));
m.dopplerRMSE = sqrt(mean_or_nan_local(dopplerSqErr));
end


function opts = fill_wrapper_defaults(opts)
if ~isfield(opts,'successThreshold') || isempty(opts.successThreshold)
    opts.successThreshold.angleDeg = 2;
    opts.successThreshold.rangeBin = 1.5;
    opts.successThreshold.dopplerBin = 2;
else
    if ~isfield(opts.successThreshold,'angleDeg'), opts.successThreshold.angleDeg = 2; end
    if ~isfield(opts.successThreshold,'rangeBin'), opts.successThreshold.rangeBin = 1.5; end
    if ~isfield(opts.successThreshold,'dopplerBin'), opts.successThreshold.dopplerBin = 2; end
end
if ~isfield(opts,'uavMergeRule') || isempty(opts.uavMergeRule)
    opts.uavMergeRule = struct();
end
if ~isfield(opts.uavMergeRule,'enable'), opts.uavMergeRule.enable = false; end
if ~isfield(opts.uavMergeRule,'angleDeg'), opts.uavMergeRule.angleDeg = 3; end
if ~isfield(opts.uavMergeRule,'rangeBin'), opts.uavMergeRule.rangeBin = 2; end
if ~isfield(opts.uavMergeRule,'dopplerBin'), opts.uavMergeRule.dopplerBin = 3; end
if ~isfield(opts.uavMergeRule,'sidebandHarmonics'), opts.uavMergeRule.sidebandHarmonics = -3:3; end
if ~isfield(opts.uavMergeRule,'spacingCandidates'), opts.uavMergeRule.spacingCandidates = [4 5 6 7 8]; end

% Local defaults needed by the independent sparse/subspace frameworks.
if ~isfield(opts,'theta_grid') || isempty(opts.theta_grid), opts.theta_grid = -60:0.1:60; end
if ~isfield(opts,'sigma_R') || isempty(opts.sigma_R), opts.sigma_R = 0.85; end
if ~isfield(opts,'sigma_D_u') || isempty(opts.sigma_D_u), opts.sigma_D_u = 0.75; end
if ~isfield(opts,'sigma_D_c') || isempty(opts.sigma_D_c), opts.sigma_D_c = 0.70; end
if ~isfield(opts,'cfarMinCandidates') || isempty(opts.cfarMinCandidates), opts.cfarMinCandidates = 20; end
if ~isfield(opts,'cfarCandidateExtra') || isempty(opts.cfarCandidateExtra), opts.cfarCandidateExtra = 10; end
if ~isfield(opts,'betaMD') || isempty(opts.betaMD), opts.betaMD = 0.8; end
if ~isfield(opts,'bodyAmp') || isempty(opts.bodyAmp), opts.bodyAmp = 1.0; end
if ~isfield(opts,'numSidebandOrder') || isempty(opts.numSidebandOrder), opts.numSidebandOrder = 3; end
if ~isfield(opts,'mdToBody_dB') || isempty(opts.mdToBody_dB), opts.mdToBody_dB = -10; end
if ~isfield(opts,'ospa') || isempty(opts.ospa), opts.ospa = struct(); end
if ~isfield(opts.ospa,'order') || isempty(opts.ospa.order), opts.ospa.order = 2; end
if ~isfield(opts.ospa,'p') || isempty(opts.ospa.p), opts.ospa.p = opts.ospa.order; end
if ~isfield(opts.ospa,'cutoff') || isempty(opts.ospa.cutoff), opts.ospa.cutoff = 3; end
end









































function y = get_field_default_local(s, name, defaultValue)
if isfield(s,name) && ~isempty(s.(name)), y = s.(name); else, y = defaultValue; end
end


function y = mean_or_nan_local(x)
x = x(isfinite(x));
if isempty(x)
    y = NaN;
else
    y = mean(x);
end
end


function e=model_bounded_error_1542_local(v,y,w,orders,N,centerBounds,spacingBounds)
if numel(v)~=2 || any(~isfinite(v)) || v(1)<centerBounds(1) || v(1)>centerBounds(2) ...
 || v(2)<spacingBounds(1) || v(2)>spacingBounds(2)
 e=1000; return;
end
e=model_fit_error_1542_local(y,w,v(1),v(2),orders,N);
end


function [isUAV,score,spacing,matched,width,reason,diagnostic]=model_decision_1542_local(g,rule,forcedCenter)
% Variable projection: optimize continuous frequencies, solve complex LS amplitudes.
if nargin<3, forcedCenter=[]; end
cfg=model_rule_1542_local(rule);
N=numel(g); width=timed_spectral_width_bins(g,rule.widthPowerFraction);
isUAV=false; score=0; spacing=0; matched=0;
reason="model-unstructured: no accepted physical model";
diagnostic=struct('toneError',NaN,'harmonicError',NaN,'BICGain',NaN, ...
 'relativeImprovement',NaN,'sidebandEnergy',NaN,'bodyBin',NaN, ...
 'spacing',NaN,'toneFit',NaN,'harmonicFit',NaN);
if N<16 || any(~isfinite(g)) || norm(g)<eps, return; end
y=ifft(ifftshift(g(:)))*sqrt(N); y=y/norm(y);
w=raw_window_local(N,get_field_default_local(rule,'modelWindow','none'));
[~,peak]=max(abs(g).^2);
if isempty(forcedCenter), center=peak; else, center=forcedCenter; end
center=max(1,min(N,center));
lo=max(1,center-cfg.centerHalfWidth); hi=min(N,center+cfg.centerHalfWidth);
search=optimset('Display','off','MaxIter',cfg.maxIter,'TolX',1e-4,'TolFun',1e-9);
toneObjective=@(f) model_fit_error_1542_local(y,w,f,0,0,N);
f0=fminbnd(toneObjective,lo,hi,search);
[E0,~]=model_fit_error_1542_local(y,w,f0,0,0,N);
orders=(-cfg.maxHarmonicOrder:cfg.maxHarmonicOrder).';
grid=double(rule.frCandidates(:));
assert(~isempty(grid) && all(isfinite(grid)) && all(grid>0),'ModelDecision:Spacing','Positive spacing candidates required.');
spacingLo=min(grid); spacingHi=max(grid);
if spacingLo==spacingHi, spacingHi=spacingLo+0.01; end
coarse=zeros(numel(grid),1);
for j=1:numel(grid), coarse(j)=model_fit_error_1542_local(y,w,f0,grid(j),orders,N); end
[~,order]=sort(coarse);
best=[f0 grid(order(1))]; E1=coarse(order(1));
objective=@(v) model_bounded_error_1542_local(v,y,w,orders,N,[lo hi],[spacingLo spacingHi]);
for j=1:min(cfg.refineStarts,numel(grid))
 start=[f0 grid(order(j))]; refined=fminsearch(objective,start,search);
 e=objective(refined);
 if e<E1, E1=e; best=refined; end
end
[E1,coef]=model_fit_error_1542_local(y,w,best(1),best(2),orders,N);
P=numel(orders); k0=3; k1=2*P+2;
% Approximate model-selection evidence. CPD-factor noise need not be iid;
% this is not a calibrated Bayesian probability or a guaranteed CFAR test.
bicGain=2*N*log(max(E0,cfg.residualFloor)/max(E1,cfg.residualFloor))-(k1-k0)*log(2*N);
improvement=(E0-E1)/max(E0,cfg.residualFloor);
power=abs(coef).^2; body=orders==0; side=~body;
sideEnergy=sum(power(side))/max(sum(power),eps);
supported=side & power>=cfg.minSideCoefficientRatio*max(power(body),eps);
matched=nnz(supported); both=any(supported & orders<0) && any(supported & orders>0);
centerDominant=power(body)>=max(power(side));
centerOK=abs(best(1)-f0)<=cfg.centerGuard;
if ~isempty(forcedCenter), centerOK=centerOK && abs(best(1)-forcedCenter)<=cfg.centerHalfWidth; end
physical=1-E1>=cfg.minHarmonicFit && centerOK && centerDominant;
isUAV=physical && bicGain>=cfg.minBICGain && improvement>=cfg.minRelativeImprovement ...
 && sideEnergy>=cfg.minSidebandEnergy && matched>=cfg.minSideCount ...
 && (~cfg.requireBothSides || both);
score=max(0,min(1,improvement))*max(0,1-E1);
spacing=best(2);
if isUAV
 reason="model-UAV: continuous harmonic evidence";
elseif 1-E0>=cfg.minToneFit
 reason="model-object: single-tone supported";
end
diagnostic=struct('toneError',E0,'harmonicError',E1,'BICGain',bicGain, ...
 'relativeImprovement',improvement,'sidebandEnergy',sideEnergy,'bodyBin',best(1), ...
 'spacing',best(2),'toneFit',1-E0,'harmonicFit',1-E1);
end


function opts=model_defaults_1542_local(opts)
cfg=get_field_default_local(opts,'sharedCPD',struct());
cfg.numRestarts=get_field_default_local(cfg,'numRestarts',opts.numRestarts);
cfg.maxRetryRounds=get_field_default_local(cfg,'maxRetryRounds',3);
validateattributes(cfg.numRestarts,{'numeric'},{'scalar','integer','positive'});
validateattributes(cfg.maxRetryRounds,{'numeric'},{'scalar','integer','nonnegative'});
opts.sharedCPD=cfg;
rule=opts.periodicRule;
rule.modelDecision=model_rule_1542_local(rule);
opts.periodicRule=rule;
end


function [e,c]=model_fit_error_1542_local(y,w,center,spacing,orders,N)
bins=center+orders(:).'*spacing;
frequencies=bins-1-floor(N/2);
D=w(:).*exp(1j*2*pi*(0:N-1).'*frequencies/N);
c=D\y;
e=max(0,real(sum(abs(y-D*c).^2)));
end


function cfg=model_rule_1542_local(rule)
cfg=get_field_default_local(rule,'modelDecision',struct());
defaults=struct('maxHarmonicOrder',3,'minBICGain',10, ...
 'minRelativeImprovement',0.25,'minHarmonicFit',0.75,'minToneFit',0.75, ...
 'minSidebandEnergy',0.01,'minSideCoefficientRatio',0.01,'minSideCount',2, ...
 'requireBothSides',true,'refineStarts',2,'maxIter',45, ...
 'centerHalfWidth',0.8,'centerGuard',0.65,'residualFloor',1e-10);
names=fieldnames(defaults);
for j=1:numel(names)
 name=names{j}; cfg.(name)=get_field_default_local(cfg,name,defaults.(name));
end
validateattributes(cfg.maxHarmonicOrder,{'numeric'},{'scalar','integer','positive'});
validateattributes(cfg.refineStarts,{'numeric'},{'scalar','integer','positive'});
validateattributes(cfg.maxIter,{'numeric'},{'scalar','integer','positive'});
for name={'minRelativeImprovement','minHarmonicFit','minToneFit','minSidebandEnergy','minSideCoefficientRatio'}
 validateattributes(cfg.(name{1}),{'numeric'},{'scalar','real','finite','>=',0,'<=',1});
end
validateattributes(cfg.minBICGain,{'numeric'},{'scalar','real','finite','nonnegative'});
validateattributes(cfg.residualFloor,{'numeric'},{'scalar','real','finite','positive','<',1});
end


function [candidates,info]=os_candidates_from_map_local(RV,opts,shape,blocked)
cfg=get_field_default_local(opts,'osCfar',struct());
pfa=get_field_default_local(cfg,'Pfa',1e-4);
fraction=get_field_default_local(cfg,'orderFraction',0.75);
matchCA=get_field_default_local(cfg,'matchCAEffectivePfa',true);
validateattributes(pfa,{'numeric'},{'scalar','positive','<',1});
validateattributes(fraction,{'numeric'},{'scalar','positive','<=',1});
gR=2; gD=2; wR=8; wD=10;
mask=true(2*wR+1,2*wD+1);
mask(wR-gR+1:wR+gR+1,wD-gD+1:wD+gD+1)=false;
n=nnz(mask); k=ceil(fraction*n);
alpha=opts.rawCFARCalibration.osScale; targetPfa=opts.rawCFARCalibration.targetPfa;
candidates=zeros(0,3);
for rr=wR+1:size(RV,1)-wR
    for dd=wD+1:size(RV,2)-wD
        if blocked(rr,dd) || ~timed_is_local_max(RV,rr,dd), continue; end
        block=RV(rr-wR:rr+wR,dd-wD:dd+wD); ref=sort(block(mask));
        if RV(rr,dd)>alpha*ref(k)
            candidates(end+1,:)=[rr dd RV(rr,dd)]; %#ok<AGROW>
        end
    end
end
candidates=timed_select_separated_candidates(candidates,...
    timed_get_opt(opts,'cfarMaxCandidates',inf),2,3);
info=struct('orderIndex',k,'referenceCells',n,'noiseShape',shape,...
    'thresholdScale',alpha,'nominalPfa',pfa,'effectiveTargetPfa',targetPfa,...
    'matchCAEffectivePfa',false,'calibration',opts.rawCFARCalibration);
end


function info=raw_calibrate_cfar_local(opts,key)
% Noise-only calibration includes window-induced correlation; no target data.
timer=tic; pfa=get_field_default_local(opts.osCfar,'Pfa',1e-4);
fraction=get_field_default_local(opts.osCfar,'orderFraction',.75);
validateattributes(pfa,{'numeric'},{'scalar','positive','<',1});
validateattributes(fraction,{'numeric'},{'scalar','positive','<=',1});
[rr,dd]=ndgrid(9:opts.NR-8,11:opts.ND-10);
cut=sub2ind([opts.NR opts.ND],rr(:),dd(:));
if isempty(cut), error('RawFMCW:CalibrationSize','NR and ND are too small for the CFAR reference window.'); end
[dr,dc]=ndgrid(-8:8,-10:10); mask=~(abs(dr)<=2 & abs(dc)<=2);
offset=dr(mask)+dc(mask)*opts.NR;
indices=offset(:)+cut(:).'; k=ceil(fraction*numel(offset));
nCut=numel(cut); frames=opts.raw.calibrationFrames;
ca=zeros(nCut,frames); os=ca;
stream=RandStream('mt19937ar','Seed',opts.raw.calibrationSeed);
fprintf('Noise-only CFAR calibration: %d frames, %d CUTs/frame; windows=%s/%s.\n',...
    frames,nCut,opts.raw.cfarRangeWindow,opts.raw.cfarDopplerWindow);
for j=1:frames
    X=(randn(stream,opts.M,opts.raw.nFast,opts.ND)+...
        1j*randn(stream,opts.M,opts.raw.nFast,opts.ND))/sqrt(2);
    Z=raw_process_tensor_local(X,opts,'cfar'); RV=squeeze(sum(abs(Z).^2,1));
    ref=RV(indices); ca(:,j)=RV(cut)./mean(ref,1).';
    ref=sort(ref,1); os(:,j)=RV(cut)./ref(k,:).';
    if mod(j,max(1,floor(frames/4)))==0 || j==frames
        fprintf('  Calibration frame %d/%d complete.\n',j,frames);
    end
end
c=sort(ca(:)); o=sort(os(:)); index=max(1,min(numel(c),ceil((1-pfa)*numel(c))));
caScale=c(index); osScale=o(index); clear ca os c o ref
validCA=0; validOS=0; samples=0;
stream=RandStream('mt19937ar','Seed',opts.raw.calibrationSeed+1);
for j=1:opts.raw.calibrationValidationFrames
    X=(randn(stream,opts.M,opts.raw.nFast,opts.ND)+...
        1j*randn(stream,opts.M,opts.raw.nFast,opts.ND))/sqrt(2);
    Z=raw_process_tensor_local(X,opts,'cfar'); RV=squeeze(sum(abs(Z).^2,1));
    ref=RV(indices); validCA=validCA+nnz(RV(cut)>caScale*mean(ref,1).');
    ref=sort(ref,1); validOS=validOS+nnz(RV(cut)>osScale*ref(k,:).');
    samples=samples+nCut;
end
info=struct('key',key,'caScale',caScale,'osScale',osScale,'targetPfa',pfa,...
    'orderIndex',k,'referenceCells',numel(offset),'frames',frames,...
    'sampleCount',nCut*frames,'validationSampleCount',samples,...
    'validationCA',validCA/max(samples,1),'validationOS',validOS/max(samples,1),...
    'expectedTailSamples',nCut*frames*pfa,'seed',opts.raw.calibrationSeed,...
    'elapsedSeconds',toc(timer),'definition',"noise-only cell ratios before local-peak selection");
if info.expectedTailSamples<50
    warning('RawFMCW:SmallCalibration','Only %.1f expected tail samples; increase calibrationFrames for production.',info.expectedTailSamples);
end
fprintf('Calibration complete: CA=%g, OS=%g; validation rates=%g / %g; setup %.2f s.\n',...
    caScale,osScale,info.validationCA,info.validationOS,info.elapsedSeconds);
end


function key=raw_calibration_key_local(opts)
pfa=get_field_default_local(opts.osCfar,'Pfa',1e-4);
fraction=get_field_default_local(opts.osCfar,'orderFraction',.75);
key=sprintf('%d/%d/%d/%d/%s/%s/%.12g/%.12g/%d/%d/%d',...
    opts.M,opts.raw.nFast,opts.NR,opts.ND,opts.raw.cfarRangeWindow,...
    opts.raw.cfarDopplerWindow,pfa,fraction,opts.raw.calibrationFrames,...
    opts.raw.calibrationValidationFrames,opts.raw.calibrationSeed);
end


function v=raw_doppler_tone_local(ND,d)
v=exp(1j*2*pi*(d-1-floor(ND/2))*(0:ND-1).'/ND)/sqrt(ND);
end


function opts=raw_fill_default_opts_local(opts)
cfg=get_field_default_local(opts,'raw',struct());
cfg.nFast=get_field_default_local(cfg,'nFast',2*opts.NR);
cfg.carrierHz=get_field_default_local(cfg,'carrierHz',24e9);
cfg.sampleRateHz=get_field_default_local(cfg,'sampleRateHz',2e6);
cfg.chirpSlopeHzPerSec=get_field_default_local(cfg,'chirpSlopeHzPerSec',1e12);
cfg.chirpRepetitionSec=get_field_default_local(cfg,'chirpRepetitionSec',100e-6);
cfg.tensorWindow=get_field_default_local(cfg,'tensorWindow','none');
cfg.cfarRangeWindow=lower(char(get_field_default_local(cfg,'cfarRangeWindow','hann')));
cfg.cfarDopplerWindow=lower(char(get_field_default_local(cfg,'cfarDopplerWindow','hann')));
cfg.calibrationFrames=get_field_default_local(cfg,'calibrationFrames',128);
cfg.calibrationValidationFrames=get_field_default_local(cfg,'calibrationValidationFrames',16);
cfg.calibrationSeed=get_field_default_local(cfg,'calibrationSeed',24681357);
validateattributes(cfg.nFast,{'numeric'},{'scalar','integer','positive'});
validateattributes(cfg.sampleRateHz,{'numeric'},{'scalar','finite','positive'});
validateattributes(cfg.carrierHz,{'numeric'},{'scalar','finite','positive'});
validateattributes(cfg.chirpSlopeHzPerSec,{'numeric'},{'scalar','finite','positive'});
validateattributes(cfg.chirpRepetitionSec,{'numeric'},{'scalar','finite','positive'});
validateattributes(cfg.calibrationFrames,{'numeric'},{'scalar','integer','positive'});
validateattributes(cfg.calibrationValidationFrames,{'numeric'},{'scalar','integer','positive'});
if cfg.nFast~=2*opts.NR, error('RawFMCW:Size','nFast must equal 2*NR for positive-range retention.'); end
if ~strcmpi(cfg.tensorWindow,'none'), error('RawFMCW:CPDWindow','CPD input must be raw and unwindowed.'); end
if cfg.nFast/cfg.sampleRateHz>cfg.chirpRepetitionSec
    error('RawFMCW:Timing','Fast-time sampling interval exceeds chirp repetition interval.');
end
cfg.c0=299792458; cfg.wavelength=cfg.c0/cfg.carrierHz;
cfg.rangeBinMeters=cfg.c0*cfg.sampleRateHz/(2*cfg.chirpSlopeHzPerSec*cfg.nFast);
cfg.dopplerBinHz=1/(opts.ND*cfg.chirpRepetitionSec);
cfg.chirpSampledDurationSec=cfg.nFast/cfg.sampleRateHz;
cfg.sampledBandwidthHz=cfg.chirpSlopeHzPerSec*cfg.chirpSampledDurationSec;
opts.raw=cfg;
if ~isfield(opts,'energyAssist'), opts.energyAssist=struct(); end
if get_field_default_local(opts.energyAssist,'enable',false)
    error('RawFMCW:Rescue','Disable legacy energyAssist; its truth-count/SNR-gated rescue is not used in this version.');
end
opts.energyAssist.enable=false; opts.energyAssist.lowSNREnable=false;
if ~isfield(opts,'osCfar'), opts.osCfar=struct(); end
opts.osCfar.matchCAEffectivePfa=false;
key=raw_calibration_key_local(opts);
if ~isfield(opts,'rawCFARCalibration') || ~isfield(opts.rawCFARCalibration,'key') || ...
        ~strcmp(opts.rawCFARCalibration.key,key)
    opts.rawCFARCalibration=raw_calibrate_cfar_local(opts,key);
end
end


function Y=raw_process_tensor_local(X,opts,branch)
if strcmp(branch,'cfar')
    wr=raw_window_local(opts.raw.nFast,opts.raw.cfarRangeWindow);
    wd=raw_window_local(opts.ND,opts.raw.cfarDopplerWindow);
else
    wr=ones(opts.raw.nFast,1); wd=ones(opts.ND,1);
end
Y=X.*reshape(wr,1,[],1).*reshape(wd,1,1,[]);
Y=fft(Y,[],2)/sqrt(opts.raw.nFast);
Y=Y(:,1:opts.NR,:);
Y=fftshift(fft(Y,[],3),3)/sqrt(opts.ND);
end


function v=raw_range_tone_local(NF,r)
v=exp(1j*2*pi*(r-1)*(0:NF-1).'/NF)/sqrt(NF);
end


function w=raw_window_local(N,name)
switch lower(char(name))
    case {'none','rect','rectangular'}, w=ones(N,1);
    case 'hann', w=.5-.5*cos(2*pi*(0:N-1).'/N);
    case 'hamming', w=.54-.46*cos(2*pi*(0:N-1).'/N);
    otherwise, error('RawFMCW:Window','Window must be none, hann or hamming.');
end
w=w*sqrt(N)/max(norm(w),eps); % Unit RMS: preserve expected marginal noise power.
end


function y = safe_divide_local(a,b)
if b == 0
    y = NaN;
else
    y = a / b;
end
end


function P = timed_angle_spectrum(x, theta_grid)
M = numel(x); P = zeros(numel(theta_grid),1);
for ii = 1:numel(theta_grid), P(ii) = abs(timed_steering_ula(M, theta_grid(ii))' * x)^2; end
end

function [candidateList, cfarMask] = timed_cfar_2d_candidates(RV, opts)
[NR,ND] = size(RV); cfarMask = false(NR,ND); gR=opts.guardR; gD=opts.guardD; tR=opts.trainR; tD=opts.trainD; winR=tR+gR; winD=tD+gD;
numTrain = (2*winR+1)*(2*winD+1)-(2*gR+1)*(2*gD+1); alpha = timed_get_opt(opts,'thresholdScale',numTrain*(opts.Pfa^(-1/numTrain)-1));
for rr=(winR+1):(NR-winR)
    for dd=(winD+1):(ND-winD)
        block=RV(rr-winR:rr+winR,dd-winD:dd+winD); guard=false(size(block)); guard((winR-gR+1):(winR+gR+1),(winD-gD+1):(winD+gD+1))=true;
        if RV(rr,dd)>alpha*mean(block(~guard)) && timed_is_local_max(RV,rr,dd), cfarMask(rr,dd)=true; end
    end
end
[rIdx,dIdx]=find(cfarMask); if isempty(rIdx), candidateList=zeros(0,3); return; end
candidateList = timed_select_separated_candidates([rIdx,dIdx,RV(sub2ind(size(RV),rIdx,dIdx))], opts.maxCandidates, opts.minRangeDistance, opts.minDopplerDistance);
end

function [isUAV,bestScore,bestSpacing,matchedPeaks,widthBins,reason]=timed_classify_hybrid_peaks(g,rule,forcedCenter)
if nargin<3, forcedCenter=[]; end
[isUAV,bestScore,bestSpacing,matchedPeaks,widthBins,reason]=model_decision_1542_local(g,rule,forcedCenter);
end


function [isUAV,score,spacing,matched,width,reason]=timed_classify_hybrid_peaks_adjacent(g,d0,offsets,rule) %#ok<INUSD>
[isUAV,score,spacing,matched,width,reason]=timed_classify_hybrid_peaks(g,rule,d0);
end


function scene = timed_f_make_sim_scene_local(Nu, Nc, Nn, opts) %#ok<INUSD>
% Every group obeys the same bounded uniform-offset rule; no truth enters estimators.
cfg = timed_get_opt(opts,'spacing',struct());
scale = timed_get_opt(cfg,'scale',1);
bounds = timed_get_opt(cfg,'baseBounds',[3 0.6 3]);
centers = timed_get_opt(cfg,'centers',[-30 30 48; 0 48 64; 30 66 80]);
counts = timed_get_opt(opts,'clusterUAVCounts',[1 2 3]);
validateattributes(scale,{'numeric'},{'scalar','finite','positive'});
validateattributes(bounds,{'numeric'},{'size',[1 3],'finite','positive'});
if numel(counts)~=Nc || sum(counts)~=Nu || any(counts<0 | counts~=fix(counts))
    error('SpacingScene:Counts','clusterUAVCounts must contain Nc nonnegative integers summing to Nu.');
end
if size(centers,2)~=3 || size(centers,1)<Nc || any(~isfinite(centers(:)))
    error('SpacingScene:Centers','Supply at least Nc finite [angle,range,Doppler] center rows.');
end
if isfield(opts,'offGrid') && timed_get_opt(opts.offGrid,'enable',false)
    error('SpacingScene:ExtraJitter','Disable extra offGrid jitter; positions already have bounded fractional offsets.');
end
centers=centers(1:Nc,:);
unitOffsets=2*rand(Nu,3)-1;
offsets=unitOffsets.*(scale*bounds);
ids=repelem((1:Nc).',counts(:));
positions=centers(ids,:)+offsets;
frDict=[5 6 7 8];
fr=frDict(randi(numel(frDict),Nu,1));
uavAmpRange=timed_get_opt(cfg,'uavAmplitudeRange',[0.55 0.90]);
objectAmpRange=timed_get_opt(cfg,'objectAmplitudeRange',[1.25 2.20]);
validateattributes(uavAmpRange,{'numeric'},{'size',[1 2],'finite','positive','nondecreasing'});
validateattributes(objectAmpRange,{'numeric'},{'size',[1 2],'finite','positive','nondecreasing'});
ampU=uavAmpRange(1)+diff(uavAmpRange)*rand(Nu,1);
ampC=objectAmpRange(1)+diff(objectAmpRange)*rand(Nc,1);
allPos=[positions;centers];
if any(allPos(:,1)<min(opts.theta_grid) | allPos(:,1)>max(opts.theta_grid)) || ...
        any(allPos(:,2)<1 | allPos(:,2)>opts.NR) || ...
        any(allPos(:,3)<1 | allPos(:,3)>opts.ND)
    error('SpacingScene:OutOfBounds','A scaled target leaves the observation domain; adjust centers or spacing bounds.');
end
if any(positions(:,3)-3*fr<1 | positions(:,3)+3*fr>opts.ND)
    error('SpacingScene:SidebandClipping','A retained sideband leaves the Doppler domain; adjust centers or spacing scale.');
end
scene=struct();
scene.theta_u_list=positions(:,1).'; scene.Ru_list=positions(:,2).';
scene.d0_u_list=positions(:,3).'; scene.fr_u_list=fr(:).';
scene.alpha_u_list=ampU(:).';
scene.theta_c_list=centers(:,1).'; scene.Rc_list=centers(:,2).';
scene.Dc_list=centers(:,3).'; scene.alpha_c_list=ampC(:).';
scene.clusterID_u=ids(:).'; scene.clusterID_c=1:Nc;
scene.clusterUAVCounts=counts(:).'; scene.K_true=Nu+Nc;
scene.spacingScale=scale; scene.baseBounds=bounds; scene.centers=centers;
scene.normalizedOffsets=unitOffsets; scene.actualOffsets=offsets;
scene.uavRangeMeters=(scene.Ru_list-1)*opts.raw.rangeBinMeters;
scene.nonUAVRangeMeters=(scene.Rc_list-1)*opts.raw.rangeBinMeters;
scene.uavBodyDopplerHz=(scene.d0_u_list-1-floor(opts.ND/2))*opts.raw.dopplerBinHz;
scene.nonUAVBodyDopplerHz=(scene.Dc_list-1-floor(opts.ND/2))*opts.raw.dopplerBinHz;
scene.uavVelocityMps=scene.uavBodyDopplerHz*opts.raw.wavelength/2;
scene.uav_sideband_amps=timed_make_bessel_sideband_amps(opts.bodyAmp,opts.betaMD, ...
    opts.numSidebandOrder,opts.mdToBody_dB);
end


function opts = timed_fill_default_opts(opts)
if ~isfield(opts,'seed'), opts.seed = 20260605; end
if ~isfield(opts,'verbose'), opts.verbose = true; end
if ~isfield(opts,'numRestarts'), opts.numRestarts = 4; end
if ~isfield(opts,'doTensor'), opts.doTensor = true; end
if ~isfield(opts,'successThreshold')
    opts.successThreshold.angleDeg = 5;
    opts.successThreshold.rangeBin = 3;
    opts.successThreshold.dopplerBin = 4;
end

opts.M = timed_get_opt(opts,'M',16);
opts.NR = timed_get_opt(opts,'NR',96);
opts.ND = timed_get_opt(opts,'ND',128);
opts.theta_grid = timed_get_opt(opts,'theta_grid',-60:0.1:60);
opts.sigma_R = timed_get_opt(opts,'sigma_R',0.85);
opts.sigma_D_u = timed_get_opt(opts,'sigma_D_u',0.75);
opts.sigma_D_c = timed_get_opt(opts,'sigma_D_c',0.70);
opts.uavAlphaRange = timed_get_opt(opts,'uavAlphaRange',[0.75 1.00]);
opts.clutterAlphaRange = timed_get_opt(opts,'clutterAlphaRange',[0.20 0.40]);
opts.cfarCandidateExtra = timed_get_opt(opts,'cfarCandidateExtra',10);
opts.cfarMinCandidates = timed_get_opt(opts,'cfarMinCandidates',20);
opts.adjacentDopplerBins = timed_get_opt(opts,'adjacentDopplerBins',-2:2);
opts.tradRangeNeighborhood = timed_get_opt(opts,'tradRangeNeighborhood',-2:2);
opts.tradDopplerNeighborhood = timed_get_opt(opts,'tradDopplerNeighborhood',-8:8);

mergeRule.angleDeg = 3;
mergeRule.rangeBin = 2;
mergeRule.dopplerBin = 3;
mergeRule.sidebandHarmonics = -3:3;
mergeRule.spacingCandidates = [5 6 7 8];
mergeRule.maxGroupSize = inf;
opts.uavMergeRule = timed_get_opt(opts,'uavMergeRule',mergeRule);

opts.bodyAmp = timed_get_opt(opts,'bodyAmp',1.0);
opts.betaMD = timed_get_opt(opts,'betaMD',0.8);
opts.numSidebandOrder = timed_get_opt(opts,'numSidebandOrder',3);
opts.mdToBody_dB = timed_get_opt(opts,'mdToBody_dB',-10);
opts.uavSidebandAmps = timed_get_opt(opts,'uavSidebandAmps',timed_make_bessel_sideband_amps(opts.bodyAmp, opts.betaMD, opts.numSidebandOrder, opts.mdToBody_dB));

rankRule.minDeltaR = 0.005;
rankRule.consecutiveRequired = 1;
rankRule.retryOnResidualIncrease = true;
rankRule.maxRetryRounds = 3;
rankRule.retryRestarts = opts.numRestarts;
rankRule.hardMaxRank = 48;
if ~isfield(opts,'rankSelectionRule') || isempty(opts.rankSelectionRule)
    opts.rankSelectionRule = rankRule;
else
    ruleFields = fieldnames(rankRule);
    for ii = 1:numel(ruleFields)
        field = ruleFields{ii};
        if ~isfield(opts.rankSelectionRule,field)
            opts.rankSelectionRule.(field) = rankRule.(field);
        end
    end
end

rule.frCandidates = 1:10;
rule.searchHalfWidth = 2;
rule.peakRelThreshold = 0.04;
rule.minPeakDistance = 2;
rule.minMatchedPeaks = 3;
rule.spacingTolerance = 1;
rule.matchedEnergyHalfWidth = 1;
rule.minPeriodicScore = 0.30;
rule.maxPeriodicityError = 0.95;
rule.minWidthBins = 5;
rule.maxWidthBins = 30;
rule.widthPowerFraction = 0.90;
opts.periodicRule = timed_get_opt(opts,'periodicRule',rule);
end


function v = timed_get_opt(s, name, defaultValue)
if isfield(s,name)
    v = s.(name);
else
    v = defaultValue;
end
end


function tf = timed_is_local_max(A,rr,dd), block=A(rr-1:rr+1,dd-1:dd+1); tf=A(rr,dd)==max(block(:)); end


function uavSidebandAmps = timed_make_bessel_sideband_amps(bodyAmp, betaMD, numSidebandOrder, mdToBody_dB)
% Body amplitude is fixed, while all micro-Doppler sidebands are scaled so
% that their total energy has the target MD-to-body energy ratio.
if numSidebandOrder ~= 3
    error('This simulation currently expects numSidebandOrder = 3.');
end
J1 = abs(besselj(1, betaMD));
J2 = abs(besselj(2, betaMD));
J3 = abs(besselj(3, betaMD));
baseSidebands = [J1, J1, J2, J2, J3, J3];
P0 = sum(baseSidebands.^2);
if P0 <= eps
    sidebands = zeros(size(baseSidebands));
else
    alpha = sqrt(10^(mdToBody_dB/10) * bodyAmp^2 / P0);
    sidebands = alpha * baseSidebands;
end
uavSidebandAmps = [bodyAmp, sidebands];
end

function X = timed_outer3(a,b,c)
X = zeros(numel(a),numel(b),numel(c));
for kk = 1:numel(c), X(:,:,kk) = a * (b.' * c(kk)); end
end

function [tradResult, tradResultAll, tradCandidates] = timed_run_traditional_chain(X, theta_grid, opts, candidateOverride)
% Classify at the detected peak. Classification never rewrites peak coordinates.
[M,~,ND]=size(X);
RV=squeeze(sum(abs(X).^2,1));
cfar=struct('guardR',2,'guardD',2,'trainR',6,'trainD',8,'Pfa',1e-4,...
    'maxCandidates',timed_get_opt(opts,'cfarMaxCandidates',inf),...
    'minRangeDistance',2,'minDopplerDistance',3,'thresholdScale',opts.rawCFARCalibration.caScale);
if nargin<4
    [tradCandidates,~]=timed_cfar_2d_candidates(RV,cfar);
else
    tradCandidates=candidateOverride;
end
K0=size(tradCandidates,1);
angle=zeros(K0,1); range=tradCandidates(:,1); doppler=tradCandidates(:,2);
score=zeros(K0,1); spacing=zeros(K0,1); matched=zeros(K0,1);
width=nan(K0,1); reason=strings(K0,1); isUAV=false(K0,1);
for kk=1:K0
    rr=range(kk); dd=doppler(kk);
    P=timed_angle_spectrum(X(:,rr,dd),theta_grid);
    [~,it]=max(P); angle(kk)=theta_grid(it);
    a=timed_steering_ula(M,angle(kk));
    Y=reshape(X(:,rr,:),M,ND);
    g=(a'*Y).';
    decisionRule=opts.periodicRule; decisionRule.modelWindow=opts.raw.cfarDopplerWindow;
    [isUAV(kk),score(kk),spacing(kk),matched(kk),width(kk),reason(kk)]=...
        timed_classify_hybrid_peaks_adjacent(g,dd,opts.adjacentDopplerBins,decisionRule);
end
tradResultAll=table((1:K0).',angle,range,doppler,score,spacing,matched,width,reason,isUAV,...
    'VariableNames',{'ID','AngleDeg','RangeBin','DopplerBin','PeriodicScore',...
    'BestSpacing','MatchedPeaks','SpectrumWidth','DecisionReason','IsUAV'});
tooWide=contains(reason,["too wide before periodic test","model-unstructured"]);
label=repmat("Object",K0,1); label(tooWide)="Rejected"; label(~tooWide & isUAV)="UAV";
tradResultAll.ClassLabel=label;
tradResult=tradResultAll(~tooWide,:);
end


function selected = timed_select_separated_candidates(cand,maxCandidates,minRangeDistance,minDopplerDistance)
if isempty(cand), selected=zeros(0,3); return; end
[~,ord]=sort(cand(:,3),'descend'); cand=cand(ord,:); selected=[];
for ii=1:size(cand,1)
    if isempty(selected) || all(abs(selected(:,1)-cand(ii,1))>=minRangeDistance | abs(selected(:,2)-cand(ii,2))>=minDopplerDistance)
        selected=[selected; cand(ii,:)]; %#ok<AGROW>
    end
    if size(selected,1)>=maxCandidates, break; end
end
end

function widthBins=timed_spectral_width_bins(g,powerFraction)
p=abs(g(:)).^2; p=p/(sum(p)+eps); [~,peakIdx]=max(p); left=peakIdx; right=peakIdx; captured=p(peakIdx);
while captured<powerFraction && (left>1 || right<numel(p))
    lp=-inf; rp=-inf; if left>1, lp=p(left-1); end; if right<numel(p), rp=p(right+1); end
    if lp>=rp, left=left-1; captured=captured+p(left); else, right=right+1; captured=captured+p(right); end
end
widthBins=right-left+1;
end

function a = timed_steering_ula(M, theta_deg)
m = (0:M-1).'; a = exp(1j*pi*m*sind(theta_deg)); a = a / norm(a);
end
