% CFAR-only small diagnostic. No Tensorlab dependency.
codeRoot=fileparts(mfilename('fullpath'));
addpath(codeRoot);
cfg=struct('numMC',5,'snr',[-10 0 10 20 25 Inf],'spacing',[0.5 1 3]);
cfg.outputRoot=fullfile(codeRoot,'Figures','cfardiag20261027');
diagnosticResult=f_cfar_diag_20261027(cfg);
