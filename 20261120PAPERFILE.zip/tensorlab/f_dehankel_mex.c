#include "mex.h"
#include "matrix.h"
#include <stdlib.h>
#include <stdint.h>

/* The gateway function */
void mexFunction( int nlhs, mxArray *plhs[],
                  int nrhs, const mxArray *prhs[])
{   
    int64_t nY = (int64_t) mxGetScalar(prhs[0]);
    int64_t *index = (int64_t *) mxGetInt64s(prhs[1]);
    mxComplexDouble *x = mxGetComplexDoubles(prhs[2]); int64_t nIndex = mxGetM(prhs[2]);

    plhs[0] = mxCreateDoubleMatrix((mwSize)(nY),(mwSize)1,mxCOMPLEX);
    mxComplexDouble *y = mxGetComplexDoubles(plhs[0]);
    plhs[1] = mxCreateNumericMatrix((mwSize)(nY),1,mxINT64_CLASS,mxREAL);
    int64_t *num = mxGetInt64s(plhs[1]);
    int64_t ii;
    for (ii = 0; ii < nIndex; ii++) {
        num[index[ii]-1] = num[index[ii]-1] + 1;
        y[index[ii]-1].real += x[ii].real;
        y[index[ii]-1].imag += x[ii].imag;
    }
    for (ii = 0; ii < nY; ii++) {
        if (num[ii] > 0) {
            y[ii].real /= (double) num[ii];
            y[ii].imag /= (double) num[ii];
        }
    }
}
