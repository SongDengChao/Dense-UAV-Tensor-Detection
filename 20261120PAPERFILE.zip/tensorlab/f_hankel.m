function T_new = f_hankel(T, varargin)
%% The function is used to hanklize a tensor T in some dimensions.
%% Inputs:
% T: The tensor to be hanklized;
% varargin: A cell contains the parameters of the hanklization method.
%           There are two methods to input the parameters:
%           Method 1: f_hankel(T, sz1, sz2, ..., szN, st1, st2, ..., stN);
%           Method 2: f_hankel(T, {sz1, sz2, ..., szN}, {st1, st2, ..., stN});
%                     where N is equal to the dimension of tensor T;
%                     szn is a vector which denotes the size of the n-th dimensions after hankelization,
%                     stn is a vector which denotes the size of the n-th dimensions after hankelization;
%                     The length of szn should be equal to the length of stn,
%                     while setting szn = stn = [] means doing no hankelization on the n-th dimension.
%% Outputs:
% T_new: The hankelized tensor whose size is [sz1 sz2 ... szN].

sizeT = size(T); NT = length(sizeT);
if (NT == 2 && sizeT(2) == 1)
    NT = 1;
end
if (isempty(varargin))
    error("The dimesion dismatches.");
elseif (length(varargin) == 2 && iscell(varargin{1}) && iscell(varargin{2}))
    varargin = [varargin{1}, varargin{2}];
end
if (length(varargin)/2 < NT)
    error("The dimesion dismatches.");
end

ind = 0; l = 0;
for n = 1:NT
    sz = varargin{n}; st = varargin{n+NT};
    if (length(sz) ~= length(st))
        error("The dimesion dismatches.");
    end
    if (isempty(sz))
        ind_ = linvec(0, 1*prod(sizeT(1:n-1)), sizeT(n)); sz = sizeT(n);
    elseif (length(sz) == 1)
        ind_ = linvec(0, st*prod(sizeT(1:n-1)), sz);
    else
        ind_ = f_hankel_vec(sz, st*prod(sizeT(1:n-1)));
    end
    if ((sz-1)*st.'+1 > sizeT(n))
        error("The index is oversized.");
    end
    ind_t = reshape(ind_, [ones(1, l) [sz 1]]);
    ind = ind + ind_t; l = l + length(sz);
end
ind = ind + 1;

T_new = T(ind);

end


%%
function out = linvec(init, step, n)
out = init + (0:step:(n-1)*step);
end

function T = f_hankel_vec(sz, st)
ind = linvec(0, st(1), sz(1)).';
for n = 2:length(sz)
    ind_ = linvec(0, st(n), sz(n));
    ind_t = reshape(ind_, [ones(1, n-1) sz(n)]);
    ind = ind + ind_t;
end
T = ind;
end
