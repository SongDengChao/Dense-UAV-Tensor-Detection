function [P, w, relerr] = f_ALGO_VVD_JEVD(x, R)
%% An algebraic algorithm for computing the Vandermode vector decomposition (VVD) x = P*w, where P is a Vandermonde Structured matrix.
%% Inputs:
% x: The data vector to be decomposed;
% R: The approximate number of latent Vandermonde Structured vectors.
%% Outputs:
% P: The Vandermonde Structured factor matrix;
% w: The complex coefficient vector.
% relerr: The relative fitting error of the vector decompostion to the data vector.

lx = length(x);

sz = [floor(lx/2) lx+1-floor(lx/2)]; st = [1 1];
X = f_DATA_HANKEL(x, sz, st); X = X.data;
[A, ~, D, ~] = f_ALGO_VMD_EVD(X, R);
generator = A(2,:);
P = f_vdm(generator, lx); w = diag(D);
relerr = norm(P*w-x) / norm(x);
end


%%
function [A, B, D, relerr] = f_ALGO_VMD_EVD(X, R)
%% An algebraic algorithm for computing the Vandermonde matrix decomposition (VMD) X = A*D*B^T, where A and B are Vandermonde Structured matrices with the same generators.
%% Inputs:
% X: The data matrix to be decomposed;
% R: The approximate rank of the Vandermonde Structured decomposition.
%% Outputs:
% A, B, D: The factor matrices;
% relerr: The relative fitting error of the matrix decompostion to the data.

[U, S, V] = f_svd(X, R);
Y = U; W = conj(V) * S;
Y1 = Y(1:end-1, :); Y2 = Y(2:end, :); P = (pinv(Y1)*Y2).';
W1 = W(1:end-1, :); W2 = W(2:end, :); Q = (pinv(W1)*W2);

[V, D] = eig((P+Q)/2); D = diag(D);
[~, ind] = sort(abs(D), 'descend');
M = V(:, ind(1:R)); Z = diag(D(ind(1:R)));
M = M.'; Z = diag(Z).'; Z = Z ./ abs(Z);

A = f_vdm(Z, size(X, 1)); B = f_vdm(Z, size(X, 2));
D1 = mean((Y/M)./A); D2 = mean((W*M.')./B); D = diag(D1.*D2);

relerr = norm(X - A*D*B.') / norm(X);

end

function Y = f_DATA_HANKEL(X,sz,st)
%% X is the matrix whose columns are to be hankelized
%  sz denotes the size of the obtained tensor after hankelization
%  st denotes the step size of hankelization in each mode
[N,T] = size(X);
dim = length(sz);
trunc = sum((sz - ones(1,dim)).*st)+1;
if trunc > N
    error('The hankelized tensor is oversized, consider reducing the dimension or stepsize in certain mode');
else
    X_data = X(1:trunc,:);
end
ind_ten = ones(sz);
for ii = 1:dim
    order = [ii,setdiff([1:dim],ii)];
    t_sz = sz(order);
    t_vec = (0:st(ii):st(ii)*(sz(ii)-1)).';
    t_ind_ten = repmat(t_vec,[1,t_sz(2:end)]);
    [~,new_order] = sort(order);
    t_ind_ten = permute(t_ind_ten,new_order);
    ind_ten = ind_ten + t_ind_ten;
end
Y.data = [];
Y.ind = ind_ten;
for tt = 1:T
    t_vec = X_data(:,tt).';
    Y.data = cat(dim+1,Y.data,t_vec(Y.ind));    
end
end

function [U,S,V] = f_svd(mtx,R)
sz = size(mtx);
if sz(1) == sz(2)
    [U,S,V] = svd(mtx);
    U = U(:,1:R);S = S(1:R,1:R);V = V(:,1:R);
elseif sz(1) < sz(2)
    t_mtx = mtx * mtx';
    [U,S,~] = svd(t_mtx);
    U = U(:,1:R);
    S = sqrt(S(1:R,1:R));
    V = (S\U')*mtx;
    V = V';
else
    t_mtx = mtx'*mtx;
    [V,S,~] = svd(t_mtx);
    V = V(:,1:R);
    S = sqrt(S(1:R,1:R));
    U = mtx*V/S;
end
end

function U = f_vdm(generator, dim)
%% ��������ʸ���󷶵��ɾ���
R = numel(generator);
U = ones(dim,R);
for ii = 2:dim
    U(ii,:) = U(ii-1,:).*generator;
end
end
