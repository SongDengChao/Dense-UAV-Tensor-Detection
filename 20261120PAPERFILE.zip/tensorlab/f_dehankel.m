function T = f_dehankel(T_new, sizeT, varargin)
%% The function is used to dehanklize a tensor T in some dimensions.
%% Inputs:
% T_new: The tensor to be dehanklized.
% sizeT: The size of the output tensor T.
% varargin: A cell contains the parameters of the dehanklization method.
%           There are two methods to input the parameters:
%           Method 1: f_dehankel(T_new, sizeT, st1, st2, ..., stN);
%           Method 2: f_hankel(T_new, sizeT, {st1, st2, ..., stN});
%                     where N is equal to the dimension of tensor T;
%                     stn is a vector which denotes the size of the n-th dimensions after getting T_new from T by hankelization,
%                     while setting stn = [] means there does no hankelization on the n-th dimension when getting T_new from T.
%% Outputs:
% T: A cell which contains the dehankelized tensor whose size is sizeT and the index of the missing datas after the hankelization and dehankelization operation.
%    T.data: The dehankelized tensor whose size is sizeT;
%    T.missingInd: The index of the missing datas after the -hankelization and dehankelization operation.

sizeT_new = size(T_new); NT = length(sizeT);
if (isempty(varargin))
    error("The dimesion dismatches.");
elseif (length(varargin) == 1 && iscell(varargin{1}))
    varargin = varargin{1};
end
if (length(varargin) < NT)
    error("The dimesion dismatches.");
end

szT_new = cell(1, NT); l = 1;
for n = 1:NT
    if (isempty(varargin{n}))
        varargin{n} = 1;
    end
    szT_new{n} = sizeT_new(linvec(l, 1, length(varargin{n})));
    l = l + length(varargin{n});
end

ind = 0; l = 0; hFlag = zeros(1, NT);
for n = 1:NT
    st = varargin{n}; sz = szT_new{n};
    if (length(st) == 1)
        ind_ = linvec(0, st*prod(sizeT(1:n-1)), sz);
    else
        ind_ = f_dehankel_vec(sz, st*prod(sizeT(1:n-1)));
        hFlag(n) = 1;
    end
    ind_t = reshape(ind_, [ones(1, l) [sz 1]]);
    ind = ind + ind_t; l = l + length(sz);
end
ind = ind + 1;

[T_, num_] = f_dehankel_mex(prod(sizeT), int64(ind(:)), complex(T_new(:)));
T.data = reshape(T_, [sizeT 1]);
T.missingInd = reshape(num_ == 0, [sizeT 1]);

end

%%
function out = linvec(init, step, n)
out = init + (0:step:(n-1)*step);
end

function T = f_dehankel_vec(sz, st)
ind = linvec(0, st(1), sz(1)).';
for n = 2:length(sz)
    ind_ = linvec(0, st(n), sz(n));
    ind_t = reshape(ind_, [ones(1, n-1) sz(n)]);
    ind = ind + ind_t;
end
T = ind;
end
