function U = f_vdm(generator, dim)
%% 由生成子矢量求范德蒙矩阵
R = numel(generator);
U = ones(dim,R);
for ii = 2:dim
    U(ii,:) = U(ii-1,:).*generator;
end
end