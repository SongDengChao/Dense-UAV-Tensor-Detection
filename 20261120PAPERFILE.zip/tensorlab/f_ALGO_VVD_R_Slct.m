function [V, w, L, relerr] = f_ALGO_VVD_R_Slct(vec, L_range)
V_cand = cell(length(L_range),1);
w_cand = V_cand;
fiterr = zeros(length(L_range),1);
for ll = 1:length(L_range)
    t_L = L_range(ll);    
    [t_V, t_w, fiterr(ll)] = f_ALGO_VVD_JEVD(vec, t_L);
    V_cand{ll} = t_V;
    w_cand{ll} = t_w;
end
cand = find(fiterr == min(fiterr));
L = L_range(cand);
V = V_cand{cand};
w = w_cand{cand};
relerr = fiterr(cand);
end

% function fval = f_EVAL_relerr(ten,ten_est)
% res_ten = ten - ten_est;
% fval = norm(res_ten(:),'fro')/norm(ten(:),'fro');
% end