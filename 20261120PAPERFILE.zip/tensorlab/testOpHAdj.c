#include "mex.h"
#include "matrix.h"

/* The gateway function */
void mexFunction( int nlhs, mxArray *plhs[],
                  int nrhs, const mxArray *prhs[])
{    
    int m = mxGetM(prhs[0]);
    int n = mxGetN(prhs[0]);
    plhs[0] = mxCreateDoubleMatrix((mwSize)(m+n-1),1,mxCOMPLEX);
    mxComplexDouble *x = mxGetComplexDoubles(prhs[0]);
    mxComplexDouble *y = mxGetComplexDoubles(plhs[0]);

    int ii, jj;
    for (ii = 0; ii < m; ii++) {
        for (jj = 0; jj < n; jj++) {
//           mexPrintf("i = %d, j = %d\n", ii, jj);
            y[ii+jj].real = y[ii+jj].real + x[jj*(int)m+ii].real;
            y[ii+jj].imag = y[ii+jj].imag + x[jj*(int)m+ii].imag;
        }
    }
    //#endif
}
