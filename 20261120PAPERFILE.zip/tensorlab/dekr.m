function B = dekr(krAB, A, flag)
if (size(krAB, 2) ~= size(A, 2))
    error("The dimesion dismatches.");
end
if (flag == 0)
    krAB_ = reshape(krAB, [], numel(A)) ./ A(:).';
    krAB_ = mean(reshape(krAB_.', size(A,1), []));
    B = reshape(krAB_, size(A,2), []).';
else
    krAB_ = reshape(krAB.', numel(A), []) ./ f_vec(A.');
    krAB_ = reshape(krAB_, size(A,2), []).';
    krAB_ = mean(reshape(krAB_, size(A,1), []));
    B = reshape(krAB_, [], size(A,2));
end
end

function out = f_vec(T)
out = T(:);
end