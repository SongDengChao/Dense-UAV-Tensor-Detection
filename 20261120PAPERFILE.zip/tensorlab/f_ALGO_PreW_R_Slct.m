function [mtx, PreW_data, U, S, V, R, fiterr] = f_ALGO_PreW_R_Slct(mtx_data, R_range)
R_lb = R_range(1);
R_ub = R_range(2);
[U,S,V] = f_svd(mtx_data,R_ub+2);
S = diag(S);
S_diff = -diff(S)./S(1:end-1);
S_diff_ = S_diff(R_lb:R_ub);
R = find(S_diff == max(S_diff_));
U = U(:,1:R); S = diag(S(1:R)); V = V(:,1:R);
mtx = U * S * V';
PreW_data = V';
fiterr = norm(mtx - mtx_data,'fro')/norm(mtx_data,'fro');
end

function [U,S,V] = f_svd(mtx,R)
sz = size(mtx);
if sz(1) == sz(2)
    [U,S,V] = svd(mtx);
    U = U(:,1:R);S = S(1:R,1:R);V = V(:,1:R);
elseif sz(1) < sz(2)
    t_mtx = mtx * mtx';
    [U,S,~] = svd(t_mtx);
    U = U(:,1:R);
    S = sqrt(S(1:R,1:R));
    V = (S\U')*mtx;
    V = V';
else
    t_mtx = mtx'*mtx;
    [V,S,~] = svd(t_mtx);
    V = V(:,1:R);
    S = sqrt(S(1:R,1:R));
    U = mtx*V/S;
end
end