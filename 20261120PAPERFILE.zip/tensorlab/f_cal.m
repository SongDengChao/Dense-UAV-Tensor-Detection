function [obj, relerr, That, cov, res_f, res_s] = f_cal(T, U, Z, D, Omega, sz, st, lambda, beta, nuclearFlag)

if (nargin < 10), nuclearFlag = true(1, length(U)); end
HU = cellfun(@f_hankel, U(nuclearFlag), sz, st, "UniformOutput", false);
S = cellfun(@f_pagesvd, HU, "UniformOutput", false);
obj_nuclear = sum(cellfun(@(x) sum(x(:)), S));

Lr = size(U{2},2)/size(U{1},2);
if (Lr > 1)
    A_ext = reshape(repmat(U{1}, Lr, 1), size(U{1},1), []);
else
    A_ext = U{1};
end
That = cpdgen([A_ext U(2:end)]);
obj_fit = lambda/2*frob(That(Omega)-T(Omega))^2;

obj_origin = obj_nuclear + obj_fit;

dUZ = cellfun(@minus, HU, Z, "UniformOutput", false);
DdUZ = cellfun(@inprod, D, dUZ);
obj_sum = sum(cellfun(@(x) sum(x(:)), cellfun(@f_pagesvd, Z, "UniformOutput", false)))...
    + obj_fit + beta/2 * frob(cellfun(@frob, dUZ))^2 + real(sum(DdUZ));

relerr = frob(That(Omega)-T(Omega))/frob(T(Omega));

Nf = size(U{1},1); N = length(U);
if (N == 3), T4 = T(:,:,end); That4 = That(:,:,end);
elseif (N == 4), T4 = reshape(T(:,:,:,end), Nf, []); That4 = reshape(That(:,:,:,end), Nf, []);
else, T4 = reshape(T(:,:,:,:,end), Nf, []); That4 = reshape(That(:,:,:,:,end), Nf, []);
end

U_f = U{1};
U_s = kr(U(end-1:-1:2)); U_s = reshape(U_s.', Lr, []);
if (any(size(U_s) == 1))
else
    U_s = sum(U_s);
end
U_s = reshape(U_s, size(U{1},2), []).';

obj.nuclear = obj_nuclear;
obj.fit = obj_fit;
obj.origin = obj_origin;
obj.sum = obj_sum;
if nargout > 2
    [cov, res_f, res_s] = calTarget(T4, That4, U_f, U_s);
end

end

function out = f_pagesvd(T)
[~, out, ~] = pagesvd(T, "econ", "vector");
end


