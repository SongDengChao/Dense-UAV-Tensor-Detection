function [U, relerr] = f_ALGO_CPD_VDM_JEVD(tensor, vdm_mode, R)
%% An algebraic algorithm for computing CPD with Vandermonde Structured factor matrices
%% Inputs:
% tensor: the data tensor to be decomposed.
% vdm_mode: An integer vector that indicates modes of the data tensor in which the CPD factor matrices have Vandermonde structure.
%           The largest number in vdm_mode should not exceed the order of the tensor; 
%           The vector vdm_mode should not contain repeating entries; 
%           The length of vdm_mode should not exceed the order of the tensor.
% R: Rank of the CPD model
%% Outputs:
% U: a 1 x N cell that contains the CPD factor matrices;
% relerr: the relative fitting error of the CPD model to the data tensor
sz = size(tensor);
N = length(sz);
U = cell(1,N);
vdm_order = length(vdm_mode);
non_vdm_mode = setdiff(1:N,vdm_mode);
seq = [vdm_mode,non_vdm_mode];
T1 = permute(tensor,seq);
sz = sz(seq);
UTU = ones(R,R);
core = zeros(R,R,vdm_order);
t_mtx = [];
t_sz = zeros(vdm_order,1);
for vv = 1:vdm_order
    order1 = setdiff(1:N-1,vv);    
    new_order = [order1,vv,N];    
    mtx = permute(T1,new_order);
    sz_1 = prod(sz(order1));
    mtx = reshape(mtx,[sz_1,sz(vv)*sz(N)]);
    if sz_1 > R
        [~,t_s,t_v] = f_svd(mtx,R);
        mtx = t_s * t_v';
        t_sz(vv) = R;
    else
        t_sz(vv) = sz_1;
    end
    mtx = reshape(mtx,[t_sz(vv),sz(vv),sz(N)]);
    mtx = reshape(mtx,[t_sz(vv)*sz(vv),sz(N)]);
    t_mtx = [t_mtx;mtx];     
end
% size(t_mtx)
[t_cpr_mtx, SS, U_cpr_3] = f_svd(t_mtx,R);
t_cpr_mtx = t_cpr_mtx * SS;
U_cpr_3 = conj(U_cpr_3);
offset = 0;
for vv = 1:vdm_order
    mtx = t_cpr_mtx(offset+1:offset+t_sz(vv)*sz(vv),:);
    U1 = mtx(1:(sz(vv)-1)*t_sz(vv),:);
    U2 = mtx((t_sz(vv)+1):sz(vv)*t_sz(vv),:);
    core(:,:,vv) = pinv(U1)*U2;
    offset = offset + t_sz(vv)*sz(vv);
end
%% Joint EVD
if vdm_order == 1
    [A_fac, Z] = eig(core);
    for rr = 1:R
        A_fac(:,rr) = A_fac(:,rr)/norm(A_fac(:,rr));
    end
    z = diag(Z).';
    z = z./abs(z);
    U{1} = f_vdm(z, sz(1));
    UTU = UTU.*(U{1}'*U{1});
else
    core(:,:,end+1) = eye(R);
    [eig_fac,~] = cpd_gevd(core,R);
    [eig_fac,~] = cpd3_sgsd(core,eig_fac);
    A_fac = eig_fac{1};
    for rr = 1:R
        A_fac(:,rr) = A_fac(:,rr)/norm(A_fac(:,rr));
    end
end
C_cpr = inv(A_fac.');
C = U_cpr_3 / (A_fac.');
U{N} = C;

%% Calculate the Vandermonde structured factor matrices
t_core = reshape(core,R^2,[]);
t_core = ((A_fac'*A_fac).*(C_cpr'*C_cpr)\(kr(C_cpr,A_fac)') * t_core).'; % vdm_order x R
for vv = 1:vdm_order
    t_angle = angle(t_core(vv,:));
    z = exp(1i*t_angle);
    U{vv} = f_vdm(z, sz(vv));
    UTU = UTU.*(U{vv}'*U{vv});
end
%     for vv = 1:vdm_order
%         t_z = core(:,:,vv)*A_fac./A_fac;
%         t_angle = mean(angle(t_z),1);
%         z = exp(1i*t_angle);
% %         t_z = mean(t_z,1);
% %         z = t_z./abs(t_z);
%         U{vv} = f_vdm(z, sz(vv));
%         UTU = UTU.*(U{vv}'*U{vv});
%     end   


%% Calculate non-Vandermonde structured matrices
ndm_order = length(non_vdm_mode);
T1 = reshape(T1,[],sz(N));
T1 = T1 * conj(U_cpr_3);
sz(N) = R;
T1 = reshape(T1,sz);
if ndm_order == 1
    sz_vdm = prod(sz(1:vdm_order));
    t_m = reshape(T1,sz_vdm,[]);
    vdm_kr = kr(U{vdm_order:-1:1});
    t_C = ((UTU\(vdm_kr'))*t_m).';
    co = diag(mean(t_C./C_cpr,1));
    C_cpr = C_cpr * co;
    C = U_cpr_3 * C_cpr;
    U{N} = C;
else % ndm_order > 1
    sz_abo = prod(sz(1:N-1)); % abo = all but one    
    ndm_ind = vdm_order+1:N-1;
    ndm_sz = prod(sz(ndm_ind));
    ndm_kr = zeros(ndm_sz,R);
    new_order = [vdm_order+1:N-1,1:vdm_order,N];
    T1 = permute(T1,new_order);
    t_m = reshape(T1,sz_abo,[]);
    t_mtx = t_m * A_fac;
    for rr = 1:R
        t_kr = t_mtx(:,rr);
        I_mtx = eye(ndm_sz);
        t_vdm_kr = 1;
        for vv = 1:vdm_order
            t_a = U{vv}(:,rr);
            t_a = t_a'/norm(t_a);
            t_vdm_kr = kron(t_a,t_vdm_kr);
        end
        t_vdm_kr = kron(t_vdm_kr,I_mtx);
        ndm_kr(:,rr) = t_vdm_kr * t_kr;
    end
    t_sz = sz(ndm_ind);
    t_mtx = ndm_kr;
    t_ind = vdm_order+1;
    while length(t_sz) > 1
        sz_1 = t_sz(1);
        sz_r = prod(t_sz(2:end));
        [U{t_ind},U_r] = f_colwise_rank1(t_mtx,sz_1,sz_r);
        t_sz(1) = [];
        t_mtx = U_r;
        t_ind = t_ind + 1;
    end
    U{t_ind} = t_mtx;    
end

seq1(seq) = 1:N;
U = U(seq1);

tmp = cellfun(@(U) U'*U, U, 'UniformOutput',false);
% U{end} = U{end} .* (inv(prod(cat(3,tmp{:}),3)) * squeeze(sum(sum(sum(tensor.*conj(reshape(U{1},size(U{1},1),1,1,[])),1) .* conj(reshape(U{2},1,size(U{2},1),1,[])), 2) .* conj(reshape(U{3},1,1,size(U{3},1),[])),3))).';
U{end} = U{end} .* (pinv(kr(U(end:-1:1)))*tensor(:)).';%    ��������ģ�� ����QuaDriGaʵ��

relerr = f_relerr(U, tensor);
end

function U = f_vdm(generator, dim)
%% ��������ʸ���󷶵��ɾ���
R = numel(generator);
U = ones(dim,R);
for ii = 2:dim
    U(ii,:) = U(ii-1,:).*generator;
end
end

function [U_l,U_r] = f_colwise_rank1(mtx, sz_l, sz_r)
%% �Ծ���mtx��ÿһ�н���������һ�ƽ�
R = size(mtx,2);
U_l = zeros(sz_l,R);
U_r = zeros(sz_r,R);
for rr = 1:R
    t_mtx = reshape(mtx(:,rr),[sz_l,sz_r]);
    [U,S,V] = svd(t_mtx);
    U_l(:,rr) = U(:,1);
    U_r(:,rr) = S(1,1)*conj(V(:,1));
end
end

function fval = f_relerr(U, tensor)
%% ���㵱ǰ�����Ĵ��ۺ���ֵ
resten = cpdgen(U) - tensor;
fval = sqrt((resten(:)'*resten(:))/(tensor(:)'*tensor(:)));
end

function [U,S,V] = f_svd(mtx,R)
sz = size(mtx);
if sz(1) == sz(2)
    [U,S,V] = svd(mtx);
    U = U(:,1:R);S = S(1:R,1:R);V = V(:,1:R);
elseif sz(1) < sz(2)
    t_mtx = mtx * mtx';
    [U,S,~] = svd(t_mtx);
    U = U(:,1:R);
    S = sqrt(S(1:R,1:R));
    V = (S\U')*mtx;
    V = V';
else
    t_mtx = mtx'*mtx;
    [V,S,~] = svd(t_mtx);
    V = V(:,1:R);
    S = sqrt(S(1:R,1:R));
    U = mtx*V/S;
end
end

function [U,S] = f_ALGO_RSVD(mtx,R,P,Q)
%% find the first R right singular vectors of a matrix with more columns than rows
[~,J] = size(mtx);
% if I > J
%     error('The matrix should have more columns than rows');    
% end
test_mtx = randn(J,R + P);
Y = mtx*test_mtx;
if Q > 0
    for jj = 1:Q
        [Q_tmp, ~] = lu(Y);
        [Z, ~] = lu(mtx.'*Q_tmp);
        Y = mtx*Z;
    end
end
[U,S,~] = svd(Y);
% [U,~,~] = f_ALGO_SVD(Y);
U = U(:,1:R);
end