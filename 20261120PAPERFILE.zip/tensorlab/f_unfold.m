 function mtx = f_unfold(tensor, n)
%% To do a n-mode matrix unfolding of tensor
tsize = size(tensor);
N = length(tsize);    % the dimensionality of tensor
ndim = n;
cdim = setdiff(N:-1:1,ndim);
ten = permute(tensor,[ndim,cdim]);
mtx = reshape(ten,tsize(ndim),prod(tsize(cdim)));
end