function T = f_dimdismerge(T_new, sizeT, varargin)

if isempty(varargin)
    error("Please input the dimension to dismerge.");
end
if length(varargin) == 1
    varargin = varargin{1};
end
if (iscell(varargin))
    order = cell2mat(varargin);
else
    order = varargin;
end

order = unique(order, 'stable');
if (length(sizeT) ~= length(order))
    error("The dimesion dismatches.");
end

sizeT_ = sizeT(order);
T_ = reshape(T_new, sizeT_);

T = ipermute(T_, order);

end