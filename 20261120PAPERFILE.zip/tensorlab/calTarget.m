function [cov, res_f, res_s] = calTarget(T4, That4, U_f, U_s)
Nf = size(T4, 1);

cov = zeros(1, Nf);
for ff = 1:Nf
    temp1 = T4(ff, :);
    temp2 = That4(ff, :);
    cov(ff) = abs(temp1*temp2') / frob(temp1) / frob(temp2);
end
res_f = zeros(1, Nf); res_s = zeros(1, Nf);
if nargin > 2
    % proj = U_f / (U_f' * U_f) * U_f';
    proj = U_f * pinv(U_f' * U_f) * U_f';
    res = T4 - proj * T4;
    for ff = 1:Nf
        res_f(ff) = 10*log10(frob(res(ff,:))/frob(T4(ff,:)));
    end

    % proj = U_s / (U_s'*U_s) * U_s';
    proj = U_s * pinv(U_s'*U_s) * U_s';

    res = T4.' - proj * T4.';
    for ff = 1:Nf
        res_s(ff) = 10*log10(norm(res(:,ff))/norm(T4(ff,:)));
    end
    res_s(res_s == NaN) = eps;

end

end