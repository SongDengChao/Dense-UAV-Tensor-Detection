function T_new = f_dimmerge(T, varargin)

if isempty(varargin)
    error("Please input the dimension to merge.");
end
if length((varargin)) == 1
    varargin = varargin{1};
end
if (iscell(varargin))
    order = cell2mat(varargin);
else
    order = varargin;
end

sizeT = size(T);
order = unique(order, 'stable');
if (length(sizeT) ~= length(order))
    error("The dimesion dismatches.");
end

T_ = permute(T, order);
sizeT_new = zeros(1, length(varargin));
for n = 1:length(varargin)
    sizeT_new(n) = prod(sizeT(varargin{n}));
end

T_new = reshape(T_, sizeT_new);

end