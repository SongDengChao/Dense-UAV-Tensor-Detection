function fig = view_cfarsep_pd_f1(varargin)
% VIEW_CFARSEP_PD_F1 Preview OS-CFAR Pd/F1 for three scene layouts.
% view_cfarsep_pd_f1
% view_cfarsep_pd_f1('Save',true) exports FIG, PNG and vector PDF.
root = fileparts(mfilename('fullpath'));
p = inputParser;
addParameter(p,'Folder',fullfile(root,'Figures','cfarsep20261027','20261027_163648'),@(x)ischar(x)||isstring(x));
addParameter(p,'Save',false,@(x)islogical(x)&&isscalar(x));
parse(p,varargin{:});
folder = char(p.Results.Folder);
T = readtable(fullfile(folder,'summary.csv'),'TextType','string');
cases = ["single_offgrid","separated","cluster"];
labels = ["Single","Separated","Dense"];
method = "OS-CFAR";
markers = {'o','s','^'};
colors = [0.05 0.55 0.28; 0.05 0.35 0.80; 0.85 0.22 0.08];
fig = figure('Color','w','Units','centimeters','Position',[3 3 8.9 5.6],...
    'Name','CFAR validation: UAV Pd and F1','NumberTitle','off');
tl = tiledlayout(fig,1,2,'TileSpacing','loose','Padding','compact');
fields = {'PdBody','F1Body'};
ylabels = {'(a) P_d','(b) F1 score'};
handles = gobjects(3,1);
for panel = 1:2
    ax = nexttile(tl); hold(ax,'on');
    for c = 1:3
            rows = T.Case==cases(c) & T.Method==method & isfinite(T.SNR);
            if ~any(rows), error('CFARSep:MissingData','Missing %s / %s.',cases(c),method); end
            [x,order] = sort(T.SNR(rows));
            y = T.(fields{panel})(rows); y = y(order);
            if numel(unique(x))~=numel(x)
                error('CFARSep:DuplicateSNR','Expected one row per SNR and case/method.');
            end
            h = plot(ax,x,y,'Color',colors(c,:),'LineStyle','-',...
                'Marker',markers{c},'MarkerIndices',1:5:numel(x),...
                'MarkerSize',3.5,'LineWidth',1.0);
            if panel==1, handles(c)=h; end
    end
    set(ax,'FontName','Times New Roman','FontSize',8,'LineWidth',0.6,...
        'XLim',[-30 25],'XTick',[-30 -10 10 25],'YLim',[0 1.04],...
        'YTick',[0 0.5 1],'Box','on','GridAlpha',0.15);
    grid(ax,'on'); xlabel(ax,'SNR (dB)'); ylabel(ax,ylabels{panel});
end
lg = legend(handles,labels,'NumColumns',3,'Box','off',...
    'FontName','Times New Roman','FontSize',8,'Interpreter','none');
lg.Layout.Tile = 'south';
fig.UserData = struct('source',fullfile(folder,'summary.csv'),...
    'metrics',{fields},'method',method,'cases',cases);
drawnow;
if p.Results.Save
    base = fullfile(folder,'pd_f1_single_column');
    savefig(fig,[base '.fig']);
    exportgraphics(fig,[base '.png'],'Resolution',600);
    exportgraphics(fig,[base '.pdf'],'ContentType','vector');
end
end
