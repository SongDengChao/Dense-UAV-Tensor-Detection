function [figures,slices] = view_run06_sectionB(sValues,varargin)
% VIEW_RUN06_SECTIONB Preview SNR slices with a shared 2-row, 4-column legend.
% No simulations are rerun and no figures or source files are saved/modified.
%
% Interactive spacing selection:
%   view_run06_sectionB
% One window, six metrics in a 2-by-3 layout:
%   view_run06_sectionB(1)
% Three rows, two columns:
%   view_run06_sectionB(1,'Layout',[3 2])
% One six-panel window per spacing:
%   view_run06_sectionB([0.5 1 3])
% Select a subset/order of metrics:
%   view_run06_sectionB(1,'Metrics',{'Pd','F1','UAVCOUNT','UAVCOUNTACC','TIME','OSPA'})
% Use a different run:
%   view_run06_sectionB(1,'JointFolder','E:\path\runXX\joint')

if nargin<1, sValues=[]; end
defaultFolder=fullfile(fileparts(mfilename('fullpath')),'Figures',...
    'version202610261542','run06','joint');
p=inputParser;
addParameter(p,'JointFolder',defaultFolder,@(x)ischar(x)||(isstring(x)&&isscalar(x)));
addParameter(p,'Metrics',{'Pd','F1','UAVCOUNT','UAVCOUNTACC','TIME','OSPA'},@(x)iscellstr(x)||isstring(x)||ischar(x));
addParameter(p,'Layout',[2 3],@(x)isnumeric(x)&&isreal(x)&&isequal(size(x),[1 2])&&...
    (isequal(x,[2 3])||isequal(x,[3 2])));
addParameter(p,'MarkerEvery',2,@(x)isnumeric(x)&&isscalar(x)&&isfinite(x)&&x>=1&&fix(x)==x);
parse(p,varargin{:});
folder=char(p.Results.JointFolder);
metrics=upper(string(p.Results.Metrics)); metrics=metrics(:).';
metrics(metrics=="RUNTIME")="TIME";
allowed=["PD","F1","UAVCOUNT","UAVCOUNTACC","TIME","OSPA"];
if isempty(metrics)||numel(metrics)>6||any(~ismember(metrics,allowed))||numel(unique(metrics))~=numel(metrics)
    error('SectionB:Metrics','Select up to six unique metrics: Pd, F1, UAVCOUNT, UAVCOUNTACC, TIME, OSPA.');
end
files={'Pd_overlay.fig','F1_overlay.fig','UAV_count_overlay.fig',...
    'UAV_count_acc_overlay.fig','Runtime_median_overlay.fig','OSPA_overlay.fig'};
labels={'Detection probability','F1 score','Mean estimated UAV count',...
    'Correct UAV-count probability','Median reconstructed time (s)','OSPA'};
base=read_overlay_local(fullfile(folder,files{1}));
if numel(base.keys)~=8
    error('SectionB:Methods','Expected eight methods for the two-row, four-column legend.');
end
if isempty(sValues)
    choices=arrayfun(@(v)sprintf('s = %g',v),base.spacing,'UniformOutput',false);
    [~,initial]=min(abs(base.spacing-1));
    [selected,ok]=listdlg('PromptString','Select spacing scale(s); one window per s',...
        'ListString',choices,'SelectionMode','multiple','InitialValue',initial,'ListSize',[330 180]);
    if ~ok, figures=gobjects(0); slices=struct([]); return; end
    sValues=base.spacing(selected);
end
validateattributes(sValues,{'numeric'},{'vector','real','finite','nonempty'});
sValues=unique(sValues(:).','stable');
indices=zeros(size(sValues));
for j=1:numel(sValues)
    [distance,indices(j)]=min(abs(base.spacing-sValues(j)));
    if distance>1e-9*max(1,max(abs(base.spacing)))
        error('SectionB:Spacing','s=%g is not a saved node. Available nodes: %s. No interpolation is performed.',...
            sValues(j),mat2str(base.spacing));
    end
end
grids=struct(); correctedF1=false;
for metric=metrics
    pos=find(allowed==metric);
    if metric=="PD", data=base; else, data=read_overlay_local(fullfile(folder,files{pos})); end
    check_grid_local(base,data);
    grids.(char(metric))=data.values;
end
if any(metrics=="F1")
    % Original F1 contains undefined 0/0 nodes. Compute F1 directly from counts.
    tp=read_overlay_local(fullfile(folder,'TP_overlay.fig'));
    fp=read_overlay_local(fullfile(folder,'FA_overlay.fig'));
    check_grid_local(base,tp); check_grid_local(base,fp);
    ratios=[];
    for j=1:numel(base.keys)
        key=base.keys{j}; recall=double(base.values.(key)); counts=double(tp.values.(key));
        valid=isfinite(recall)&isfinite(counts)&recall>0;
        ratios=[ratios;counts(valid)./recall(valid)]; %#ok<AGROW>
    end
    if isempty(ratios)||max(abs(ratios-round(median(ratios))))>1e-7||median(ratios)<1
        error('SectionB:TruthCount','Cannot infer a constant true UAV count from saved TP and Pd grids.');
    end
    truthCount=round(median(ratios));
    for j=1:numel(base.keys)
        key=base.keys{j};
        grids.F1.(key)=2*tp.values.(key)./(truthCount+tp.values.(key)+fp.values.(key));
    end
    correctedF1=true;
    fprintf('F1 preview uses count-based 2TP/(Ntrue+TP+FP), Ntrue=%g; zero-TP nodes are 0. Source FIGs unchanged.\n',truthCount);
end
colors=[.05 .65 .85;.05 .35 .65;.75 .18 .08;.55 .08 .78;...
    .72 .35 .78;.38 .26 .63;.85 .15 .55;.72 .08 .4];
markers={'>','s','p','d','v','h','*','x'};
figures=gobjects(numel(sValues),1); slices=struct([]);
for j=1:numel(sValues)
    s=base.spacing(indices(j));
    nr=p.Results.Layout(1); nc=p.Results.Layout(2);
    if nr==2, figurePosition=[70 70 1450 840];
    else, figurePosition=[100 40 1130 980]; end
    fig=figure('Color','w','Visible','on','NumberTitle','off',...
        'Name',sprintf('Section IV-B | s = %g | preview only',s),...
        'Position',figurePosition);
    layout=tiledlayout(fig,nr,nc,'TileSpacing','compact','Padding','compact');
    handles=gobjects(8,1); vectors=struct();
    for m=1:numel(metrics)
        metric=char(metrics(m)); pos=find(allowed==metrics(m));
        ax=nexttile(layout); hold(ax,'on');
        for k=1:8
            key=base.keys{k}; y=double(grids.(metric).(key)(indices(j),:));
            vectors.(metric).(key)=y;
            if strcmp(metric,'TIME'), y(y<=0)=NaN; end
            h=plot(ax,base.snr,y,'Color',colors(k,:),'Marker',markers{k},...
                'LineStyle','-','LineWidth',1.2,'MarkerSize',5,...
                'MarkerIndices',1:p.Results.MarkerEvery:numel(base.snr),...
                'DisplayName',base.names{k},'Tag',key);
            if m==1, handles(k)=h; end
        end
        xlabel(ax,'SNR (dB)');
        ylabel(ax,sprintf('(%c) %s','a'+m-1,labels{pos}));
        ax.FontSize=10; ax.XGrid='on'; ax.YGrid='on'; ax.GridAlpha=.15; box(ax,'on');
        xlim(ax,[min(base.snr) max(base.snr)]);
        switch metric
            case {'PD','F1','UAVCOUNTACC'}
                ylim(ax,[0 1.02]);
            case 'UAVCOUNT'
                ymax=max(arrayfun(@(k) max(vectors.UAVCOUNT.(base.keys{k}),[],'omitnan'),1:8));
                ylim(ax,[0 max(7,1.08*ymax)]);
                if correctedF1
                    yline(ax,truthCount,'--','Color',[.4 .4 .4],...
                        'HandleVisibility','off','LineWidth',.9);
                end
            case 'TIME'
                ax.YScale='log';
            case 'OSPA'
                ymax=max(arrayfun(@(k) max(vectors.OSPA.(base.keys{k}),[],'omitnan'),1:8));
                ylim(ax,[0 max(3,1.03*ymax)]);
        end
    end
    title(layout,sprintf('Spacing scale s = %g',s),'FontSize',12,'FontWeight','normal');
    lg=legend(handles,base.names,'NumColumns',4,'Orientation','horizontal',...
        'Interpreter','none','FontSize',10,'Box','off');
    lg.Layout.Tile='south';
    item=struct('sourceFolder',folder,'spacing',s,'snr',base.snr,...
        'metrics',metrics,'methodKeys',{base.keys},'methodNames',{base.names},...
        'values',vectors,'F1FromCounts',correctedF1,'layout',p.Results.Layout,...
        'runtimeDefinition','Median reconstructed common-fit protocol cost, not independent runtime');
    fig.UserData=item; figures(j)=fig;
    if isempty(slices), slices=item; else, slices(end+1)=item; end %#ok<AGROW>
    fprintf('Opened s=%g: %s. Preview only; no files saved.\n',s,strjoin(metrics,', '));
end
end

function data=read_overlay_local(file)
if ~isfile(file), error('SectionB:Missing','Missing FIG: %s',file); end
fig=openfig(file,'new','invisible'); cleanup=onCleanup(@()close(fig));
meta=fig.UserData;
required={'snrValues','spacingValues','methodKeys','methodNames','displayedValues'};
if ~isstruct(meta)||~all(isfield(meta,required))
    error('SectionB:Metadata','FIG does not contain the expected saved grid metadata: %s',file);
end
data=struct('snr',double(meta.snrValues(:).'),'spacing',double(meta.spacingValues(:).'),...
    'keys',{cellstr(string(meta.methodKeys(:))).'},...
    'names',{cellstr(string(meta.methodNames(:))).'},'values',meta.displayedValues);
for k=1:numel(data.keys)
    if ~isfield(data.values,data.keys{k})||...
            ~isequal(size(data.values.(data.keys{k})),[numel(data.spacing) numel(data.snr)])
        error('SectionB:Shape','Invalid grid dimensions in %s.',file);
    end
end
end

function check_grid_local(a,b)
if ~isequal(a.snr,b.snr)||~isequal(a.spacing,b.spacing)||~isequal(a.keys,b.keys)
    error('SectionB:GridMismatch','Selected metric FIGs have different grids or method orders.');
end
end
