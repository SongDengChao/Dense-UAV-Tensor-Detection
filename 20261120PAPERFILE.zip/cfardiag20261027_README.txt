CFAR-only diagnostic for version202610261542

Run in MATLAB:
  test_cfar_diag_20261027

Files:
  test_cfar_diag_20261027.m : editable small experiment settings
  f_cfar_diag_20261027.m    : standalone runner and copied 1542 detector helpers

Default experiment:
  5 MC trials per condition; SNR = [-10 0 10 20 25 Inf] dB
  Cluster spacing = [0.5 1 3]
  Single integer-bin UAV; single off-grid UAV; original 6 UAV + 3 object scene
  Extra noise-only control. 155 generated trials, each evaluated by CA/OS-CFAR.
  Inf means no additive noise, not infinite signal amplitude.
  This is a diagnostic pilot, not a statistically precise performance estimate.

All active CA/OS-CFAR and model-decision helpers are copied unchanged from 1542.
No CPD, rankest, MUSIC or Tensorlab is invoked. No output merging is performed.
Calibration retains 128 training and 16 validation noise frames.
Original files and results are not modified.

Output:
  Figures/cfardiag20261027/<timestamp>/
  01_stages.png/.fig : cluster candidate coverage, classification and final Pd
  02_controls.png/.fig : single-target and ideal-factor checks
  summary.csv, trials.csv, targets.csv, candidates.csv, controls.csv, results.mat
  Checkpoint saved every 10 generated trials.

Interpretation:
  BodyRDCoverage: a body-near range/Doppler candidate exists after peak selection.
  Body3DCoverage: such a candidate also meets the angle gate.
  PassGiven3DCoverage: conditional UAV pass rate among covered true targets.
  Coverage counts are per-truth existence and need not be one-to-one.
  PdBody: one-to-one original greedy evaluation against body coordinates only.
  PdLegacy: original 1542 CFAR evaluation, allowing body or harmonic-sideband match.
  FABody/FALegacy: unmatched UAV outputs under the corresponding scoring rule.
  TruthLocalPass: known true angle/nearest range/nearest body center in the mixture.
  IdealFactorPass: isolated noiseless slow-time factor with the same Hann/model rule.
  Truth-directed probes are diagnostic controls only, not deployable detectors.
  targets.csv includes threshold ratios and local maxima before peak suppression.
  candidates.csv includes E0, E1, BIC gain, relative gain, sideband fraction and label.
  NaN conditional rates mean no denominator, not failure probability zero.

Execution status at creation:
  MATLAB batch launch was attempted but failed with MathWorks service error 5201.
  No simulated performance results are claimed until this script runs successfully.
