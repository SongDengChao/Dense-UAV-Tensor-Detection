% Small separated-versus-dense CFAR validation. No Tensorlab required.
codeRoot=fileparts(mfilename('fullpath'));
addpath(codeRoot);
cfg=struct('numMC',20,'snr',(-30:1:25),'spacing',1);
cfg.outputRoot=fullfile(codeRoot,'Figures','cfarsep20261027');
diagnosticResult=f_cfar_separation_20261027(cfg);
