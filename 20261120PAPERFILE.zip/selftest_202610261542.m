%% Quick diagnostics; does not launch the SNR/spacing sweep.
clear; clc;
codeFolder=fileparts(mfilename('fullpath'));
addpath(codeFolder);
legacy='E:\Academic Research\DoctorPeriod\MYPAPER\RANK1-APPROXIMATION-VDM-LOW-SNR-CALCULATING\CodeFile';
if exist(legacy,'dir'), addpath(legacy); end
if exist(fullfile(legacy,'tensorlab'),'dir'), addpath(fullfile(legacy,'tensorlab')); end
addpath(codeFolder);

syntaxFunctions=checkcode(fullfile(codeFolder,'f_newtype_202610261542.m'),'-id');
syntaxMain=checkcode(fullfile(codeFolder,'test_202610261542.m'),'-id');
disp('Code Analyzer messages (legacy warnings may be present):');
disp(struct2table(syntaxFunctions));
disp(struct2table(syntaxMain));

cfg=struct();
cfg.raw.calibrationFrames=8;
cfg.raw.calibrationValidationFrames=4;
% Reduced noise calibration is for diagnostics only, not performance figures.
modelReport=f_newtype_202610261542('modeltest',cfg);
disp(modelReport.cases);
disp(modelReport);

runEightMethodSmokeTest=false; % Set true to also run real Tensorlab CPD.
if runEightMethodSmokeTest
 smoke=f_newtype_202610261542('selftest',cfg);
 disp(smoke);
end
disp('Model diagnostic finished. This is not a full MC validation.');
