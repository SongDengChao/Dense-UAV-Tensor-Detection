function out = f_newtype_202610261542(Nu, Nc, Nn, SNR_dB, numMC, opts)
% Output proximity merging is disabled by default; evaluation matching is unchanged.
% Eight-method shared-fit RAW-domain CPD comparison. FFT is applied only to fitted factors.
% FMCW dechirped I/Q synthesis; no Gaussian spectral kernels in active paths.
% Eight-method paired comparison with shared CPD and reconstructed conditional costs.
% Runtime includes the full CFAR preprocessing needed by each implementation.
% Data synthesis, metric evaluation, plotting, and file I/O are excluded.
% CFAR candidates initialize the proposed rank without truth-count fallback.
% CA-CFAR initializes ranks; OS-CFAR and OS-CFAR-CLEAN use fixed candidate positions.
% Continuous-frequency single-tone/harmonic model competition replaces width/peak vetoes.
% One noise-only growth step with a small residual gain triggers rollback
% to the complete fit at the previous rank.

% Utility call prepares physical settings and noise-only CFAR calibration once.
if nargin==2 && (ischar(Nu) || isstring(Nu))
    action=lower(char(Nu));
    if ~ismember(action,{'prepare','selftest','modeltest'}), error('RawFMCW:Action','Unknown utility action.'); end
    out=model_defaults_1542_local(raw_fill_default_opts_local(timed_fill_default_opts(fill_wrapper_defaults(Nc))));
    if strcmp(action,'selftest'), out=raw_selftest_local(out); end
    if strcmp(action,'modeltest'), out=model_selftest_1542_local(out); end
    return;
end
if nargin < 6
    opts = struct();
end
opts = model_defaults_1542_local(raw_fill_default_opts_local(timed_fill_default_opts(fill_wrapper_defaults(opts))));
validateattributes(numMC,{'numeric'},{'scalar','integer','positive'});
opts.saveDataTensor = true;
if exist('rankest','file') ~= 2
    error('Cannot find Tensorlab rankest.m. Add the Tensorlab folder to the MATLAB path.');
end

% Process one MC realization at a time; never retain full grid tensors.

methodKeys = {'osCfar','osCfarClean','jointMusic','proposed','rankestTensor','rankestPlateauTensor','oracleTensor','redundantTensor'};
methodNames = {'OS-CFAR','OS-CFAR-CLEAN','MDL-Joint MUSIC','Proposed framework','Rankest-CPD','Plateau-Rankest-CPD','Oracle-rank CPD','Redundant-rank CPD'};

out = struct();
out.inputs = struct('Nu',Nu,'Nc',Nc,'Nn',Nn,'SNR_dB',SNR_dB,'numMC',numMC);
out.opts = opts;
out.scene = cell(numMC,1);
out.methodKeys = methodKeys;
out.methodNames = methodNames;
out.methods = struct();
out.metricPerMC = table();
out.sharedAudit=cell(numMC,1);
out.runtimePerMC = table();
out.inputDomain = "unwindowed array x fast-time x slow-time I/Q tensor";
out.rawConfiguration=opts.raw;
out.cfarCalibration=opts.rawCFARCalibration;
out.runtimeDefinition = "Reconstructed common-fit protocol cost, NOT independent wall-clock runtime. ActualIncrementalSeconds depends on cache/order. Common fits may use predecessor initialization; independent benchmarks are still required.";

agg = struct();
for mm = 1:numel(methodKeys)
    key = methodKeys{mm};
    agg.(key) = init_metric_aggregate_local();
    out.methods.(key) = cell(numMC,1);
end

for mc = 1:numMC
    if isempty(opts.seed)
        error('PairedGrid:SeedRequired','A nonempty seed is required for paired grid trials.');
    end
    rng(opts.seed + mc - 1,'twister');
    trialOpts = opts;
    trialOpts.noiseSeed = opts.seed + 10000000 + mc - 1;
    trialOpts.solverSeed = opts.seed + 20000000 + mc - 1;
    shared_cpd_1542_local('reset',trialOpts);
    shared_cpd_1542_local('begin','proposed');
    cacheCleanup=onCleanup(@() shared_cpd_1542_local('clear'));
    trialWall=tic;
    one = timed_run_one_trial(Nu,Nc,Nn,SNR_dB,trialOpts);
    trueUAV = one.trueUAV;
    trueClutter = one.trueClutter;
    X = one.X;
    trad = one.traditional;
    prop = one.tensor;
    proposedLedger=shared_cpd_1542_local('ledger');
    out.scene{mc} = struct('trueUAV',trueUAV,'trueClutter',trueClutter, ...
        'definition',one.sceneDefinition,'noiseAudit',one.noiseAudit);
    prop.SNR_dB = SNR_dB;

    for mm = 1:numel(methodKeys)
        key = methodKeys{mm};
        name = methodNames{mm};

        if ~strcmp(key,'proposed'), shared_cpd_1542_local('begin',key); end
        methodTimer = tic;
        frontEndSeconds = trad.runtimeSeconds;
        switch key
            case 'cfar'
                oneMethod = trad;
                sidebandAware = true;
            case 'cfarSubspace'
                oneMethod = run_cfar_subspace_refinement_framework_3d(X, trad, opts);
                sidebandAware = true;
            case 'cfarClean'
                oneMethod = run_cfar_clean_framework_3d(X, trad, opts);
                sidebandAware = true;
            case 'proposed'
                oneMethod = run_energy_assisted_tensor_framework_local(prop, opts);
                sidebandAware = false;
            case 'rankestTensor'
                oneMethod = run_rankest_tensor_framework_local(X, trad, SNR_dB, mc, opts);
                sidebandAware = false;
            case 'rankestPlateauTensor'
                oneMethod = run_rankest_tensor_framework_local(X, trad, SNR_dB, mc, opts, true);
                sidebandAware = false;
            case 'osCfar'
                oneMethod = run_os_cfar_framework_local(one.X_cfar, opts);
                frontEndSeconds = one.cfarFFTSeconds;
                sidebandAware = true;
            case 'osCfarClean'
                oneMethod = run_os_cfar_clean_framework_local(one.X_cfar, opts);
                frontEndSeconds = one.cfarFFTSeconds;
                sidebandAware = true;
            case 'jointMusic'
                oneMethod = run_joint_music_framework_local(one.X_music, opts);
                frontEndSeconds = one.musicFFTSeconds;
                sidebandAware = false;
            case 'redundantTensor'
                totalPhysicalCount = height(trueUAV) + height(trueClutter);
                oneMethod = run_redundant_tensor_framework_local(X, trad, totalPhysicalCount, SNR_dB, mc, opts);
                sidebandAware = false;
            case 'oracleTensor'
                oracleRank = height(trueUAV) + height(trueClutter);
                oneMethod = run_oracle_tensor_framework_local(X, trad, oracleRank, SNR_dB, mc, opts);
                sidebandAware = false;
            otherwise
                error('Unknown framework key: %s', key);
        end

        methodSeconds = toc(methodTimer);
        if strcmp(key, 'proposed')
            preprocessingSeconds = prop.runtimeSeconds;
        else
            preprocessingSeconds = frontEndSeconds;
        end
        actualSeconds=preprocessingSeconds+methodSeconds;
        ledger=shared_cpd_1542_local('ledger');
        if strcmp(key,'proposed'), ledger=proposedLedger; end
        adjustment=ledger.nominalSeconds-ledger.newComputeSeconds;
        oneMethod.actualIncrementalRuntimeSeconds=actualSeconds;
        oneMethod.runtimeSeconds=max(0,actualSeconds+adjustment);
        oneMethod.sharedTiming=ledger;
        if isfield(oneMethod,'rankInfo') && isfield(oneMethod.rankInfo,'elapsedSeconds')
            oneMethod.rankInfo.elapsedSeconds=max(0,oneMethod.rankInfo.elapsedSeconds+adjustment);
        end
        oneMethod.runtimeBreakdown = struct('preprocessingSeconds', preprocessingSeconds, ...
            'additionalProcessingSeconds', methodSeconds, 'cfarSeconds', frontEndSeconds);
        out.runtimePerMC = [out.runtimePerMC; ...
            table(mc, string(key), string(name), oneMethod.runtimeSeconds, ...
            preprocessingSeconds, methodSeconds, actualSeconds, ledger.fitSeconds, ledger.interpretSeconds, ...
            'VariableNames', {'MC','MethodKey','Method','RuntimeSeconds', ...
            'PreprocessingSeconds','AdditionalProcessingSeconds','ActualIncrementalSeconds', ...
            'SharedCPDNominalSeconds','SharedInterpretNominalSeconds'})]; %#ok<AGROW>

        if sidebandAware
            metrics = evaluate_detection_metrics_local(oneMethod.uavEstimate, trueUAV, opts.successThreshold, true);
        else
            metrics = evaluate_detection_metrics_local(oneMethod.uavEstimate, trueUAV, opts.successThreshold, false);
        end
        extraMetrics = evaluate_cluster_extra_metrics_local(oneMethod.uavEstimate, trueUAV, trueClutter, opts.successThreshold, opts.ospa, sidebandAware, metrics);
        metrics.Pd_UAV = extraMetrics.Pd_UAV;
        metrics.Pfa_UAV = extraMetrics.Pfa_UAV;
        metrics.uavCountCorrect = extraMetrics.uavCountCorrect;
        metrics.uavCountErrorAbs = extraMetrics.uavCountErrorAbs;
        metrics.OSPA_UAV = extraMetrics.OSPA_UAV;
        metrics.OSPA_UAV_loc = extraMetrics.OSPA_UAV_loc;
        metrics.OSPA_UAV_card = extraMetrics.OSPA_UAV_card;
        metrics.nonUAVCount = extraMetrics.nonUAVCount;
        metrics.nonUAVAsUAV = extraMetrics.nonUAVAsUAV;
        oneMethod.metrics = metrics;
        oneMethod.methodName = string(name);
        oneMethod.extraMetrics = extraMetrics;
        oneMethod.confusionMetrics = evaluate_confusion_local(oneMethod.uavEstimate, trueUAV, trueClutter, opts.successThreshold, sidebandAware);

        out.methods.(key){mc} = oneMethod;
        agg.(key) = update_metric_aggregate_local(agg.(key), metrics);
        out.metricPerMC = [out.metricPerMC; metrics_to_row_local(mc, string(name), metrics)]; %#ok<AGROW>
    end
    out.sharedAudit{mc}=shared_cpd_1542_local('audit');
    out.sharedAudit{mc}.trialWallIncludingSynthesisAndMetrics=toc(trialWall);
    clear cacheCleanup;
end

out.summary.methods = struct();
for mm = 1:numel(methodKeys)
    key = methodKeys{mm};
    out.summary.methods.(key) = finalize_metric_aggregate_local(agg.(key), numMC);
    trialSeconds = cellfun(@(item) item.runtimeSeconds, out.methods.(key));
    validSeconds = trialSeconds(isfinite(trialSeconds));
    if isempty(validSeconds)
        medianSeconds = NaN;
        meanSeconds = NaN;
    else
        medianSeconds = median(validSeconds);
        meanSeconds = mean(validSeconds);
    end
    out.summary.methods.(key).runtimeMedianSeconds = medianSeconds;
    out.summary.methods.(key).runtimeMeanSeconds = meanSeconds;
    out.summary.methods.(key).runtimeNumTrials = numel(validSeconds);
    out.summary.(key) = out.summary.methods.(key);
end

% Backward-compatible aliases.
out.summary.traditional = out.summary.methods.osCfar;
out.summary.tensor = out.summary.methods.proposed;
end

function v = get_column_or_default(T, name, defaultValue)
if ismember(name, T.Properties.VariableNames)
    v = T.(name);
else
    v = defaultValue;
end
end

function oneMethod = run_energy_assisted_tensor_framework_local(prop, opts)
% SNR-adaptive component interpretation. Energy/strength is used to keep
% credible physical components at low SNR, while UAV identity is still
% decided from Doppler width and harmonic evidence.
oneMethod = prop;
if ~isfield(opts,'energyAssist') || ~get_field_default_local(opts.energyAssist,'enable',false)
    return;
end
if ~isfield(prop,'allEstimate') || isempty(prop.allEstimate)
    return;
end
allRows = prop.allEstimate;
if isempty(allRows) || ~all(ismember({'PeriodicScore','SpectrumWidth','IsUAV'}, allRows.Properties.VariableNames))
    return;
end
if ~ismember('ClassLabel', allRows.Properties.VariableNames)
    classLabel = repmat("Object", height(allRows), 1);
    classLabel(logical(allRows.IsUAV)) = "UAV";
    allRows.ClassLabel = classLabel;
end
if ~ismember('DecisionReason', allRows.Properties.VariableNames)
    allRows.DecisionReason = strings(height(allRows), 1);
end
ea = opts.energyAssist;
snrNow = get_field_default_local(prop,'SNR_dB',inf);
lowThr = get_field_default_local(ea,'lowSNRThresholdDb',-5);
isLowSNR = get_field_default_local(ea,'lowSNREnable',true) && snrNow <= lowThr;

minWidth = get_field_default_local(ea,'minWidthBins',3);
maxWidth = get_field_default_local(ea,'maxWidthBins',40);
scoreRel = get_field_default_local(ea,'scoreRelThreshold',0.35);
maxWeak = get_field_default_local(ea,'maxWeakCandidates',2);

score = double(allRows.PeriodicScore);
score(~isfinite(score)) = 0;
width = double(allRows.SpectrumWidth);
matched = zeros(height(allRows),1);
if ismember('MatchedPeaks', allRows.Properties.VariableNames)
    matched = double(allRows.MatchedPeaks);
    matched(~isfinite(matched)) = 0;
end

if isLowSNR
    lowMaxWidth = get_field_default_local(ea,'lowSNRMaxWidthBins',120);
    lowNoiseWidth = get_field_default_local(ea,'lowSNRNoiseWidthBins',180);
    lowMinWidth = get_field_default_local(ea,'lowSNRMinWidthBins',4);
    lowScoreRel = get_field_default_local(ea,'lowSNRScoreRelThreshold',0.18);
    lowMinMatched = get_field_default_local(ea,'lowSNRMinMatchedPeaks',2);
    lowSoftThr = get_field_default_local(ea,'lowSNRSoftScoreThreshold',0.38);
    lowMaxUAV = get_field_default_local(ea,'lowSNRMaxRescueUAV',max(2,ceil(0.65*opts.cfarMinCandidates)));

    scoreNorm = score ./ (max(score) + eps);
    matchedNorm = min(1, matched ./ max(1, lowMinMatched));
    widthScore = double(width >= lowMinWidth & width <= lowMaxWidth);
    strengthScore = max(scoreNorm, double(score >= lowScoreRel * max(score + eps)));
    softScore = 0.45 * strengthScore + 0.30 * matchedNorm + 0.25 * widthScore;

    tooWide = width > lowNoiseWidth;
    tooNarrow = width < lowMinWidth;
    strictUAV = logical(allRows.IsUAV);
    rescueMask = ~strictUAV & ~tooWide & ~tooNarrow & softScore >= lowSoftThr;
    rescueIdx = find(rescueMask);
    if ~isempty(rescueIdx)
        [~,ord] = sort(softScore(rescueIdx), 'descend');
        rescueIdx = rescueIdx(ord(1:min(lowMaxUAV,numel(rescueIdx))));
        allRows.IsUAV(rescueIdx) = true;
        allRows.ClassLabel(rescueIdx) = "UAV";
        allRows.DecisionReason(rescueIdx) = "low-SNR energy-assisted weak harmonic UAV candidate";
    end

    noiseIdx = find(~strictUAV & tooWide);
    if ~isempty(noiseIdx)
        allRows.IsUAV(noiseIdx) = false;
        allRows.ClassLabel(noiseIdx) = "Rejected";
        allRows.DecisionReason(noiseIdx) = "low-SNR rejected: excessively wide unstructured Doppler";
    end
else
    scoreThr = scoreRel * max(score + eps);
    weakMask = ~logical(allRows.IsUAV) & width >= minWidth & width <= maxWidth & score >= scoreThr;
    weakIdx = find(weakMask);
    if ~isempty(weakIdx)
        [~,ord] = sort(score(weakIdx), 'descend');
        weakIdx = weakIdx(ord(1:min(maxWeak,numel(weakIdx))));
        allRows.IsUAV(weakIdx) = false;
        allRows.ClassLabel(weakIdx) = "Object";
        allRows.DecisionReason(weakIdx) = "energy-assisted tensor physical non-UAV candidate";
    end
end

oneMethod.allEstimate = allRows;
oneMethod.afterNoiseRemoval = allRows(allRows.ClassLabel ~= "Rejected",:);
uavRaw = allRows(logical(allRows.IsUAV),:);
oneMethod.uavEstimateRaw = uavRaw;
oneMethod.uavEstimate = merge_duplicate_uav_estimates_local(uavRaw, opts.uavMergeRule);
oneMethod.frameworkKey = "energy_assisted_tensor";
end

function [A, B] = align_estimate_tables_for_vertcat_local(A, B)
varsA = A.Properties.VariableNames;
varsB = B.Properties.VariableNames;
commonVars = intersect(varsA, varsB, 'stable');
if isempty(commonVars)
    return;
end
A = A(:, commonVars);
B = B(:, commonVars);
end

function [isUAV, score, spacing, matched, width, reason, classLabel] = inherit_cfar_decision_local(cand, ii)
vars = cand.Properties.VariableNames;
isUAV = get_table_scalar_default_local(cand, vars, 'IsUAV', ii, false);
score = get_table_scalar_default_local(cand, vars, 'PeriodicScore', ii, 0);
spacing = get_table_scalar_default_local(cand, vars, 'BestSpacing', ii, NaN);
matched = get_table_scalar_default_local(cand, vars, 'MatchedPeaks', ii, 0);
width = get_table_scalar_default_local(cand, vars, 'SpectrumWidth', ii, NaN);
reason = string(get_table_scalar_default_local(cand, vars, 'DecisionReason', ii, ""));
if ismember('ClassLabel', vars)
    classLabel = string(cand.ClassLabel(ii));
elseif isUAV
    classLabel = "UAV";
else
    classLabel = "Object";
end
if isUAV
    classLabel = "UAV";
end
end

function value = get_table_scalar_default_local(T, vars, name, ii, defaultValue)
if ismember(name, vars)
    value = T.(name)(ii);
else
    value = defaultValue;
end
if iscell(value)
    value = value{1};
end
end

function oneMethod = run_cfar_subspace_refinement_framework_3d(X, trad, opts)
% CFAR provides candidate neighborhoods and FFT-neighborhood UAV decisions.
% Subspace processing only refines the local angle estimate. Range, Doppler,
% and micro-Doppler decisions are inherited from the original CFAR baseline.
[M, NR, ND] = size(X);
if ~isfield(trad,'allEstimate') || isempty(trad.allEstimate)
    oneMethod.allEstimate = empty_estimate_table_local();
    oneMethod.afterNoiseRemoval = oneMethod.allEstimate;
    oneMethod.uavEstimateRaw = oneMethod.allEstimate;
    oneMethod.uavEstimate = oneMethod.allEstimate;
    oneMethod.frameworkKey = "cfar_subspace_refinement";
    return;
end
if isfield(opts,'cfarSubspace'), cs = opts.cfarSubspace; else, cs = struct(); end
angHalf = get_field_default_local(cs,'localAngleHalfWidth',6);
dopHalf = get_field_default_local(cs,'localDopplerHalfWidth',8);
angleFallbackDeg = get_field_default_local(cs,'angleFallbackDeg',opts.uavMergeRule.angleDeg);

rows = table();
cand = trad.allEstimate;
id = 0;
for ii = 1:height(cand)
    r0 = min(max(round(cand.RangeBin(ii)),1),NR);
    Y = squeeze(X(:,r0,:));
    if isvector(Y), Y = reshape(Y, M, ND); end
    [P_AD, ~] = make_angle_doppler_energy_map_local(Y, opts.theta_grid);

    theta0 = cand.AngleDeg(ii);
    d0 = min(max(round(cand.DopplerBin(ii)),1),ND);
    thetaMask = abs((-opts.theta_grid(:)) - theta0) <= angHalf;
    if ~any(thetaMask)
        [~,thetaIdx0] = min(abs((-opts.theta_grid(:)) - theta0));
        thetaMask(thetaIdx0) = true;
    end
    dopMask = false(1,ND);
    dopMask(max(1,d0-dopHalf):min(ND,d0+dopHalf)) = true;
    localAD = P_AD;
    localAD(~thetaMask,:) = -inf;
    localAD(:,~dopMask) = -inf;
    angleScore = max(localAD, [], 2);
    [~,thetaIdx] = max(angleScore);
    dopIdx = d0;
    thetaHat = -opts.theta_grid(thetaIdx);
    useFallbackAngle = abs(thetaHat - theta0) > angleFallbackDeg;
    if useFallbackAngle
        thetaHat = theta0;
    end

    [isUAV, score, spacing, matched, width, reason, classLabel] = inherit_cfar_decision_local(cand, ii);
    if strlength(reason) == 0
        reason = "CFAR FFT decision with subspace-refined angle";
    else
        reason = reason + "; subspace-refined angle";
    end
    if useFallbackAngle
        reason = reason + "; angle fallback";
    end
    id = id + 1;
    newRow = table(id, thetaHat, double(r0), double(dopIdx), score, spacing, matched, width, string(reason), isUAV, classLabel, ...
        'VariableNames', {'ID','AngleDeg','RangeBin','DopplerBin','PeriodicScore','BestSpacing','MatchedPeaks','SpectrumWidth','DecisionReason','IsUAV','ClassLabel'});
    if isempty(rows), rows = newRow; else, rows = [rows; newRow]; end %#ok<AGROW>
end
if isempty(rows), rows = empty_estimate_table_local(); end
oneMethod.allEstimate = rows;
oneMethod.afterNoiseRemoval = rows(rows.ClassLabel ~= "Rejected",:);
oneMethod.uavEstimateRaw = rows(rows.IsUAV,:);
oneMethod.uavEstimate = merge_duplicate_uav_estimates_local(oneMethod.uavEstimateRaw, opts.uavMergeRule);
oneMethod.frameworkKey = "cfar_subspace_refinement";
end

function oneMethod = run_cfar_clean_framework_3d(X, trad, opts)
% Sequentially retain strong CFAR candidates and suppress their local
% range-Doppler neighborhoods to reduce repeated peak detections.
[~, NR, ND] = size(X);
if isfield(opts,'clean'), cl = opts.clean; else, cl = struct(); end
rangeGuard = max(1, round(get_field_default_local(cl,'rangeGuard', opts.uavMergeRule.rangeBin)));
dopplerGuard = max(1, round(get_field_default_local(cl,'dopplerGuard', opts.uavMergeRule.dopplerBin)));
suppressFactor = get_field_default_local(cl,'suppressFactor', 0.02);
minResidualRel = get_field_default_local(cl,'minResidualRel', 0.03);
maxComponents = get_field_default_local(cl,'maxComponents', height(trad.allEstimate));

if ~isfield(trad,'allEstimate') || isempty(trad.allEstimate)
    oneMethod.allEstimate = empty_estimate_table_local();
    oneMethod.afterNoiseRemoval = oneMethod.allEstimate;
    oneMethod.uavEstimateRaw = oneMethod.allEstimate;
    oneMethod.uavEstimate = oneMethod.allEstimate;
    oneMethod.frameworkKey = "cfar_clean";
    return;
end

rdEnergy = squeeze(sum(abs(X).^2, 1));
cand = trad.allEstimate;
nCand = height(cand);
candEnergy = zeros(nCand,1);
for ii = 1:nCand
    rr = min(max(round(cand.RangeBin(ii)), 1), NR);
    dd = min(max(round(cand.DopplerBin(ii)), 1), ND);
    candEnergy(ii) = rdEnergy(rr, dd);
end
maxEnergy = max(candEnergy);
if maxEnergy <= 0 || ~isfinite(maxEnergy), maxEnergy = 1; end
[~, order] = sort(candEnergy, 'descend');

residualEnergy = rdEnergy;
rows = table();
id = 0;
for kk = 1:numel(order)
    ii = order(kk);
    rr = min(max(round(cand.RangeBin(ii)), 1), NR);
    dd = min(max(round(cand.DopplerBin(ii)), 1), ND);
    if residualEnergy(rr, dd) < minResidualRel * maxEnergy
        continue;
    end
    if id >= maxComponents
        break;
    end

    id = id + 1;
    row = cand(ii,:);
    row.ID = id;
    row.DecisionReason = string(row.DecisionReason) + "; CFAR-CLEAN retained";
    if isempty(rows), rows = row; else, rows = [rows; row]; end %#ok<AGROW>

    rIdx = max(1, rr-rangeGuard):min(NR, rr+rangeGuard);
    dIdx = max(1, dd-dopplerGuard):min(ND, dd+dopplerGuard);
    residualEnergy(rIdx, dIdx) = residualEnergy(rIdx, dIdx) * suppressFactor;
end
if isempty(rows), rows = empty_estimate_table_local(); end
oneMethod.allEstimate = rows;
oneMethod.afterNoiseRemoval = rows(rows.ClassLabel ~= "Rejected",:);
oneMethod.uavEstimateRaw = rows(rows.IsUAV,:);
oneMethod.uavEstimate = merge_duplicate_uav_estimates_local(oneMethod.uavEstimateRaw, opts.uavMergeRule);
oneMethod.frameworkKey = "cfar_clean";
end

function oneMethod = run_multi_hypothesis_subspace_framework_3d(X, opts, expectedPhysicalCount)
% Unknown source number is handled by trying multiple subspace hypotheses.
[~, NR, ~] = size(X);
if isfield(opts,'mhSubspace'), mh = opts.mhSubspace; else, mh = struct(); end
Kmin = max(1, get_field_default_local(mh,'minSources',1));
Kmax = min([NR-2, get_field_default_local(mh,'maxSources',expectedPhysicalCount+4), expectedPhysicalCount+6]);
sourcePenalty = get_field_default_local(mh,'sourcePenalty',0.04);
bestScore = -inf;
bestMethod = [];
rankInfo = table();
for K = Kmin:Kmax
    optsK = opts;
    optsK.subspace3D.maxComponents = K;
    optsK.subspace3D.Kmin = K;
    optsK.subspace3D.Kmax = K;
    cand = run_subspace_parametric_framework_3d(X, K, optsK, K);
    if isempty(cand.allEstimate)
        nUAV = 0; nObj = 0; nNoise = K; meanScore = 0;
    else
        nUAV = height(cand.uavEstimate);
        nObj = sum(cand.allEstimate.ClassLabel == "Object");
        nNoise = sum(cand.allEstimate.ClassLabel == "Rejected");
        meanScore = mean(double(cand.allEstimate.PeriodicScore), 'omitnan');
        if ~isfinite(meanScore), meanScore = 0; end
    end
    nPhysical = nUAV + nObj;
    score = 2.0*nUAV + 0.35*nObj - 0.75*nNoise + 0.25*meanScore - sourcePenalty*K;
    rankInfo = [rankInfo; table(K,nUAV,nObj,nNoise,nPhysical,meanScore,score, ...
        'VariableNames', {'K','NumUAV','NumObject','NumNoise','NumPhysical','MeanScore','SelectionScore'})]; %#ok<AGROW>
    if score > bestScore
        bestScore = score;
        bestMethod = cand;
    end
end
if isempty(bestMethod)
    bestMethod.allEstimate = empty_estimate_table_local();
    bestMethod.afterNoiseRemoval = bestMethod.allEstimate;
    bestMethod.uavEstimateRaw = bestMethod.allEstimate;
    bestMethod.uavEstimate = bestMethod.allEstimate;
end
oneMethod = bestMethod;
oneMethod.frameworkKey = "multi_hypothesis_subspace";
oneMethod.rankInfo = rankInfo;
if ~isempty(rankInfo)
    [~,idx] = max(rankInfo.SelectionScore);
    oneMethod.selectedHypothesis = rankInfo.K(idx);
end
end

function agg = init_metric_aggregate_local()
agg.trueTarget = 0;
agg.estimateCount = 0;
agg.truePositive = 0;
agg.falseAlarm = 0;
agg.missed = 0;
agg.angleSqErr = [];
agg.rangeSqErr = [];
agg.dopplerSqErr = [];
agg.nonUAVCount = 0;
agg.nonUAVAsUAV = 0;
agg.uavCountCorrect = 0;
agg.uavCountErrorAbs = 0;
agg.OSPA_UAV_vals = [];
agg.OSPA_UAV_loc_vals = [];
agg.OSPA_UAV_card_vals = [];
end

function agg = update_metric_aggregate_local(agg, m)
agg.trueTarget = agg.trueTarget + m.trueTarget;
agg.estimateCount = agg.estimateCount + m.estimateCount;
agg.truePositive = agg.truePositive + m.truePositive;
agg.falseAlarm = agg.falseAlarm + m.falseAlarm;
agg.missed = agg.missed + m.missed;
agg.angleSqErr = [agg.angleSqErr; m.angleSqErr(:)];
agg.rangeSqErr = [agg.rangeSqErr; m.rangeSqErr(:)];
agg.dopplerSqErr = [agg.dopplerSqErr; m.dopplerSqErr(:)];
agg.nonUAVCount = agg.nonUAVCount + get_metric_field_local(m, 'nonUAVCount', 0);
agg.nonUAVAsUAV = agg.nonUAVAsUAV + get_metric_field_local(m, 'nonUAVAsUAV', 0);
agg.uavCountCorrect = agg.uavCountCorrect + get_metric_field_local(m, 'uavCountCorrect', 0);
agg.uavCountErrorAbs = agg.uavCountErrorAbs + get_metric_field_local(m, 'uavCountErrorAbs', 0);
agg.OSPA_UAV_vals = [agg.OSPA_UAV_vals; get_metric_field_local(m, 'OSPA_UAV', NaN)];
agg.OSPA_UAV_loc_vals = [agg.OSPA_UAV_loc_vals; get_metric_field_local(m, 'OSPA_UAV_loc', NaN)];
agg.OSPA_UAV_card_vals = [agg.OSPA_UAV_card_vals; get_metric_field_local(m, 'OSPA_UAV_card', NaN)];
end

function s = finalize_metric_aggregate_local(agg, numMC)
s = agg;
s.Pd = safe_divide_local(agg.truePositive, agg.trueTarget);
s.Pm = safe_divide_local(agg.missed, agg.trueTarget);
s.falseAlarmRatePerTruth = safe_divide_local(agg.falseAlarm, agg.trueTarget);
s.avgFalseAlarmPerMC = safe_divide_local(agg.falseAlarm, numMC);
s.precision = safe_divide_local(agg.truePositive, agg.estimateCount);
s.recall = s.Pd;
s.F1 = safe_divide_local(2*s.precision*s.recall, s.precision + s.recall);
s.angleRMSE = sqrt(mean_or_nan_local(agg.angleSqErr));
s.rangeRMSE = sqrt(mean_or_nan_local(agg.rangeSqErr));
s.dopplerRMSE = sqrt(mean_or_nan_local(agg.dopplerSqErr));
s.Pd_UAV = s.Pd;
s.Pfa_UAV = safe_divide_local(agg.nonUAVAsUAV, agg.nonUAVCount);
s.uavCountAccuracy = safe_divide_local(agg.uavCountCorrect, numMC);
s.uavCountMAE = safe_divide_local(agg.uavCountErrorAbs, numMC);
s.OSPA_UAV = mean_or_nan_local(agg.OSPA_UAV_vals);
s.OSPA_UAV_loc = mean_or_nan_local(agg.OSPA_UAV_loc_vals);
s.OSPA_UAV_card = mean_or_nan_local(agg.OSPA_UAV_card_vals);
end

function m = evaluate_detection_metrics_local(estTable, trueUAV, thr, sidebandAware)
trueTarget = height(trueUAV);
if isempty(estTable)
    estimateCount = 0;
else
    estimateCount = height(estTable);
end
usedTruth = false(trueTarget,1);
truePositive = 0;
angleSqErr = [];
rangeSqErr = [];
dopplerSqErr = [];

for ii = 1:estimateCount
    da = abs(estTable.AngleDeg(ii) - trueUAV.AngleDeg);
    dr = abs(estTable.RangeBin(ii) - trueUAV.RangeBin);
    dd = zeros(trueTarget,1);
    for uu = 1:trueTarget
        if sidebandAware && ismember('MicroDopplerSpacing', trueUAV.Properties.VariableNames)
            centers = trueUAV.DopplerBin(uu) + (-3:3) * trueUAV.MicroDopplerSpacing(uu);
            dd(uu) = min(abs(estTable.DopplerBin(ii) - centers));
        else
            dd(uu) = abs(estTable.DopplerBin(ii) - trueUAV.DopplerBin(uu));
        end
    end
    valid = da < thr.angleDeg & dr < thr.rangeBin & dd < thr.dopplerBin & ~usedTruth;
    if any(valid)
        score = da/max(thr.angleDeg,eps) + dr/max(thr.rangeBin,eps) + dd/max(thr.dopplerBin,eps);
        score(~valid) = inf;
        [~, idx] = min(score);
        usedTruth(idx) = true;
        truePositive = truePositive + 1;
        angleSqErr(end+1,1) = da(idx)^2; %#ok<AGROW>
        rangeSqErr(end+1,1) = dr(idx)^2; %#ok<AGROW>
        dopplerSqErr(end+1,1) = dd(idx)^2; %#ok<AGROW>
    end
end

falseAlarm = estimateCount - truePositive;
missed = trueTarget - truePositive;
m.trueTarget = trueTarget;
m.estimateCount = estimateCount;
m.truePositive = truePositive;
m.falseAlarm = falseAlarm;
m.missed = missed;
m.Pd = safe_divide_local(truePositive, trueTarget);
m.Pm = safe_divide_local(missed, trueTarget);
m.precision = safe_divide_local(truePositive, estimateCount);
m.recall = m.Pd;
m.F1 = safe_divide_local(2*m.precision*m.recall, m.precision + m.recall);
m.angleSqErr = angleSqErr;
m.rangeSqErr = rangeSqErr;
m.dopplerSqErr = dopplerSqErr;
m.angleRMSE = sqrt(mean_or_nan_local(angleSqErr));
m.rangeRMSE = sqrt(mean_or_nan_local(rangeSqErr));
m.dopplerRMSE = sqrt(mean_or_nan_local(dopplerSqErr));
end

function m = evaluate_confusion_local(estTable, trueUAV, trueClutter, thr, sidebandAware)
if isempty(estTable)
    estimateCount = 0;
else
    estimateCount = height(estTable);
end
usedUAV = false(height(trueUAV),1);
usedClutter = false(height(trueClutter),1);
TP_UAV = 0;
FP_clutter_as_UAV = 0;
FP_ghost = 0;

for ii = 1:estimateCount
    [isUAVMatch, idxUAV] = find_best_uav_match_local(estTable(ii,:), trueUAV, thr, sidebandAware, usedUAV);
    if isUAVMatch
        TP_UAV = TP_UAV + 1;
        usedUAV(idxUAV) = true;
        continue;
    end

    [isClutterMatch, idxClutter] = find_best_clutter_match_local(estTable(ii,:), trueClutter, thr, usedClutter);
    if isClutterMatch
        FP_clutter_as_UAV = FP_clutter_as_UAV + 1;
        usedClutter(idxClutter) = true;
    else
        FP_ghost = FP_ghost + 1;
    end
end

FN_UAV = height(trueUAV) - TP_UAV;
TN_clutter = height(trueClutter) - FP_clutter_as_UAV;
FP_total = FP_clutter_as_UAV + FP_ghost;
m.TP_UAV = TP_UAV;
m.FN_UAV = FN_UAV;
m.FP_clutter_as_UAV = FP_clutter_as_UAV;
m.FP_ghost = FP_ghost;
m.TN_clutter = TN_clutter;
m.Pd = safe_divide_local(TP_UAV, height(trueUAV));
m.Pm = safe_divide_local(FN_UAV, height(trueUAV));
m.Pfa_UAV = safe_divide_local(FP_clutter_as_UAV, height(trueClutter));
m.precision = safe_divide_local(TP_UAV, TP_UAV + FP_total);
m.F1 = safe_divide_local(2*m.precision*m.Pd, m.precision + m.Pd);
end

function [tf, bestIdx] = find_best_uav_match_local(estRow, trueUAV, thr, sidebandAware, usedUAV)
bestIdx = NaN;
if isempty(trueUAV) || height(trueUAV) == 0
    tf = false;
    return;
end
da = abs(estRow.AngleDeg - trueUAV.AngleDeg);
dr = abs(estRow.RangeBin - trueUAV.RangeBin);
dd = zeros(height(trueUAV),1);
for uu = 1:height(trueUAV)
    if sidebandAware && ismember('MicroDopplerSpacing', trueUAV.Properties.VariableNames)
        centers = trueUAV.DopplerBin(uu) + (-3:3) * trueUAV.MicroDopplerSpacing(uu);
        dd(uu) = min(abs(estRow.DopplerBin - centers));
    else
        dd(uu) = abs(estRow.DopplerBin - trueUAV.DopplerBin(uu));
    end
end
valid = da < thr.angleDeg & dr < thr.rangeBin & dd < thr.dopplerBin & ~usedUAV;
if any(valid)
    score = da/max(thr.angleDeg,eps) + dr/max(thr.rangeBin,eps) + dd/max(thr.dopplerBin,eps);
    score(~valid) = inf;
    [~, bestIdx] = min(score);
    tf = true;
else
    tf = false;
end
end

function [tf, bestIdx] = find_best_clutter_match_local(estRow, trueClutter, thr, usedClutter)
bestIdx = NaN;
if isempty(trueClutter) || height(trueClutter) == 0
    tf = false;
    return;
end
da = abs(estRow.AngleDeg - trueClutter.AngleDeg);
dr = abs(estRow.RangeBin - trueClutter.RangeBin);
dd = abs(estRow.DopplerBin - trueClutter.DopplerBin);
valid = da < thr.angleDeg & dr < thr.rangeBin & dd < thr.dopplerBin & ~usedClutter;
if any(valid)
    score = da/max(thr.angleDeg,eps) + dr/max(thr.rangeBin,eps) + dd/max(thr.dopplerBin,eps);
    score(~valid) = inf;
    [~, bestIdx] = min(score);
    tf = true;
else
    tf = false;
end
end

function row = metrics_to_row_local(mc, methodName, m)
row = table(mc, string(methodName), m.trueTarget, m.estimateCount, m.truePositive, ...
    m.falseAlarm, m.missed, m.Pd, m.Pm, m.precision, m.F1, ...
    m.angleRMSE, m.rangeRMSE, m.dopplerRMSE, m.Pd_UAV, m.Pfa_UAV, ...
    m.uavCountCorrect, m.uavCountErrorAbs, m.OSPA_UAV, m.OSPA_UAV_loc, m.OSPA_UAV_card, ...
    'VariableNames', {'MC','Method','TrueTarget','EstimateCount','TruePositive','FalseAlarm','Missed','Pd','Pm','Precision','F1','AngleRMSE','RangeRMSE','DopplerRMSE','Pd_UAV','Pfa_UAV','UAVCountCorrect','UAVCountErrorAbs','OSPA_UAV','OSPA_UAV_loc','OSPA_UAV_card'});
end

function v = get_metric_field_local(s, name, defaultValue)
if isstruct(s) && isfield(s, name) && ~isempty(s.(name))
    v = s.(name);
else
    v = defaultValue;
end
end

function extra = evaluate_cluster_extra_metrics_local(estTable, trueUAV, trueClutter, thr, ospaOpts, sidebandAware, baseMetrics)
if isempty(estTable)
    estCount = 0;
else
    estCount = height(estTable);
end
extra.Pd_UAV = baseMetrics.Pd;
extra.nonUAVCount = height(trueClutter);
extra.nonUAVAsUAV = count_non_uav_as_uav_local(estTable, trueClutter, thr);
extra.Pfa_UAV = safe_divide_local(extra.nonUAVAsUAV, extra.nonUAVCount);
extra.uavCountCorrect = double(estCount == height(trueUAV));
extra.uavCountErrorAbs = abs(estCount - height(trueUAV));
[extra.OSPA_UAV, extra.OSPA_UAV_loc, extra.OSPA_UAV_card] = compute_ospa_uav_local(trueUAV, estTable, thr, ospaOpts, sidebandAware);
end

function nFalse = count_non_uav_as_uav_local(estTable, trueClutter, thr)
if isempty(estTable) || isempty(trueClutter) || height(trueClutter) == 0
    nFalse = 0;
    return;
end
nFalse = 0;
for cc = 1:height(trueClutter)
    da = abs(estTable.AngleDeg - trueClutter.AngleDeg(cc));
    dr = abs(estTable.RangeBin - trueClutter.RangeBin(cc));
    dd = abs(estTable.DopplerBin - trueClutter.DopplerBin(cc));
    if any(da < thr.angleDeg & dr < thr.rangeBin & dd < thr.dopplerBin)
        nFalse = nFalse + 1;
    end
end
end

function [ospa, locTerm, cardTerm] = compute_ospa_uav_local(trueUAV, estTable, thr, ospaOpts, sidebandAware)
p = get_field_default_local(ospaOpts, 'order', get_field_default_local(ospaOpts, 'p', 2));
c = get_field_default_local(ospaOpts, 'cutoff', 3);
m = height(trueUAV);
if isempty(estTable)
    n = 0;
else
    n = height(estTable);
end
if m == 0 && n == 0
    ospa = 0; locTerm = 0; cardTerm = 0; return;
end
N = max(m,n);
q = min(m,n);
if q == 0
    ospa = c;
    locTerm = 0;
    cardTerm = c;
    return;
end
D = zeros(m,n);
for ii = 1:m
    for jj = 1:n
        da = abs(trueUAV.AngleDeg(ii) - estTable.AngleDeg(jj)) / max(thr.angleDeg, eps);
        dr = abs(trueUAV.RangeBin(ii) - estTable.RangeBin(jj)) / max(thr.rangeBin, eps);
        if sidebandAware && ismember('MicroDopplerSpacing', trueUAV.Properties.VariableNames)
            centers = trueUAV.DopplerBin(ii) + (-3:3) * trueUAV.MicroDopplerSpacing(ii);
            ddRaw = min(abs(estTable.DopplerBin(jj) - centers));
        else
            ddRaw = abs(trueUAV.DopplerBin(ii) - estTable.DopplerBin(jj));
        end
        dd = ddRaw / max(thr.dopplerBin, eps);
        D(ii,jj) = min(c, sqrt(da^2 + dr^2 + dd^2));
    end
end
if m <= n
    C = D.^p;
else
    C = (D.').^p;
end
assignCost = min_assignment_cost_local(C);
cardCost = (c^p) * abs(n - m);
locTerm = (assignCost / N)^(1/p);
cardTerm = (cardCost / N)^(1/p);
ospa = ((assignCost + cardCost) / N)^(1/p);
end

function bestCost = min_assignment_cost_local(C)
[nRows, nCols] = size(C);
if nRows == 0
    bestCost = 0;
    return;
end
used = false(1,nCols);
bestCost = inf;
search_row_local(1, 0);
    function search_row_local(rr, currentCost)
        if currentCost >= bestCost
            return;
        end
        if rr > nRows
            bestCost = currentCost;
            return;
        end
        for cc = 1:nCols
            if ~used(cc)
                used(cc) = true;
                search_row_local(rr + 1, currentCost + C(rr,cc));
                used(cc) = false;
            end
        end
    end
end
function y = safe_divide_local(a,b)
if b == 0
    y = NaN;
else
    y = a / b;
end
end

function y = mean_or_nan_local(x)
x = x(isfinite(x));
if isempty(x)
    y = NaN;
else
    y = mean(x);
end
end

function mergedTable = merge_duplicate_uav_estimates_local(estTable, rule)
rule = fill_merge_rule_defaults_local(rule);
if ~rule.enable
    mergedTable = estTable;
    return;
end
if isempty(estTable) || height(estTable) <= 1
    mergedTable = estTable;
    return;
end
score = get_table_score_local(estTable);
[~, order] = sort(score, 'descend');
used = false(height(estTable),1);
keepRows = [];
mergedCount = zeros(0,1);
mergedIDs = strings(0,1);
for oo = 1:numel(order)
    seedIdx = order(oo);
    if used(seedIdx), continue; end
    same = false(height(estTable),1);
    for jj = 1:height(estTable)
        if used(jj), continue; end
        if is_same_uav_detection_local(estTable(seedIdx,:), estTable(jj,:), rule)
            same(jj) = true;
        end
    end
    groupIdx = find(same);
    [~, localBest] = max(score(groupIdx));
    keepIdx = groupIdx(localBest);
    used(groupIdx) = true;
    keepRows(end+1,1) = keepIdx; %#ok<AGROW>
    mergedCount(end+1,1) = numel(groupIdx); %#ok<AGROW>
    mergedIDs(end+1,1) = strjoin(string(estTable.ID(groupIdx).'), ','); %#ok<AGROW>
end
mergedTable = estTable(keepRows,:);
mergedTable.MergedCount = mergedCount;
mergedTable.MergedIDs = mergedIDs;
mergedTable.ID = (1:height(mergedTable)).';
end

function rule = fill_merge_rule_defaults_local(rule)
if nargin < 1 || isempty(rule), rule = struct(); end
if ~isfield(rule,'enable'), rule.enable = false; end
if ~isfield(rule,'angleDeg'), rule.angleDeg = 3; end
if ~isfield(rule,'rangeBin'), rule.rangeBin = 2; end
if ~isfield(rule,'dopplerBin'), rule.dopplerBin = 3; end
if ~isfield(rule,'sidebandHarmonics'), rule.sidebandHarmonics = -3:3; end
if ~isfield(rule,'spacingCandidates'), rule.spacingCandidates = [5 6 7 8]; end
end

function tf = is_same_uav_detection_local(a, b, rule)
angleClose = abs(a.AngleDeg - b.AngleDeg) <= rule.angleDeg;
rangeClose = abs(a.RangeBin - b.RangeBin) <= rule.rangeBin;
if ~angleClose || ~rangeClose
    tf = false;
    return;
end
spacingCandidates = unique([rule.spacingCandidates(:).', round(a.BestSpacing), round(b.BestSpacing)]);
spacingCandidates = spacingCandidates(isfinite(spacingCandidates) & spacingCandidates > 0);
if isempty(spacingCandidates), spacingCandidates = 1; end
dopplerClose = abs(a.DopplerBin - b.DopplerBin) <= rule.dopplerBin;
for ss = spacingCandidates
    centers = a.DopplerBin + rule.sidebandHarmonics * ss;
    if min(abs(b.DopplerBin - centers)) <= rule.dopplerBin
        dopplerClose = true;
        break;
    end
end
tf = dopplerClose;
end

function score = get_table_score_local(T)
score = zeros(height(T),1);
if ismember('PeriodicScore', T.Properties.VariableNames), score = score + T.PeriodicScore; end
if ismember('MatchedPeaks', T.Properties.VariableNames), score = score + 0.05 * T.MatchedPeaks; end
if ismember('SpectrumWidth', T.Properties.VariableNames), score = score - 0.001 * abs(T.SpectrumWidth - 12); end
score(~isfinite(score)) = -inf;
end


function oneMethod = run_sparse_reconstruction_framework_3d(X, opts)
% Local sparse harmonic matching. It first finds local angle-range-Doppler
% candidates from the 3-D echo, then compares a single-tone object atom with
% a harmonic UAV atom around each candidate.
[M, NR, ND] = size(X);
sp = get_sparse_opts_local(opts, M, NR, ND);
candidates = select_local_sparse_candidates_3d(X, sp, M, NR, ND);
rows = table();
for kk = 1:height(candidates)
    thetaFine = make_local_grid_local(candidates.ThetaInternal(kk), sp.localThetaHalfWidth, sp.localThetaStep, min(sp.thetaGrid), max(sp.thetaGrid));
    rangeFine = make_local_grid_local(candidates.RangeBin(kk), sp.localRangeHalfWidth, sp.localRangeStep, min(sp.rangeGrid), max(sp.rangeGrid));
    bodyFine = make_local_grid_local(candidates.DopplerBin(kk), sp.localDopplerHalfWidth, sp.localDopplerStep, min(sp.bodyGrid), max(sp.bodyGrid));
    spacingFine = sp.spacingGrid;
    [best, ~] = search_sparse_atom_grid_local(X, sp, thetaFine, rangeFine, bodyFine, spacingFine, M, NR, ND);
    if ~isfinite(best.score) || best.score < sp.minCorrelation
        best.kind = "Rejected";
        best.theta = candidates.ThetaInternal(kk);
        best.range = candidates.RangeBin(kk);
        best.doppler = candidates.DopplerBin(kk);
        best.spacing = 0;
        best.matched = 0;
        best.periodicScore = max(0, candidates.Score(kk));
        best.width = NaN;
        best.reason = "local sparse rejected: low correlation";
    end
    newRow = sparse_atom_to_row(best, kk, sp);
    if isempty(rows), rows = newRow; else, rows = [rows; newRow]; end %#ok<AGROW>
end
if isempty(rows), rows = empty_estimate_table_local(); end
if height(rows) > 0
    rows.IsUAV = rows.ClassLabel == "UAV";
end
oneMethod.allEstimate = rows;
oneMethod.afterNoiseRemoval = rows(~contains(string(rows.DecisionReason), "rejected"),:);
oneMethod.uavEstimateRaw = rows(rows.IsUAV,:);
oneMethod.uavEstimate = merge_duplicate_uav_estimates_local(oneMethod.uavEstimateRaw, opts.uavMergeRule);
oneMethod.frameworkKey = "local_sparse_harmonic_matching";
end

function sp = get_sparse_opts_local(opts, M, NR, ND)
if isfield(opts,'sparse3D'), sp = opts.sparse3D; else, sp = struct(); end
sp.thetaGrid = get_field_default_local(sp,'thetaGrid',-55:5:55);
sp.rangeGrid = get_field_default_local(sp,'rangeGrid',4:2:(NR-3));
sp.bodyGrid = get_field_default_local(sp,'bodyGrid',8:2:(ND-8));
sp.spacingGrid = get_field_default_local(sp,'spacingGrid',[4 5 6 7 8]);
sp.harmonics = get_field_default_local(sp,'harmonics',-3:3);
sp.maxAtoms = get_field_default_local(sp,'maxAtoms',max(4, min(8, opts.cfarMinCandidates)));
sp.maxCandidates = get_field_default_local(sp,'maxCandidates',sp.maxAtoms);
sp.maxRangeDopplerPerTheta = get_field_default_local(sp,'maxRangeDopplerPerTheta',max(3, ceil(sp.maxCandidates/2)));
sp.candidateRelThreshold = get_field_default_local(sp,'candidateRelThreshold',0.08);
sp.minCandidateThetaDistance = get_field_default_local(sp,'minCandidateThetaDistance',3);
sp.minCandidateRangeDistance = get_field_default_local(sp,'minCandidateRangeDistance',2);
sp.minCandidateDopplerDistance = get_field_default_local(sp,'minCandidateDopplerDistance',4);
sp.minCorrelation = get_field_default_local(sp,'minCorrelation',0.02);
sp.widthPowerFraction = get_field_default_local(sp,'widthPowerFraction',0.90);
sp.uavResidualAdvantage = get_field_default_local(sp,'uavResidualAdvantage',1.02);
sp.maxCoarseTheta = get_field_default_local(sp,'maxCoarseTheta',15);
sp.maxCoarseRange = get_field_default_local(sp,'maxCoarseRange',25);
sp.maxCoarseDoppler = get_field_default_local(sp,'maxCoarseDoppler',35);
sp.localThetaHalfWidth = get_field_default_local(sp,'localThetaHalfWidth',4);
sp.localRangeHalfWidth = get_field_default_local(sp,'localRangeHalfWidth',3);
sp.localDopplerHalfWidth = get_field_default_local(sp,'localDopplerHalfWidth',3);
sp.localThetaStep = get_field_default_local(sp,'localThetaStep',1);
sp.localRangeStep = get_field_default_local(sp,'localRangeStep',0.5);
sp.localDopplerStep = get_field_default_local(sp,'localDopplerStep',1);
sp.betaMD = get_field_default_local(sp,'betaMD',opts.betaMD);
sp.sigma_R = opts.sigma_R;
sp.sigma_D_u = opts.sigma_D_u;
sp.sigma_D_c = opts.sigma_D_c;
sp.M = M; sp.NR = NR; sp.ND = ND;
end

function candidates = select_local_sparse_candidates_3d(X, sp, M, NR, ND)
thetaScan = coarsen_grid_local(sp.thetaGrid, sp.maxCoarseTheta);
XR = reshape(X, M, []);
thetaList = [];
rangeList = [];
dopplerList = [];
scoreList = [];
for it = 1:numel(thetaScan)
    a = steering_ula_local(M, thetaScan(it));
    Y = reshape(conj(a)' * XR, NR, ND);
    P = abs(Y).^2;
    [vals, ord] = sort(P(:), 'descend');
    localKeep = min(numel(ord), max(1, sp.maxRangeDopplerPerTheta));
    for ii = 1:localKeep
        if ~isfinite(vals(ii)) || vals(ii) <= 0
            continue;
        end
        [rr, dd] = ind2sub([NR, ND], ord(ii));
        thetaList(end+1,1) = thetaScan(it); %#ok<AGROW>
        rangeList(end+1,1) = rr; %#ok<AGROW>
        dopplerList(end+1,1) = dd; %#ok<AGROW>
        scoreList(end+1,1) = vals(ii); %#ok<AGROW>
    end
end

if isempty(scoreList)
    candidates = table(zeros(0,1), zeros(0,1), zeros(0,1), zeros(0,1), ...
        'VariableNames', {'ThetaInternal','RangeBin','DopplerBin','Score'});
    return;
end

scoreList = scoreList ./ max(scoreList);
valid = scoreList >= sp.candidateRelThreshold;
thetaList = thetaList(valid);
rangeList = rangeList(valid);
dopplerList = dopplerList(valid);
scoreList = scoreList(valid);
if isempty(scoreList)
    candidates = table(zeros(0,1), zeros(0,1), zeros(0,1), zeros(0,1), ...
        'VariableNames', {'ThetaInternal','RangeBin','DopplerBin','Score'});
    return;
end

[scoreList, order] = sort(scoreList, 'descend');
thetaList = thetaList(order);
rangeList = rangeList(order);
dopplerList = dopplerList(order);
keep = false(numel(scoreList),1);
for ii = 1:numel(scoreList)
    if sum(keep) >= sp.maxCandidates
        break;
    end
    if ~any(keep)
        keep(ii) = true;
        continue;
    end
    closeTheta = abs(thetaList(ii) - thetaList(keep)) <= sp.minCandidateThetaDistance;
    closeRange = abs(rangeList(ii) - rangeList(keep)) <= sp.minCandidateRangeDistance;
    closeDoppler = abs(dopplerList(ii) - dopplerList(keep)) <= sp.minCandidateDopplerDistance;
    if ~any(closeTheta & closeRange & closeDoppler)
        keep(ii) = true;
    end
end

candidates = table(thetaList(keep), rangeList(keep), dopplerList(keep), scoreList(keep), ...
    'VariableNames', {'ThetaInternal','RangeBin','DopplerBin','Score'});
end
function [best, atom] = find_best_sparse_atom_3d(R, sp, M, NR, ND)
% Coarse-to-fine sparse matching. This avoids a full fine 3-D dictionary scan.
thetaCoarse = coarsen_grid_local(sp.thetaGrid, sp.maxCoarseTheta);
rangeCoarse = coarsen_grid_local(sp.rangeGrid, sp.maxCoarseRange);
bodyCoarse = coarsen_grid_local(sp.bodyGrid, sp.maxCoarseDoppler);
[coarseBest, ~] = search_sparse_atom_grid_local(R, sp, thetaCoarse, rangeCoarse, bodyCoarse, sp.spacingGrid, M, NR, ND);

if ~isfinite(coarseBest.score)
    best = coarseBest;
    atom = zeros(size(R));
    return;
end

thetaFine = make_local_grid_local(coarseBest.theta, sp.localThetaHalfWidth, sp.localThetaStep, min(sp.thetaGrid), max(sp.thetaGrid));
rangeFine = make_local_grid_local(coarseBest.range, sp.localRangeHalfWidth, sp.localRangeStep, min(sp.rangeGrid), max(sp.rangeGrid));
bodyFine = make_local_grid_local(coarseBest.doppler, sp.localDopplerHalfWidth, sp.localDopplerStep, min(sp.bodyGrid), max(sp.bodyGrid));
spacingFine = unique([sp.spacingGrid(:).', coarseBest.spacing, coarseBest.spacing-1, coarseBest.spacing+1]);
spacingFine = spacingFine(isfinite(spacingFine) & spacingFine > 0);
[best, atom] = search_sparse_atom_grid_local(R, sp, thetaFine, rangeFine, bodyFine, spacingFine, M, NR, ND);
end

function [best, atom] = search_sparse_atom_grid_local(R, sp, thetaGrid, rangeGrid, bodyGrid, spacingGrid, M, NR, ND)
best.score = -inf; best.kind = "Object"; best.theta = NaN; best.range = NaN; best.doppler = NaN; best.spacing = NaN; best.matched = 0; best.periodicScore = 0; best.width = NaN; best.reason = "not selected";
atom = zeros(size(R));
XR = reshape(R, M, []);
for it = 1:numel(thetaGrid)
    a = steering_ula_local(M, thetaGrid(it));
    Y = squeeze(conj(a)' * XR);
    Y = reshape(Y, NR, ND);
    for ir = 1:numel(rangeGrid)
        r0 = rangeGrid(ir);
        b = gaussian_response_local(NR, r0, sp.sigma_R);
        z = conj(b)' * Y;
        z = z(:);
        for id = 1:numel(bodyGrid)
            d0 = bodyGrid(id);
            gc = gaussian_response_local(ND, d0, sp.sigma_D_c);
            clutterScore = abs(conj(gc)' * z);
            if clutterScore > best.score
                best.score = clutterScore; best.kind = "Object"; best.theta = thetaGrid(it); best.range = r0; best.doppler = d0; best.spacing = 0; best.matched = 1; best.periodicScore = clutterScore; best.width = spectral_width_local(gc, sp.widthPowerFraction); best.reason = "sparse coarse-to-fine single-tone object atom";
                atom = outer3_local(a,b,gc);
            end
            for is = 1:numel(spacingGrid)
                fr = spacingGrid(is);
                gu = harmonic_doppler_atom_local(ND, d0, fr, sp.harmonics, sp.betaMD, sp.sigma_D_u);
                uavScore = abs(conj(gu)' * z);
                if uavScore > best.score
                    best.score = uavScore; best.kind = "UAV"; best.theta = thetaGrid(it); best.range = r0; best.doppler = d0; best.spacing = fr; best.matched = numel(sp.harmonics); best.periodicScore = uavScore; best.width = spectral_width_local(gu, sp.widthPowerFraction); best.reason = "sparse coarse-to-fine harmonic UAV atom";
                    atom = outer3_local(a,b,gu);
                end
            end
        end
    end
end
end

function gridOut = coarsen_grid_local(gridIn, maxPoints)
gridIn = unique(gridIn(:).');
if numel(gridIn) <= maxPoints
    gridOut = gridIn;
    return;
end
idx = unique(round(linspace(1, numel(gridIn), maxPoints)));
gridOut = gridIn(idx);
end

function gridOut = make_local_grid_local(center, halfWidth, step, lo, hi)
if ~isfinite(center)
    gridOut = lo:step:hi;
    return;
end
gridOut = max(lo, center-halfWidth):step:min(hi, center+halfWidth);
if isempty(gridOut), gridOut = min(max(center, lo), hi); end
end

function row = sparse_atom_to_row(best, id, sp)
isUAV = best.kind == "UAV" && best.spacing > 0 && best.width >= 4 && best.width <= 36;
classLabel = "Object"; if isUAV, classLabel = "UAV"; elseif best.kind == "Rejected", classLabel = "Rejected"; end
angleOut = -best.theta;
row = table(id, angleOut, best.range, best.doppler, best.periodicScore, best.spacing, best.matched, best.width, string(best.reason), isUAV, classLabel, ...
    'VariableNames', {'ID','AngleDeg','RangeBin','DopplerBin','PeriodicScore','BestSpacing','MatchedPeaks','SpectrumWidth','DecisionReason','IsUAV','ClassLabel'});
end

function oneMethod = run_subspace_parametric_framework_3d(X, K0prior, opts, expectedPhysicalCount)
% Range-super-resolution subspace framework:
% range-mode unfolding -> Range-MUSIC -> multi-peak angle-Doppler interpretation -> UAV decision.
[M, NR, ND] = size(X);
ss = get_subspace_opts_local(opts, M, NR, ND, K0prior, expectedPhysicalCount);

XR = reshape(permute(X, [2 1 3]), NR, []);
Rr = (XR * XR') / max(1, size(XR,2));
Rr = (Rr + Rr') / 2;
[V,D] = eig(Rr, 'vector');
[eigVals, ord] = sort(real(D), 'descend');
V = V(:,ord);
Kr = estimate_source_number_mdl_gap_local(eigVals, size(XR,2), ss.Kmin, ss.Kmax);
En = V(:, min(Kr+1,NR):end);
if isempty(En), En = V(:,end); end

rangeSpectrum = gaussian_music_grid_spectrum_local(En, ss.rangeGrid, NR, ss.sigma_R);
rangeHats = select_separated_grid_peaks_local(rangeSpectrum, ss.rangeGrid, ss.maxComponents, ss.minRangeDistance);
rows = table();
id = 0;
for ii = 1:numel(rangeHats)
    rangeHat = rangeHats(ii);
    r0 = min(max(round(rangeHat),1),NR);
    rWin = max(1,r0-ss.rangeWinHalf):min(NR,r0+ss.rangeWinHalf);
    Y = squeeze(sum(X(:,rWin,:), 2));
    if isvector(Y), Y = reshape(Y, M, ND); end

    [P_AD, beamDoppler] = make_angle_doppler_energy_map_local(Y, opts.theta_grid);
    peakList = select_ad_peaks_local(P_AD, opts.theta_grid, ss);
    if isempty(peakList)
        continue;
    end

    for pp = 1:size(peakList,1)
        thetaGridIdx = peakList(pp,1);
        d0 = peakList(pp,2);
        thetaGridValue = opts.theta_grid(thetaGridIdx);
        thetaHat = -thetaGridValue;

        angleMask = abs(opts.theta_grid(:) - thetaGridValue) <= ss.angleDopplerWinDeg;
        if ~any(angleMask), angleMask(thetaGridIdx) = true; end
        pD = sum(P_AD(angleMask,:), 1).';
        pD = max(pD - ss.dopplerFloorFraction * median(pD), 0);
        if max(pD) <= eps
            pD = abs(beamDoppler(thetaGridIdx,:)).^2;
            pD = pD(:);
        end
        pD = pD / (max(pD) + eps);

        [isUAV, score, spacing, matched, width, reason] = classify_subspace_doppler_vector_local(pD, d0, ss);
        if isUAV
            classLabel = "UAV";
        elseif width <= ss.objectMaxWidth
            classLabel = "Object";
            reason = "range-subspace AD narrow object";
        else
            classLabel = "Rejected";
            if width > ss.noiseWidthMax
                reason = "range-subspace AD wide noise";
            else
                reason = "range-subspace AD ambiguous spectrum";
            end
        end

        id = id + 1;
        newRow = table(id, thetaHat, rangeHat, d0, score, spacing, matched, width, string(reason), isUAV, classLabel, ...
            'VariableNames', {'ID','AngleDeg','RangeBin','DopplerBin','PeriodicScore','BestSpacing','MatchedPeaks','SpectrumWidth','DecisionReason','IsUAV','ClassLabel'});
        if isempty(rows), rows = newRow; else, rows = [rows; newRow]; end %#ok<AGROW>
    end
end
if isempty(rows), rows = empty_estimate_table_local(); end
oneMethod.allEstimate = rows;
oneMethod.afterNoiseRemoval = rows(rows.ClassLabel ~= "Rejected",:);
oneMethod.uavEstimateRaw = rows(rows.IsUAV,:);
oneMethod.uavEstimate = merge_duplicate_uav_estimates_local(oneMethod.uavEstimateRaw, opts.uavMergeRule);
oneMethod.frameworkKey = "range_super_resolution_subspace3d_ad_multipeak";
oneMethod.sourceNumberPrior = K0prior;
oneMethod.estimatedSourceNumber = Kr;
oneMethod.eigenValues = eigVals;
oneMethod.rangeSpectrum = rangeSpectrum;
oneMethod.rangeGrid = ss.rangeGrid;
end
function [P_AD, beamDoppler] = make_angle_doppler_energy_map_local(Y, thetaGrid)
M = size(Y,1);
ND = size(Y,2);
P_AD = zeros(numel(thetaGrid), ND);
beamDoppler = zeros(numel(thetaGrid), ND);
for tt = 1:numel(thetaGrid)
    a = steering_ula_local(M, thetaGrid(tt));
    g = conj(a)' * Y;
    beamDoppler(tt,:) = g;
    P_AD(tt,:) = abs(g).^2;
end
P_AD = P_AD / (max(P_AD(:)) + eps);
end

function peakList = select_ad_peaks_local(P_AD, thetaGrid, ss)
[nTheta, nDoppler] = size(P_AD);
peakRows = [];
thr = ss.adPeakRelThreshold * max(P_AD(:));
for tt = 2:nTheta-1
    for dd = 2:nDoppler-1
        val = P_AD(tt,dd);
        if val < thr
            continue;
        end
        localPatch = P_AD(tt-1:tt+1, dd-1:dd+1);
        if val >= max(localPatch(:))
            peakRows = [peakRows; tt, dd, val]; %#ok<AGROW>
        end
    end
end
if isempty(peakRows)
    [val,idx] = max(P_AD(:));
    if isfinite(val) && val > 0
        [tt,dd] = ind2sub(size(P_AD), idx);
        peakRows = [tt, dd, val];
    end
end
if isempty(peakRows)
    peakList = zeros(0,2);
    return;
end
[~,ord] = sort(peakRows(:,3), 'descend');
peakRows = peakRows(ord,:);
peakList = zeros(0,2);
for ii = 1:size(peakRows,1)
    tt = peakRows(ii,1);
    dd = peakRows(ii,2);
    if isempty(peakList)
        keep = true;
    else
        angleSep = abs(thetaGrid(tt) - thetaGrid(peakList(:,1))).';
        dopSep = abs(dd - peakList(:,2)).';
        keep = all(angleSep >= ss.minAnglePeakDistanceDeg | dopSep >= ss.minDopplerPeakDistance);
    end
    if keep
        peakList(end+1,:) = [tt, dd]; %#ok<AGROW>
    end
    if size(peakList,1) >= ss.maxADPeaksPerRange
        break;
    end
end
end
function ss = get_subspace_opts_local(opts, M, NR, ND, K0prior, expectedPhysicalCount)
if isfield(opts,'subspace3D'), ss = opts.subspace3D; else, ss = struct(); end
expectedPhysicalCount = max(1, expectedPhysicalCount);
ss.Kmin = get_field_default_local(ss,'Kmin',max(1,expectedPhysicalCount-2));
ss.Kmax = get_field_default_local(ss,'Kmax',min(NR-2,expectedPhysicalCount+3));
ss.maxComponents = get_field_default_local(ss,'maxComponents',min(NR-2,expectedPhysicalCount+2));
ss.rangeGrid = get_field_default_local(ss,'rangeGrid',2:0.5:(NR-1));
ss.minRangeDistance = get_field_default_local(ss,'minRangeDistance',1.5);
ss.spacingGrid = get_field_default_local(ss,'spacingGrid',[4 5 6 7 8]);
ss.searchHalfWidth = get_field_default_local(ss,'searchHalfWidth',2);
ss.minMatchedPeaks = get_field_default_local(ss,'minMatchedPeaks',2);
ss.minPeriodicScore = get_field_default_local(ss,'minPeriodicScore',0.15);
ss.uavMinWidth = get_field_default_local(ss,'uavMinWidth',4);
ss.uavMaxWidth = get_field_default_local(ss,'uavMaxWidth',34);
ss.objectMaxWidth = get_field_default_local(ss,'objectMaxWidth',3);
ss.noiseWidthMax = get_field_default_local(ss,'noiseWidthMax',48);
ss.minSideEnergyRatio = get_field_default_local(ss,'minSideEnergyRatio',0.12);
ss.rangeWinHalf = get_field_default_local(ss,'rangeWinHalf',2);
ss.adPeakRelThreshold = get_field_default_local(ss,'adPeakRelThreshold',0.05);
ss.maxADPeaksPerRange = get_field_default_local(ss,'maxADPeaksPerRange',5);
ss.minAnglePeakDistanceDeg = get_field_default_local(ss,'minAnglePeakDistanceDeg',3);
ss.minDopplerPeakDistance = get_field_default_local(ss,'minDopplerPeakDistance',4);
ss.angleDopplerWinDeg = get_field_default_local(ss,'angleDopplerWinDeg',3);
ss.dopplerFloorFraction = get_field_default_local(ss,'dopplerFloorFraction',0.25);
ss.sigma_R = opts.sigma_R;
ss.sigma_D = opts.sigma_D_u;
ss.M = M; ss.NR = NR; ss.ND = ND;
end

function p = gaussian_music_grid_spectrum_local(En, gridVals, N, sigmaVal)
p = zeros(numel(gridVals),1);
Pn = En * En';
for ii = 1:numel(gridVals)
    g = gaussian_response_local(N, gridVals(ii), sigmaVal);
    p(ii) = 1 / real(conj(g)' * Pn * g + eps);
end
p = p / (max(p) + eps);
end

function peakVals = select_separated_grid_peaks_local(p, gridVals, maxPeaks, minDistance)
p = p(:); gridVals = gridVals(:); cand = [];
for ii = 2:numel(p)-1
    if p(ii) >= p(ii-1) && p(ii) >= p(ii+1)
        cand = [cand; ii, p(ii)]; %#ok<AGROW>
    end
end
if isempty(cand)
    [~,idx] = max(p);
    if isempty(idx) || ~isfinite(p(idx)), peakVals = []; else, peakVals = gridVals(idx); end
    return;
end
[~,ord] = sort(cand(:,2),'descend'); cand = cand(ord,:);
peakVals = [];
for ii = 1:size(cand,1)
    val = gridVals(cand(ii,1));
    if isempty(peakVals) || all(abs(peakVals - val) >= minDistance)
        peakVals(end+1,1) = val; %#ok<AGROW>
    end
    if numel(peakVals) >= maxPeaks, break; end
end
end

function [thetaHat, gD] = estimate_angle_and_doppler_from_ad_slice_local(Y, thetaGrid)
P = zeros(numel(thetaGrid),1);
for ii = 1:numel(thetaGrid)
    a = steering_ula_local(size(Y,1), thetaGrid(ii));
    g = conj(a)' * Y;
    P(ii) = sum(abs(g).^2);
end
[~,idx] = max(P);
thetaHat = thetaGrid(idx);
a = steering_ula_local(size(Y,1), thetaHat);
gD = (conj(a)' * Y).';
gD = gD(:);
end
function Kd = estimate_source_number_mdl_gap_local(eigVals, nSnap, Kmin, Kmax)
N = numel(eigVals); Kmax = min(Kmax, N-2); Kmin = max(0, min(Kmin, Kmax));
mdl = inf(Kmax+1,1);
for k = 0:Kmax
    noiseEig = eigVals(k+1:end);
    gm = exp(mean(log(noiseEig + eps)));
    am = mean(noiseEig + eps);
    mdl(k+1) = -nSnap * (N-k) * log(gm/(am+eps) + eps) + 0.5 * k * (2*N-k) * log(max(nSnap,2));
end
[~,idx] = min(mdl(Kmin+1:Kmax+1));
Kd = Kmin + idx - 1;
if Kd < 1
    ratios = eigVals(1:Kmax) ./ (eigVals(2:Kmax+1) + eps);
    [~,Kd] = max(ratios);
end
end

function p = gaussian_music_spectrum_local(En, ND, sigmaD)
p = zeros(ND,1);
Pn = En * En';
for dd = 1:ND
    g = gaussian_response_local(ND, dd, sigmaD);
    p(dd) = 1 / real(conj(g)' * Pn * g + eps);
end
p = p / (max(p) + eps);
end

function peakBins = select_separated_1d_local(p, maxPeaks, minDistance)
p = p(:); cand = [];
for ii = 2:numel(p)-1
    if p(ii) >= p(ii-1) && p(ii) >= p(ii+1)
        cand = [cand; ii, p(ii)]; %#ok<AGROW>
    end
end
if isempty(cand), peakBins = []; return; end
[~,ord] = sort(cand(:,2),'descend'); cand = cand(ord,:);
peakBins = [];
for ii = 1:size(cand,1)
    if isempty(peakBins) || all(abs(peakBins - cand(ii,1)) >= minDistance)
        peakBins(end+1,1) = cand(ii,1); %#ok<AGROW>
    end
    if numel(peakBins) >= maxPeaks, break; end
end
end

function [thetaHat, rangeHat] = estimate_angle_range_from_slice_local(Y, thetaGrid, sigmaR)
rangeEnergy = sum(abs(Y).^2,1).';
[~,rangeHat] = max(rangeEnergy);
x = Y(:,rangeHat);
P = zeros(numel(thetaGrid),1);
for ii = 1:numel(thetaGrid)
    a = steering_ula_local(size(Y,1), thetaGrid(ii));
    P(ii) = abs(conj(a)' * x)^2;
end
[~,idx] = max(P); thetaHat = thetaGrid(idx);
end

function [isUAV, bestScore, bestSpacing, matchedPeaks, widthBins, reason] = classify_subspace_doppler_vector_local(p, center, ss)
p = p(:) / (max(p(:)) + eps);
widthBins = spectral_width_local(p, 0.90);
bestScore = -inf; bestSpacing = 0; matchedPeaks = 0;
for fr = ss.spacingGrid
    expected = center + (-3:3) * fr;
    expected = expected(expected >= 1 & expected <= numel(p));
    matched = 0; energy = 0;
    for ee = 1:numel(expected)
        lo = max(1, expected(ee)-ss.searchHalfWidth); hi = min(numel(p), expected(ee)+ss.searchHalfWidth);
        [val,~] = max(p(lo:hi));
        if val > 0.10
            matched = matched + 1;
            energy = energy + val;
        end
    end
    score = energy / max(1,numel(expected));
    if score > bestScore
        bestScore = score;
        bestSpacing = fr;
        matchedPeaks = matched;
    end
end
bodyLo = max(1, center-1); bodyHi = min(numel(p), center+1);
bodyEnergy = sum(p(bodyLo:bodyHi));
sideEnergy = max(0, sum(p) - bodyEnergy);
sideRatio = sideEnergy / (bodyEnergy + eps);
notTooWide = widthBins <= ss.uavMaxWidth;
moderateWidth = widthBins >= ss.uavMinWidth && notTooWide;
periodicLike = matchedPeaks >= ss.minMatchedPeaks && bestScore >= ss.minPeriodicScore;
spreadLike = moderateWidth && sideRatio >= ss.minSideEnergyRatio;
isUAV = notTooWide && (periodicLike || spreadLike);
if isUAV
    reason = "subspace wide/periodic Doppler spectrum";
elseif widthBins <= ss.objectMaxWidth
    reason = "subspace narrow object";
elseif widthBins > ss.noiseWidthMax
    reason = "subspace wide noise";
else
    reason = "subspace ambiguous spectrum";
end
end
function [isUAV, bestScore, bestSpacing, matchedPeaks, widthBins, reason] = classify_periodic_vector_local(p, center, ss)
p = p(:) / (max(p(:)) + eps);
widthBins = spectral_width_local(p, 0.90);
bestScore = -inf; bestSpacing = 0; matchedPeaks = 0;
for fr = ss.spacingGrid
    expected = center + (-3:3) * fr;
    expected = expected(expected >= 1 & expected <= numel(p));
    matched = 0; energy = 0;
    for ee = 1:numel(expected)
        lo = max(1, expected(ee)-ss.searchHalfWidth); hi = min(numel(p), expected(ee)+ss.searchHalfWidth);
        [val,~] = max(p(lo:hi));
        if val > 0.12
            matched = matched + 1; energy = energy + val;
        end
    end
    score = energy / max(1,numel(expected));
    if score > bestScore
        bestScore = score; bestSpacing = fr; matchedPeaks = matched;
    end
end
isUAV = matchedPeaks >= ss.minMatchedPeaks && bestScore >= ss.minPeriodicScore && widthBins >= 4 && widthBins <= 36;
if isUAV, reason = "subspace periodic Doppler peaks"; else, reason = "subspace object/noise"; end
end

function T = empty_estimate_table_local()
T = table([],[],[],[],[],[],[],[],strings(0,1),false(0,1),strings(0,1), ...
    'VariableNames', {'ID','AngleDeg','RangeBin','DopplerBin','PeriodicScore','BestSpacing','MatchedPeaks','SpectrumWidth','DecisionReason','IsUAV','ClassLabel'});
end

function y = get_field_default_local(s, name, defaultValue)
if isfield(s,name) && ~isempty(s.(name)), y = s.(name); else, y = defaultValue; end
end

function a = steering_ula_local(M, theta_deg)
m = (0:M-1).'; a = exp(1j*pi*m*sind(theta_deg)); a = a / norm(a);
end

function v = gaussian_response_local(N, center, sigma)
n = (1:N).'; v = exp(-0.5*((n-center)/sigma).^2); v = v / (norm(v)+eps);
end

function g = harmonic_doppler_atom_local(ND, d0, fr, harmonics, betaMD, sigmaD)
g = zeros(ND,1);
weights = abs(besselj(abs(harmonics), betaMD));
weights(harmonics == 0) = 1;
weights = weights / (max(weights)+eps);
for ii = 1:numel(harmonics)
    bin = d0 + harmonics(ii) * fr;
    if bin >= 1 && bin <= ND
        g = g + weights(ii) * gaussian_response_local(ND, bin, sigmaD);
    end
end
g = g / (norm(g)+eps);
end

function X = outer3_local(a,b,c)
X = zeros(numel(a),numel(b),numel(c));
for kk = 1:numel(c)
    X(:,:,kk) = a * (b.' * c(kk));
end
end

function widthBins = spectral_width_local(g, powerFraction)
p = abs(g(:)).^2; p = p/(sum(p)+eps); [~,peakIdx] = max(p); left = peakIdx; right = peakIdx; captured = p(peakIdx);
while captured < powerFraction && (left > 1 || right < numel(p))
    lp = -inf; rp = -inf;
    if left > 1, lp = p(left-1); end
    if right < numel(p), rp = p(right+1); end
    if lp >= rp, left = left - 1; captured = captured + p(left); else, right = right + 1; captured = captured + p(right); end
end
widthBins = right - left + 1;
end
function opts = fill_wrapper_defaults(opts)
if ~isfield(opts,'successThreshold') || isempty(opts.successThreshold)
    opts.successThreshold.angleDeg = 2;
    opts.successThreshold.rangeBin = 1.5;
    opts.successThreshold.dopplerBin = 2;
else
    if ~isfield(opts.successThreshold,'angleDeg'), opts.successThreshold.angleDeg = 2; end
    if ~isfield(opts.successThreshold,'rangeBin'), opts.successThreshold.rangeBin = 1.5; end
    if ~isfield(opts.successThreshold,'dopplerBin'), opts.successThreshold.dopplerBin = 2; end
end
if ~isfield(opts,'uavMergeRule') || isempty(opts.uavMergeRule)
    opts.uavMergeRule = struct();
end
if ~isfield(opts.uavMergeRule,'enable'), opts.uavMergeRule.enable = false; end
if ~isfield(opts.uavMergeRule,'angleDeg'), opts.uavMergeRule.angleDeg = 3; end
if ~isfield(opts.uavMergeRule,'rangeBin'), opts.uavMergeRule.rangeBin = 2; end
if ~isfield(opts.uavMergeRule,'dopplerBin'), opts.uavMergeRule.dopplerBin = 3; end
if ~isfield(opts.uavMergeRule,'sidebandHarmonics'), opts.uavMergeRule.sidebandHarmonics = -3:3; end
if ~isfield(opts.uavMergeRule,'spacingCandidates'), opts.uavMergeRule.spacingCandidates = [4 5 6 7 8]; end

% Local defaults needed by the independent sparse/subspace frameworks.
if ~isfield(opts,'theta_grid') || isempty(opts.theta_grid), opts.theta_grid = -60:0.1:60; end
if ~isfield(opts,'sigma_R') || isempty(opts.sigma_R), opts.sigma_R = 0.85; end
if ~isfield(opts,'sigma_D_u') || isempty(opts.sigma_D_u), opts.sigma_D_u = 0.75; end
if ~isfield(opts,'sigma_D_c') || isempty(opts.sigma_D_c), opts.sigma_D_c = 0.70; end
if ~isfield(opts,'cfarMinCandidates') || isempty(opts.cfarMinCandidates), opts.cfarMinCandidates = 20; end
if ~isfield(opts,'cfarCandidateExtra') || isempty(opts.cfarCandidateExtra), opts.cfarCandidateExtra = 10; end
if ~isfield(opts,'betaMD') || isempty(opts.betaMD), opts.betaMD = 0.8; end
if ~isfield(opts,'bodyAmp') || isempty(opts.bodyAmp), opts.bodyAmp = 1.0; end
if ~isfield(opts,'numSidebandOrder') || isempty(opts.numSidebandOrder), opts.numSidebandOrder = 3; end
if ~isfield(opts,'mdToBody_dB') || isempty(opts.mdToBody_dB), opts.mdToBody_dB = -10; end
if ~isfield(opts,'ospa') || isempty(opts.ospa), opts.ospa = struct(); end
if ~isfield(opts.ospa,'order') || isempty(opts.ospa.order), opts.ospa.order = 2; end
if ~isfield(opts.ospa,'p') || isempty(opts.ospa.p), opts.ospa.p = opts.ospa.order; end
if ~isfield(opts.ospa,'cutoff') || isempty(opts.ospa.cutoff), opts.ospa.cutoff = 3; end
end








































function oneMethod = run_rankest_tensor_framework_local(X, trad, snrDb, mc, opts, usePlateau)
if nargin < 6, usePlateau = false; end
% Tensorlab selects total CP count. UAV count is determined afterwards.
opts = rk_fill_default_opts(opts);
rb = get_field_default_local(opts, 'rankestBaseline', struct());
plateau = get_field_default_local(opts, 'rankestPlateauBaseline', struct());
plateau.minDeltaR = get_field_default_local(plateau, 'minDeltaR', 0.005);
plateau.consecutiveRequired = get_field_default_local(plateau, 'consecutiveRequired', 2);
if usePlateau
    rb.maxRank = get_field_default_local(plateau, 'hardMaxRank', 48);
    validateattributes(plateau.minDeltaR, {'numeric'}, {'scalar','finite','positive','<',1});
    validateattributes(plateau.consecutiveRequired, {'numeric'}, {'scalar','integer','positive'});
end
plateauStreak = 0;
plateauStreakCache = [];
% Use the identical raw CFAR count used by the proposed rank-growth chain.
cfarCount = get_field_default_local(trad, 'candidateCount', height(trad.allEstimate));
validateattributes(cfarCount, {'numeric'}, {'scalar','integer','nonnegative'});
minRank = max(1, cfarCount);
configuredMaxRank = get_field_default_local(rb, 'maxRank', 18);
minScanRanks = get_field_default_local(rb, 'minScanRanks', 3);
validateattributes(configuredMaxRank, {'numeric'}, {'scalar','integer','positive'});
validateattributes(minScanRanks, {'numeric'}, {'scalar','integer','>=',3});
maxRank = max(configuredMaxRank, minRank + minScanRanks - 1);
state = rng;
rngCleanup = onCleanup(@() rng(state)); %#ok<NASGU>
warningState = warning('query', 'MATLAB:nearlySingularMatrix');
warningCleanup = onCleanup(@() warning(warningState.state, ...
    'MATLAB:nearlySingularMatrix')); %#ok<NASGU>
if ~isempty(opts.seed)
    rng(opts.seed + get_field_default_local(rb, 'seedOffset', 910000) + mc - 1);
end

candidateList = zeros(0,3);
if isfield(trad, 'allEstimate') && ~isempty(trad.allEstimate)
    T = trad.allEstimate;
    rr = double(T.RangeBin); dd = double(T.DopplerBin);
    power = double(trad.candidates(:,3));
    [~, order] = sort(power, 'descend');
    candidateList = [rr(order), dd(order), power(order)];
end
cpdOptions = struct();
cpdOptions.Compression = false;
cpdOptions.Algorithm = @cpd_nls;
cpdOptions.AlgorithmOptions.Display = 0;
cpdOptions.AlgorithmOptions.MaxIter = 180;
cpdOptions.AlgorithmOptions.TolFun = 1e-9;
cpdOptions.AlgorithmOptions.TolX = 1e-7;
cpdOptions.AlgorithmOptions.CGMaxIter = 40;
numRestarts = get_field_default_local(rb, 'numRestarts', opts.numRestarts);
validateattributes(numRestarts, {'numeric'}, {'scalar','integer','positive'});

factorCache = cell(maxRank,1);
residualCache = nan(maxRank,1);
retryCache = repmat(struct('Retried',false,'RetryRounds',0,'UsedEmbeddedFit',false),maxRank,1);
rankestOptions = struct();
rankestOptions.MinR = minRank;
rankestOptions.MaxR = maxRank;
rankestOptions.MinRelErr = get_field_default_local(rb, 'minRelErr', 0);
rankestOptions.MaxRelErr = get_field_default_local(rb, 'maxRelErr', 1);
rankestOptions.XMultiplier = get_field_default_local(rb, 'xMultiplier', 1);
rankestOptions.Complex = true;
rankestOptions.Solver = @solve_one_rank;
rankestOptions.SolverOptions = struct();
if usePlateau
    rankestOptions.StopTest = @check_residual_plateau;
end
timer = tic;
[selectedRank, lowerBoundCurve, residualCurve, cornerInfo] = ...
    rankest_cfar_local(X, rankestOptions);
U = factorCache{selectedRank};
if isempty(U)
    error('RankestBaseline:MissingFit', 'No CPD factors for selected rank %d.', selectedRank);
end
allRows = rk_interpret_cpd_components(U, opts.theta_grid, opts.periodicRule);
allRows = mark_zero_weight_components_local(allRows, U);
[uavCount, objectCount, noiseCount] = rk_count_component_classes(allRows);
noiseMask = contains(string(allRows.DecisionReason),["too wide before periodic test","model-unstructured"]) | ...
    contains(string(allRows.DecisionReason), "zero-weight nonphysical component");
allRows.ClassLabel = repmat("Object", height(allRows), 1);
allRows.ClassLabel(noiseMask) = "Rejected";
allRows.ClassLabel(logical(allRows.IsUAV)) = "UAV";
oneMethod = struct();
oneMethod.allEstimate = allRows;
oneMethod.afterNoiseRemoval = allRows(~noiseMask,:);
oneMethod.uavEstimateRaw = allRows(logical(allRows.IsUAV),:);
oneMethod.uavEstimate = merge_duplicate_uav_estimates_local( ...
    oneMethod.uavEstimateRaw, opts.uavMergeRule);
oneMethod.SNR_dB = snrDb;
oneMethod = run_energy_assisted_tensor_framework_local(oneMethod, opts);
oneMethod.frameworkKey = "rankest_tensor";
if usePlateau, oneMethod.frameworkKey = "plateau_rankest_tensor"; end
oneMethod.rankInfo = struct('selectedRank', selectedRank,'inputDomain',"raw fast/slow time",'inputSize',size(X), ...
    'selectedRelres', residualCache(selectedRank), ...
    'selectedUAVCountRaw', uavCount, 'selectedObjectCount', objectCount, ...
    'selectedNoiseCount', noiseCount, 'rankList', residualCurve(:,1), ...
    'lowerBoundCurve', lowerBoundCurve, 'residualCurve', residualCurve, ...
    'elapsedSeconds', toc(timer), 'stopReason', "Tensorlab rankest L-curve corner");
oneMethod.rankInfo.K0 = minRank;
oneMethod.rankInfo.cfarCandidateCount = cfarCount;
oneMethod.rankInfo.configuredMaxRank = configuredMaxRank;
oneMethod.rankInfo.effectiveMaxRank = maxRank;
oneMethod.rankInfo.cornerFallback = cornerInfo.fallbackToFirstRank;
oneMethod.rankInfo.searchStopReason = cornerInfo.searchStopReason;
oneMethod.rankInfo.stopTriggeredRank = cornerInfo.stopTriggeredRank;
oneMethod.rankInfo.testedRanks = residualCurve(:,1);
oneMethod.rankInfo.plateauEnabled = usePlateau;
if usePlateau
    oneMethod.rankInfo.plateauThreshold = plateau.minDeltaR;
    oneMethod.rankInfo.plateauConsecutiveRequired = plateau.consecutiveRequired;
end
if cornerInfo.fallbackToFirstRank
    oneMethod.rankInfo.stopReason = "no admissible L-curve corner; returned CFAR initial rank";
end
testedRanks = residualCurve(:,1);
gains = [NaN; (residualCurve(1:end-1,2)-residualCurve(2:end,2)) ./ ...
    max(residualCurve(1:end-1,2),eps)];
oneMethod.rankInfo.diagnostics = table(testedRanks, residualCurve(:,2), gains, ...
    [retryCache(testedRanks).Retried].', [retryCache(testedRanks).RetryRounds].', ...
    [retryCache(testedRanks).UsedEmbeddedFit].', ...
    'VariableNames', {'Rank','RelResidual','DeltaR','Retried','RetryRounds','UsedEmbeddedFit'});
if usePlateau
    oneMethod.rankInfo.diagnostics.PlateauStreak = plateauStreakCache(testedRanks).';
end
oneMethod.rankMetrics = struct('selectedRank', selectedRank, ...
    'noiseCount', noiseCount, 'objectCount', objectCount);
if opts.verbose
    fprintf('Rankest MC %d: R=%d, residual=%.4g, UAV=%d, time=%.2fs\n', ...
        mc, selectedRank, residualCache(selectedRank), ...
        height(oneMethod.uavEstimate), oneMethod.rankInfo.elapsedSeconds);
end

    function stop = check_residual_plateau(ranks, errors)
        Rnow = ranks(end);
        eligible = numel(ranks) >= 2 && ranks(end) == ranks(end-1) + 1;
        if eligible
            eligible = ~retryCache(Rnow).UsedEmbeddedFit && ...
                ~retryCache(ranks(end-1)).UsedEmbeddedFit;
        end
        [plateauStreak, stop] = update_residual_plateau_local( ...
            errors, eligible, plateauStreak, plateau.minDeltaR, plateau.consecutiveRequired);
        plateauStreakCache(Rnow) = plateauStreak;
        stop = stop && numel(ranks) >= minScanRanks;
    end

    function [Ufit, output] = solve_one_rank(T, R, varargin) %#ok<INUSD>
        % rankest adds solver options; fitting settings are shared with the base.
        [Ufit, relres] = rk_run_cpd_best_of_restarts(T, size(T), R, ...
            candidateList, opts.theta_grid, cpdOptions, numRestarts);
        previous = [];
        if R > minRank && ~isempty(factorCache{R-1})
            previous = struct('U',{factorCache{R-1}},'relres',residualCache(R-1));
        end
        maxRetryRounds = get_field_default_local(rb, 'maxRetryRounds', 3);
        validateattributes(maxRetryRounds, {'numeric'}, {'scalar','integer','positive'});
        [Ufit, relres, retryCache(R)] = ensure_monotone_cpd_local(T, Ufit, previous, R, ...
            candidateList, opts.theta_grid, cpdOptions, numRestarts, maxRetryRounds);
        if isempty(Ufit) || ~isfinite(relres)
            error('RankestBaseline:CPDFailed', ...
                'All CPD restarts failed at the initial tested rank %d.', R);
        end
        factorCache{R} = Ufit;
        residualCache(R) = relres;
        output.Algorithm.relerr = max(relres, realmin);
    end
end

% Original base utilities, copied without behavioral changes for rankest.

function opts = rk_fill_default_opts(opts)
if ~isfield(opts,'seed'), opts.seed = 20260605; end
if ~isfield(opts,'verbose'), opts.verbose = true; end
if ~isfield(opts,'numRestarts'), opts.numRestarts = 4; end
if ~isfield(opts,'doTensor'), opts.doTensor = true; end
if ~isfield(opts,'successThreshold')
    opts.successThreshold.angleDeg = 5;
    opts.successThreshold.rangeBin = 3;
    opts.successThreshold.dopplerBin = 4;
end

opts.M = rk_get_opt(opts,'M',16);
opts.NR = rk_get_opt(opts,'NR',96);
opts.ND = rk_get_opt(opts,'ND',128);
opts.theta_grid = rk_get_opt(opts,'theta_grid',-60:0.1:60);
opts.sigma_R = rk_get_opt(opts,'sigma_R',0.85);
opts.sigma_D_u = rk_get_opt(opts,'sigma_D_u',0.75);
opts.sigma_D_c = rk_get_opt(opts,'sigma_D_c',0.70);
opts.uavAlphaRange = rk_get_opt(opts,'uavAlphaRange',[0.75 1.00]);
opts.clutterAlphaRange = rk_get_opt(opts,'clutterAlphaRange',[0.20 0.40]);
opts.cfarCandidateExtra = rk_get_opt(opts,'cfarCandidateExtra',10);
opts.cfarMinCandidates = rk_get_opt(opts,'cfarMinCandidates',20);
opts.adjacentDopplerBins = rk_get_opt(opts,'adjacentDopplerBins',-2:2);
opts.tradRangeNeighborhood = rk_get_opt(opts,'tradRangeNeighborhood',-2:2);
opts.tradDopplerNeighborhood = rk_get_opt(opts,'tradDopplerNeighborhood',-8:8);

mergeRule.angleDeg = 3;
mergeRule.rangeBin = 2;
mergeRule.dopplerBin = 3;
mergeRule.sidebandHarmonics = -3:3;
mergeRule.spacingCandidates = [5 6 7 8];
mergeRule.maxGroupSize = inf;
opts.uavMergeRule = rk_get_opt(opts,'uavMergeRule',mergeRule);

opts.bodyAmp = rk_get_opt(opts,'bodyAmp',1.0);
opts.betaMD = rk_get_opt(opts,'betaMD',0.8);
opts.numSidebandOrder = rk_get_opt(opts,'numSidebandOrder',3);
opts.mdToBody_dB = rk_get_opt(opts,'mdToBody_dB',-10);
opts.uavSidebandAmps = rk_get_opt(opts,'uavSidebandAmps',rk_make_bessel_sideband_amps(opts.bodyAmp, opts.betaMD, opts.numSidebandOrder, opts.mdToBody_dB));

rule.frCandidates = 1:10;
rule.searchHalfWidth = 2;
rule.peakRelThreshold = 0.04;
rule.minPeakDistance = 2;
rule.minMatchedPeaks = 3;
rule.spacingTolerance = 1;
rule.matchedEnergyHalfWidth = 1;
rule.minPeriodicScore = 0.30;
rule.maxPeriodicityError = 0.95;
rule.minWidthBins = 5;
rule.maxWidthBins = 30;
rule.widthPowerFraction = 0.90;
opts.periodicRule = rk_get_opt(opts,'periodicRule',rule);
end

function uavSidebandAmps = rk_make_bessel_sideband_amps(bodyAmp, betaMD, numSidebandOrder, mdToBody_dB)
% Body amplitude is fixed, while all micro-Doppler sidebands are scaled so
% that their total energy has the target MD-to-body energy ratio.
if numSidebandOrder ~= 3
    error('This simulation currently expects numSidebandOrder = 3.');
end
J1 = abs(besselj(1, betaMD));
J2 = abs(besselj(2, betaMD));
J3 = abs(besselj(3, betaMD));
baseSidebands = [J1, J1, J2, J2, J3, J3];
P0 = sum(baseSidebands.^2);
if P0 <= eps
    sidebands = zeros(size(baseSidebands));
else
    alpha = sqrt(10^(mdToBody_dB/10) * bodyAmp^2 / P0);
    sidebands = alpha * baseSidebands;
end
uavSidebandAmps = [bodyAmp, sidebands];
end

function v = rk_get_opt(s, name, defaultValue)
if isfield(s,name)
    v = s.(name);
else
    v = defaultValue;
end
end

function [uavCount, objectCount, noiseCount] = rk_count_component_classes(T)
if isempty(T) || height(T) == 0
    uavCount = 0; objectCount = 0; noiseCount = 0; return;
end
isNoise = contains(string(T.DecisionReason),["too wide before periodic test","model-unstructured"]) | ...
    contains(string(T.DecisionReason), "zero-weight nonphysical component");
uavCount = nnz(T.IsUAV & ~isNoise);
objectCount = nnz(~T.IsUAV & ~isNoise);
noiseCount = nnz(isNoise);
end

function a = rk_steering_ula(M, theta_deg)
m = (0:M-1).'; a = exp(1j*pi*m*sind(theta_deg)); a = a / norm(a);
end

function v = rk_gaussian_response(N, center, sigma)
n = (1:N).'; v = exp(-0.5*((n-center)/sigma).^2); v = v / norm(v);
end

function P = rk_angle_spectrum(x, theta_grid)
M = numel(x); P = zeros(numel(theta_grid),1);
for ii = 1:numel(theta_grid), P(ii) = abs(rk_steering_ula(M, theta_grid(ii))' * x)^2; end
end

function [isUAV,bestScore,bestSpacing,matchedPeaks,widthBins,reason] = rk_classify_hybrid_peaks(g,rule,forcedCenter)
if nargin<3, forcedCenter=[]; end
widthBins=rk_spectral_width_bins(g,rule.widthPowerFraction);
if widthBins<rule.minWidthBins, isUAV=false; bestScore=0; bestSpacing=0; matchedPeaks=0; reason="too narrow before periodic test"; return; end
if widthBins>rule.maxWidthBins, isUAV=false; bestScore=0; bestSpacing=0; matchedPeaks=0; reason="too wide before periodic test"; return; end
[isUAV,bestScore,bestSpacing,matchedPeaks,periodicReason]=rk_classify_periodic_peaks(g,rule,forcedCenter);
if isUAV, reason="medium width + periodic peaks"; else, reason="medium width but "+periodicReason; end
end

function widthBins=rk_spectral_width_bins(g,powerFraction)
p=abs(g(:)).^2; p=p/(sum(p)+eps); [~,peakIdx]=max(p); left=peakIdx; right=peakIdx; captured=p(peakIdx);
while captured<powerFraction && (left>1 || right<numel(p))
    lp=-inf; rp=-inf; if left>1, lp=p(left-1); end; if right<numel(p), rp=p(right+1); end
    if lp>=rp, left=left-1; captured=captured+p(left); else, right=right+1; captured=captured+p(right); end
end
widthBins=right-left+1;
end

function [isUAV,bestScore,bestSpacing,matchedPeaks,reason]=rk_classify_periodic_peaks(g,rule,forcedCenter)
if nargin<3, forcedCenter=[]; end
[isUAV,bestScore,bestSpacing,matchedPeaks,reason]=classify_periodic_unique_local(g,rule,forcedCenter);
end

function [peakIdx,peakVal]=rk_simple_find_peaks(y,relThreshold,minDistance)
y=y(:); peakIdx=[]; peakVal=[]; threshold=relThreshold*max(y+eps);
for ii=2:(numel(y)-1), if y(ii)>=threshold && y(ii)>=y(ii-1) && y(ii)>y(ii+1), peakIdx(end+1,1)=ii; peakVal(end+1,1)=y(ii); end, end %#ok<AGROW>
if isempty(peakIdx), return; end
[peakVal,ord]=sort(peakVal,'descend'); peakIdx=peakIdx(ord); keepIdx=[]; keepVal=[];
for ii=1:numel(peakIdx), if isempty(keepIdx)||all(abs(peakIdx(ii)-keepIdx)>=minDistance), keepIdx(end+1,1)=peakIdx(ii); keepVal(end+1,1)=peakVal(ii); end, end %#ok<AGROW>
[peakIdx,ord]=sort(keepIdx,'ascend'); peakVal=keepVal(ord);
end

function T=rk_interpret_cpd_components(U,theta_grid,rule)
T=timed_interpret_cpd_components(U,theta_grid,rule);
end

function [bestU,bestRelres]=rk_run_cpd_best_of_restarts(X,size_tens,K,candidateList,theta_grid,cpd_options,numRestarts) %#ok<INUSD>
[bestU,bestRelres]=shared_cpd_1542_local('fit',X,K,candidateList,theta_grid,cpd_options);
end

function Uinit=rk_init_from_candidates(size_tens,K,candidateList,theta_grid)
Uinit=timed_init_from_candidates(size_tens,K,candidateList,theta_grid);
end

function [Un,lambda]=rk_normalize_cpd_factors(U)
Nmode=numel(U); R=size(U{1},2); Un=U; lambda=ones(1,R);
for r=1:R, for n=1:Nmode, sc=norm(Un{n}(:,r)); if sc<eps, sc=1; end; Un{n}(:,r)=Un{n}(:,r)/sc; lambda(r)=lambda(r)*sc; end, end
end



function oneMethod = run_oracle_tensor_framework_local(X, trad, oracleRank, snrDb, mc, opts)
% Oracle supplies only the generated total component count, not class labels.
timer = tic;
opts = rk_fill_default_opts(opts);
rb = get_field_default_local(opts, 'oracleBaseline', struct());
validateattributes(oracleRank, {'numeric'}, {'scalar','integer','positive'});
state = rng;
rngCleanup = onCleanup(@() rng(state)); %#ok<NASGU>
warningState = warning('query', 'MATLAB:nearlySingularMatrix');
warningCleanup = onCleanup(@() warning(warningState.state, ...
    'MATLAB:nearlySingularMatrix')); %#ok<NASGU>
if ~isempty(opts.seed)
    rng(opts.seed + get_field_default_local(rb, 'seedOffset', 920000) + mc - 1);
end

candidateList = zeros(0,3);
if isfield(trad, 'allEstimate') && ~isempty(trad.allEstimate)
    T = trad.allEstimate;
    rr = double(T.RangeBin); dd = double(T.DopplerBin);
    power = double(trad.candidates(:,3));
    [~, order] = sort(power, 'descend');
    candidateList = [rr(order), dd(order), power(order)];
end
cpdOptions = struct();
cpdOptions.Compression = false;
cpdOptions.Algorithm = @cpd_nls;
cpdOptions.AlgorithmOptions.Display = 0;
cpdOptions.AlgorithmOptions.MaxIter = 180;
cpdOptions.AlgorithmOptions.TolFun = 1e-9;
cpdOptions.AlgorithmOptions.TolX = 1e-7;
cpdOptions.AlgorithmOptions.CGMaxIter = 40;
numRestarts = get_field_default_local(rb, 'numRestarts', opts.numRestarts);
validateattributes(numRestarts, {'numeric'}, {'scalar','integer','positive'});

[U, relres] = rk_run_cpd_best_of_restarts(X, size(X), oracleRank, ...
    candidateList, opts.theta_grid, cpdOptions, numRestarts);
if isempty(U) || ~isfinite(relres)
    error('OracleBaseline:CPDFailed', 'All CPD restarts failed at oracle rank %d.', oracleRank);
end
allRows = rk_interpret_cpd_components(U, opts.theta_grid, opts.periodicRule);
allRows = mark_zero_weight_components_local(allRows,U);
[uavCount, objectCount, noiseCount] = rk_count_component_classes(allRows);
noiseMask = contains(string(allRows.DecisionReason),["too wide before periodic test","model-unstructured"]) | ...
    contains(string(allRows.DecisionReason), "zero-weight nonphysical component");
allRows.ClassLabel = repmat("Object", height(allRows), 1);
allRows.ClassLabel(noiseMask) = "Rejected";
allRows.ClassLabel(logical(allRows.IsUAV)) = "UAV";
oneMethod = struct();
oneMethod.allEstimate = allRows;
oneMethod.afterNoiseRemoval = allRows(~noiseMask,:);
oneMethod.uavEstimateRaw = allRows(logical(allRows.IsUAV),:);
oneMethod.uavEstimate = merge_duplicate_uav_estimates_local( ...
    oneMethod.uavEstimateRaw, opts.uavMergeRule);
oneMethod.SNR_dB = snrDb;
oneMethod = run_energy_assisted_tensor_framework_local(oneMethod, opts);
oneMethod.frameworkKey = "oracle_rank_tensor";
oneMethod.rankInfo = struct('selectedRank', oracleRank, 'selectedRelres', relres,'inputDomain',"raw fast/slow time",'inputSize',size(X), ...
    'selectedUAVCountRaw', uavCount, 'selectedObjectCount', objectCount, ...
    'selectedNoiseCount', noiseCount, 'rankList', oracleRank, ...
    'elapsedSeconds', toc(timer), 'stopReason', "Known total physical component count");
oneMethod.rankInfo.diagnostics = table(oracleRank, relres, ...
    'VariableNames', {'Rank','RelResidual'});
oneMethod.rankMetrics = struct('selectedRank', oracleRank, ...
    'noiseCount', noiseCount, 'objectCount', objectCount);
end

% Original simulation/detection base, instrumented locally for full timing.
function out = timed_f_newtype_202607111114_base(Nu, Nc, Nn, SNR_dB, numMC, opts)
%f_newtype_202606161534 Monte Carlo UAV detection experiment with radar performance metrics, UAV/clutter confusion metrics, and MD-to-body sideband control.
%
% out = f_newtype_202606161534(Nu, Nc, Nn, SNR_dB, numMC)
%
% Inputs:
%   Nu      - number of UAV targets
%   Nc      - number of clutter components
%   Nn      - number of close UAV-clutter pairs
%   SNR_dB  - signal-to-noise ratio in dB
%   numMC   - Monte Carlo repetitions
%   opts    - optional struct
%
% Detection success definition:
%   An estimated UAV is successful if its nearest true UAV satisfies:
%     angle error   < 5 deg
%     range error   < 3 bins
%     Doppler error < 4 bins
%
% Outputs:
%   out.scene{k}.trueUAV / trueClutter
%   out.traditional{k}.uavEstimate / allEstimate
%   out.tensor{k}.uavEstimate / allEstimate
%   out.summary.traditional / tensor include Pd, Pm, false alarm, Precision, F1, and RMSE metrics; UAV outputs retain separate classified components when merging is disabled

if nargin < 6
    opts = struct();
end

if exist('cpd','file') ~= 2 || exist('cpdgen','file') ~= 2
    error('Cannot find Tensorlab cpd()/cpdgen(). Please add Tensorlab to MATLAB path.');
end

opts = timed_fill_default_opts(opts);

out = struct();
out.inputs.Nu = Nu;
out.inputs.Nc = Nc;
out.inputs.Nn = Nn;
out.inputs.SNR_dB = SNR_dB;
out.inputs.numMC = numMC;
out.opts = opts;

tradAgg = timed_init_metric_aggregate();
tensorAgg = timed_init_metric_aggregate();
rankAgg = timed_init_rank_metric_aggregate();
tradConfAgg = timed_init_confusion_aggregate();
tensorConfAgg = timed_init_confusion_aggregate();
totalUAV = Nu * numMC;

out.scene = cell(numMC,1);
out.traditional = cell(numMC,1);
out.tensor = cell(numMC,1);
out.metricPerMC = table();
out.sharedAudit=cell(numMC,1);

for mc = 1:numMC
    if ~isempty(opts.seed)
        rng(opts.seed + mc - 1);
    end

    one = timed_run_one_trial(Nu, Nc, Nn, SNR_dB, opts);

    tradMetrics = timed_evaluate_detection_metrics_sideband(one.traditional.uavEstimate, one.trueUAV, opts.successThreshold);
    tensorMetrics = timed_evaluate_detection_metrics_body(one.tensor.uavEstimate, one.trueUAV, opts.successThreshold);
    tradConfMetrics = timed_evaluate_uav_clutter_confusion_sideband(one.traditional.uavEstimate, one.trueUAV, one.trueClutter, opts.successThreshold);
    tensorConfMetrics = timed_evaluate_uav_clutter_confusion_body(one.tensor.uavEstimate, one.trueUAV, one.trueClutter, opts.successThreshold);
    tensorRankMetrics = timed_evaluate_rank_component_metrics(one.tensor.uavEstimate, one.trueUAV, opts.successThreshold);
    tensorRankMetrics.selectedRank = one.tensor.rankInfo.selectedRank;
    tensorRankMetrics.K0 = one.tensor.rankInfo.K0;
    tensorRankMetrics.noiseCount = one.tensor.rankInfo.selectedNoiseCount;
    tensorRankMetrics.objectCount = one.tensor.rankInfo.selectedObjectCount;
    tensorRankMetrics.deltaRAtSelected = one.tensor.rankInfo.selectedDeltaR;

    tradAgg = timed_update_metric_aggregate(tradAgg, tradMetrics);
    tensorAgg = timed_update_metric_aggregate(tensorAgg, tensorMetrics);
    rankAgg = timed_update_rank_metric_aggregate(rankAgg, tensorRankMetrics);
    tradConfAgg = timed_update_confusion_aggregate(tradConfAgg, tradConfMetrics);
    tensorConfAgg = timed_update_confusion_aggregate(tensorConfAgg, tensorConfMetrics);

    one.traditional.metrics = tradMetrics;
    one.traditional.confusionMetrics = tradConfMetrics;
    one.traditional.successCount = tradMetrics.truePositive;
    one.traditional.successRate = tradMetrics.Pd;
    one.tensor.metrics = tensorMetrics;
    one.tensor.confusionMetrics = tensorConfMetrics;
    one.tensor.rankMetrics = tensorRankMetrics;
    one.tensor.successCount = tensorMetrics.truePositive;
    one.tensor.successRate = tensorMetrics.Pd;

    out.scene{mc}.trueUAV = one.trueUAV;
    out.scene{mc}.trueClutter = one.trueClutter;
    if isfield(one, 'X'), out.scene{mc}.X = one.X; end
    if isfield(one, 'X_clean'), out.scene{mc}.X_clean = one.X_clean; end
    out.traditional{mc} = one.traditional;
    out.tensor{mc} = one.tensor;

    out.metricPerMC = [out.metricPerMC; ...
        timed_metrics_to_row(mc, "Traditional", tradMetrics); ...
        timed_metrics_to_row(mc, "Tensor", tensorMetrics)]; %#ok<AGROW>

    if opts.verbose
        fprintf('MC %d/%d: traditional %d/%d, tensor %d/%d, FA(trad/tensor)=%d/%d\n', ...
            mc, numMC, tradMetrics.truePositive, Nu, tensorMetrics.truePositive, Nu, ...
            tradMetrics.falseAlarm, tensorMetrics.falseAlarm);
        timed_print_mc_uav_tables(one.trueUAV, one.traditional.uavEstimate, one.tensor.uavEstimate);
        fprintf('  Tensor rank: K0=%d, selected=%d, stop=%s, RhatUAV=%d, ER=%d\n', ...
            one.tensor.rankInfo.K0, one.tensor.rankInfo.selectedRank, string(one.tensor.rankInfo.stopReason), ...
            tensorRankMetrics.RhatUAV, tensorRankMetrics.rankError);
    end
end

out.summary.traditional = timed_finalize_metric_aggregate(tradAgg, numMC);
out.summary.tensor = timed_finalize_metric_aggregate(tensorAgg, numMC);
out.summary.totalUAV = totalUAV;
out.summary.tensorRank = timed_finalize_rank_metric_aggregate(rankAgg, numMC);
out.summary.traditionalConfusion = timed_finalize_confusion_aggregate(tradConfAgg);
out.summary.tensorConfusion = timed_finalize_confusion_aggregate(tensorConfAgg);

out.summary.traditionalSuccessCount = out.summary.traditional.truePositive;
out.summary.tensorSuccessCount = out.summary.tensor.truePositive;
out.summary.traditionalSuccessRate = out.summary.traditional.Pd;
out.summary.tensorSuccessRate = out.summary.tensor.Pd;
end

function agg = timed_init_metric_aggregate()
agg.trueTarget = 0;
agg.estimateCount = 0;
agg.truePositive = 0;
agg.falseAlarm = 0;
agg.missed = 0;
agg.angleSqErr = [];
agg.rangeSqErr = [];
agg.dopplerSqErr = [];
end

function agg = timed_update_metric_aggregate(agg, m)
agg.trueTarget = agg.trueTarget + m.trueTarget;
agg.estimateCount = agg.estimateCount + m.estimateCount;
agg.truePositive = agg.truePositive + m.truePositive;
agg.falseAlarm = agg.falseAlarm + m.falseAlarm;
agg.missed = agg.missed + m.missed;
agg.angleSqErr = [agg.angleSqErr; m.angleSqErr(:)];
agg.rangeSqErr = [agg.rangeSqErr; m.rangeSqErr(:)];
agg.dopplerSqErr = [agg.dopplerSqErr; m.dopplerSqErr(:)];
end

function s = timed_finalize_metric_aggregate(agg, numMC)
s = agg;
s.Pd = timed_safe_divide(agg.truePositive, agg.trueTarget);
s.Pm = timed_safe_divide(agg.missed, agg.trueTarget);
s.falseAlarmRatePerTruth = timed_safe_divide(agg.falseAlarm, agg.trueTarget);
s.avgFalseAlarmPerMC = timed_safe_divide(agg.falseAlarm, numMC);
s.precision = timed_safe_divide(agg.truePositive, agg.estimateCount);
s.recall = s.Pd;
s.F1 = timed_safe_divide(2*s.precision*s.recall, s.precision + s.recall);
s.angleRMSE = sqrt(timed_mean_or_nan(agg.angleSqErr));
s.rangeRMSE = sqrt(timed_mean_or_nan(agg.rangeSqErr));
s.dopplerRMSE = sqrt(timed_mean_or_nan(agg.dopplerSqErr));
end

function row = timed_metrics_to_row(mc, methodName, m)
row = table(mc, string(methodName), m.trueTarget, m.estimateCount, m.truePositive, ...
    m.falseAlarm, m.missed, m.Pd, m.Pm, m.precision, m.F1, ...
    m.angleRMSE, m.rangeRMSE, m.dopplerRMSE, ...
    'VariableNames', {'MC','Method','TrueTarget','EstimateCount','TruePositive','FalseAlarm','Missed','Pd','Pm','Precision','F1','AngleRMSE','RangeRMSE','DopplerRMSE'});
end

function y = timed_safe_divide(a,b)
if b == 0
    y = NaN;
else
    y = a / b;
end
end

function y = timed_mean_or_nan(x)
if isempty(x)
    y = NaN;
else
    y = mean(x);
end
end

function m = timed_evaluate_detection_metrics_sideband(estTable, trueUAV, thr)
m = timed_evaluate_detection_metrics_common(estTable, trueUAV, thr, true);
end

function m = timed_evaluate_detection_metrics_body(estTable, trueUAV, thr)
m = timed_evaluate_detection_metrics_common(estTable, trueUAV, thr, false);
end

function m = timed_evaluate_detection_metrics_common(estTable, trueUAV, thr, sidebandAware)
trueTarget = height(trueUAV);
if isempty(estTable)
    estimateCount = 0;
else
    estimateCount = height(estTable);
end
usedTruth = false(trueTarget,1);
truePositive = 0;
angleSqErr = [];
rangeSqErr = [];
dopplerSqErr = [];

for ii = 1:estimateCount
    da = abs(estTable.AngleDeg(ii) - trueUAV.AngleDeg);
    dr = abs(estTable.RangeBin(ii) - trueUAV.RangeBin);
    dd = zeros(trueTarget,1);
    for uu = 1:trueTarget
        if sidebandAware
            centers = trueUAV.DopplerBin(uu) + (-3:3) * trueUAV.MicroDopplerSpacing(uu);
            dd(uu) = min(abs(estTable.DopplerBin(ii) - centers));
        else
            dd(uu) = abs(estTable.DopplerBin(ii) - trueUAV.DopplerBin(uu));
        end
    end
    valid = da < thr.angleDeg & dr < thr.rangeBin & dd < thr.dopplerBin & ~usedTruth;
    if any(valid)
        score = da/max(thr.angleDeg,eps) + dr/max(thr.rangeBin,eps) + dd/max(thr.dopplerBin,eps);
        score(~valid) = inf;
        [~, idx] = min(score);
        usedTruth(idx) = true;
        truePositive = truePositive + 1;
        angleSqErr(end+1,1) = da(idx)^2; %#ok<AGROW>
        rangeSqErr(end+1,1) = dr(idx)^2; %#ok<AGROW>
        dopplerSqErr(end+1,1) = dd(idx)^2; %#ok<AGROW>
    end
end

falseAlarm = estimateCount - truePositive;
missed = trueTarget - truePositive;
m.trueTarget = trueTarget;
m.estimateCount = estimateCount;
m.truePositive = truePositive;
m.falseAlarm = falseAlarm;
m.missed = missed;
m.Pd = timed_safe_divide(truePositive, trueTarget);
m.Pm = timed_safe_divide(missed, trueTarget);
m.precision = timed_safe_divide(truePositive, estimateCount);
m.recall = m.Pd;
m.F1 = timed_safe_divide(2*m.precision*m.recall, m.precision + m.recall);
m.angleRMSE = sqrt(timed_mean_or_nan(angleSqErr));
m.rangeRMSE = sqrt(timed_mean_or_nan(rangeSqErr));
m.dopplerRMSE = sqrt(timed_mean_or_nan(dopplerSqErr));
m.angleSqErr = angleSqErr;
m.rangeSqErr = rangeSqErr;
m.dopplerSqErr = dopplerSqErr;
end
function agg = timed_init_confusion_aggregate()
agg.trueUAV = 0;
agg.trueClutter = 0;
agg.estimateUAV = 0;
agg.TP_UAV = 0;
agg.FN_UAV = 0;
agg.FP_clutter_as_UAV = 0;
agg.FP_ghost = 0;
agg.TN_clutter = 0;
end

function agg = timed_update_confusion_aggregate(agg, m)
agg.trueUAV = agg.trueUAV + m.trueUAV;
agg.trueClutter = agg.trueClutter + m.trueClutter;
agg.estimateUAV = agg.estimateUAV + m.estimateUAV;
agg.TP_UAV = agg.TP_UAV + m.TP_UAV;
agg.FN_UAV = agg.FN_UAV + m.FN_UAV;
agg.FP_clutter_as_UAV = agg.FP_clutter_as_UAV + m.FP_clutter_as_UAV;
agg.FP_ghost = agg.FP_ghost + m.FP_ghost;
agg.TN_clutter = agg.TN_clutter + m.TN_clutter;
end

function s = timed_finalize_confusion_aggregate(agg)
s = agg;
s.Pd = timed_safe_divide(agg.TP_UAV, agg.trueUAV);
s.Pm = timed_safe_divide(agg.FN_UAV, agg.trueUAV);
s.Pfa_UAV = timed_safe_divide(agg.FP_clutter_as_UAV, agg.trueClutter);
s.precision = timed_safe_divide(agg.TP_UAV, agg.TP_UAV + agg.FP_clutter_as_UAV + agg.FP_ghost);
s.recall = s.Pd;
s.F1 = timed_safe_divide(2*s.precision*s.recall, s.precision + s.recall);
end

function m = timed_evaluate_uav_clutter_confusion_sideband(estTable, trueUAV, trueClutter, thr)
m = timed_evaluate_uav_clutter_confusion_common(estTable, trueUAV, trueClutter, thr, true);
end

function m = timed_evaluate_uav_clutter_confusion_body(estTable, trueUAV, trueClutter, thr)
m = timed_evaluate_uav_clutter_confusion_common(estTable, trueUAV, trueClutter, thr, false);
end

function m = timed_evaluate_uav_clutter_confusion_common(estTable, trueUAV, trueClutter, thr, sidebandAware)
Nu = height(trueUAV);
Nc = height(trueClutter);
if isempty(estTable)
    estimateCount = 0;
else
    estimateCount = height(estTable);
end
usedUAV = false(Nu,1);
usedClutter = false(Nc,1);
TP = 0;
FPc = 0;
FPg = 0;

for ii = 1:estimateCount
    [uavMatch, uavIdx, uavScore] = timed_find_best_uav_match(estTable(ii,:), trueUAV, thr, sidebandAware, usedUAV);
    if uavMatch
        usedUAV(uavIdx) = true;
        TP = TP + 1;
        continue;
    end

    [clutterMatch, clutterIdx, clutterScore] = timed_find_best_clutter_match(estTable(ii,:), trueClutter, thr, usedClutter); %#ok<ASGLU>
    if clutterMatch
        usedClutter(clutterIdx) = true;
        FPc = FPc + 1;
    else
        FPg = FPg + 1;
    end
end

FN = Nu - TP;
TN = Nc - FPc;
m.trueUAV = Nu;
m.trueClutter = Nc;
m.estimateUAV = estimateCount;
m.TP_UAV = TP;
m.FN_UAV = FN;
m.FP_clutter_as_UAV = FPc;
m.FP_ghost = FPg;
m.TN_clutter = TN;
m.Pd = timed_safe_divide(TP, Nu);
m.Pm = timed_safe_divide(FN, Nu);
m.Pfa_UAV = timed_safe_divide(FPc, Nc);
m.precision = timed_safe_divide(TP, TP + FPc + FPg);
m.recall = m.Pd;
m.F1 = timed_safe_divide(2*m.precision*m.recall, m.precision + m.recall);
end

function [tf, bestIdx, bestScore] = timed_find_best_uav_match(estRow, trueUAV, thr, sidebandAware, usedUAV)
N = height(trueUAV);
tf = false; bestIdx = NaN; bestScore = inf;
if N == 0
    return;
end
da = abs(estRow.AngleDeg - trueUAV.AngleDeg);
dr = abs(estRow.RangeBin - trueUAV.RangeBin);
dd = zeros(N,1);
for uu = 1:N
    if sidebandAware
        centers = trueUAV.DopplerBin(uu) + (-3:3) * trueUAV.MicroDopplerSpacing(uu);
        dd(uu) = min(abs(estRow.DopplerBin - centers));
    else
        dd(uu) = abs(estRow.DopplerBin - trueUAV.DopplerBin(uu));
    end
end
valid = da < thr.angleDeg & dr < thr.rangeBin & dd < thr.dopplerBin & ~usedUAV;
if any(valid)
    score = da/max(thr.angleDeg,eps) + dr/max(thr.rangeBin,eps) + dd/max(thr.dopplerBin,eps);
    score(~valid) = inf;
    [bestScore, bestIdx] = min(score);
    tf = true;
end
end

function [tf, bestIdx, bestScore] = timed_find_best_clutter_match(estRow, trueClutter, thr, usedClutter)
N = height(trueClutter);
tf = false; bestIdx = NaN; bestScore = inf;
if N == 0
    return;
end
da = abs(estRow.AngleDeg - trueClutter.AngleDeg);
dr = abs(estRow.RangeBin - trueClutter.RangeBin);
dd = abs(estRow.DopplerBin - trueClutter.DopplerBin);
valid = da < thr.angleDeg & dr < thr.rangeBin & dd < thr.dopplerBin & ~usedClutter;
if any(valid)
    score = da/max(thr.angleDeg,eps) + dr/max(thr.rangeBin,eps) + dd/max(thr.dopplerBin,eps);
    score(~valid) = inf;
    [bestScore, bestIdx] = min(score);
    tf = true;
end
end
function agg = timed_init_rank_metric_aggregate()
agg.rankErrorSum = 0;
agg.rankExactCount = 0;
agg.componentF1Sum = 0;
agg.componentPrecisionSum = 0;
agg.componentRecallSum = 0;
agg.validF1Count = 0;
agg.RhatUAV = [];
agg.selectedRank = [];
agg.K0 = [];
agg.noiseCount = [];
agg.objectCount = [];
agg.deltaRAtSelected = [];
end

function agg = timed_update_rank_metric_aggregate(agg, m)
agg.rankErrorSum = agg.rankErrorSum + m.rankError;
agg.rankExactCount = agg.rankExactCount + double(m.rankExact);
if isfinite(m.componentF1)
    agg.componentF1Sum = agg.componentF1Sum + m.componentF1;
    agg.componentPrecisionSum = agg.componentPrecisionSum + m.componentPrecision;
    agg.componentRecallSum = agg.componentRecallSum + m.componentRecall;
    agg.validF1Count = agg.validF1Count + 1;
end
agg.RhatUAV(end+1,1) = m.RhatUAV;
agg.selectedRank(end+1,1) = m.selectedRank;
agg.K0(end+1,1) = m.K0;
agg.noiseCount(end+1,1) = m.noiseCount;
agg.objectCount(end+1,1) = m.objectCount;
agg.deltaRAtSelected(end+1,1) = m.deltaRAtSelected;
end

function s = timed_finalize_rank_metric_aggregate(agg, numMC)
s = agg;
s.meanRankError = timed_safe_divide(agg.rankErrorSum, numMC);
s.rankAccuracy = timed_safe_divide(agg.rankExactCount, numMC);
s.meanComponentF1 = timed_safe_divide(agg.componentF1Sum, agg.validF1Count);
s.meanComponentPrecision = timed_safe_divide(agg.componentPrecisionSum, agg.validF1Count);
s.meanComponentRecall = timed_safe_divide(agg.componentRecallSum, agg.validF1Count);
s.meanRhatUAV = timed_mean_or_nan(agg.RhatUAV);
s.meanSelectedRank = timed_mean_or_nan(agg.selectedRank);
s.meanK0 = timed_mean_or_nan(agg.K0);
s.meanNoiseCount = timed_mean_or_nan(agg.noiseCount);
s.meanObjectCount = timed_mean_or_nan(agg.objectCount);
s.meanDeltaRAtSelected = timed_mean_or_nan(agg.deltaRAtSelected(isfinite(agg.deltaRAtSelected)));
end

function m = timed_evaluate_rank_component_metrics(estTable, trueUAV, thr)
baseMetrics = timed_evaluate_detection_metrics_body(estTable, trueUAV, thr);
RhatUAV = baseMetrics.estimateCount;
Nu = height(trueUAV);
m.RhatUAV = RhatUAV;
m.Nu = Nu;
m.rankError = abs(RhatUAV - Nu);
m.rankExact = (RhatUAV == Nu);
m.componentPrecision = baseMetrics.precision;
m.componentRecall = baseMetrics.recall;
m.componentF1 = baseMetrics.F1;
m.truePositive = baseMetrics.truePositive;
m.falsePositive = baseMetrics.falseAlarm;
m.falseNegative = baseMetrics.missed;
m.selectedRank = NaN;
m.K0 = NaN;
m.noiseCount = NaN;
m.objectCount = NaN;
m.deltaRAtSelected = NaN;
end
function timed_print_mc_uav_tables(trueUAV, tradUAV, tensorUAV)
fprintf('  True UAV parameters:\n');
timed_print_compact_table(trueUAV, {'ID','AngleDeg','RangeBin','DopplerBin','MicroDopplerSpacing'});

fprintf('  Traditional estimated UAV parameters:\n');
timed_print_compact_table(tradUAV, {'ID','AngleDeg','RangeBin','DopplerBin','PeriodicScore','BestSpacing','MatchedPeaks','SpectrumWidth','MergedCount','MergedIDs','DecisionReason'});

fprintf('  Tensor estimated UAV parameters:\n');
timed_print_compact_table(tensorUAV, {'ID','AngleDeg','RangeBin','DopplerBin','PeriodicScore','BestSpacing','MatchedPeaks','SpectrumWidth','MergedCount','MergedIDs','DecisionReason'});
end

function timed_print_compact_table(T, preferredVars)
if isempty(T) || height(T) == 0
    fprintf('    <empty>\n');
    return;
end
vars = preferredVars(ismember(preferredVars, T.Properties.VariableNames));
disp(T(:, vars));
end
function opts = timed_fill_default_opts(opts)
if ~isfield(opts,'seed'), opts.seed = 20260605; end
if ~isfield(opts,'verbose'), opts.verbose = true; end
if ~isfield(opts,'numRestarts'), opts.numRestarts = 4; end
if ~isfield(opts,'doTensor'), opts.doTensor = true; end
if ~isfield(opts,'successThreshold')
    opts.successThreshold.angleDeg = 5;
    opts.successThreshold.rangeBin = 3;
    opts.successThreshold.dopplerBin = 4;
end

opts.M = timed_get_opt(opts,'M',16);
opts.NR = timed_get_opt(opts,'NR',96);
opts.ND = timed_get_opt(opts,'ND',128);
opts.theta_grid = timed_get_opt(opts,'theta_grid',-60:0.1:60);
opts.sigma_R = timed_get_opt(opts,'sigma_R',0.85);
opts.sigma_D_u = timed_get_opt(opts,'sigma_D_u',0.75);
opts.sigma_D_c = timed_get_opt(opts,'sigma_D_c',0.70);
opts.uavAlphaRange = timed_get_opt(opts,'uavAlphaRange',[0.75 1.00]);
opts.clutterAlphaRange = timed_get_opt(opts,'clutterAlphaRange',[0.20 0.40]);
opts.cfarCandidateExtra = timed_get_opt(opts,'cfarCandidateExtra',10);
opts.cfarMinCandidates = timed_get_opt(opts,'cfarMinCandidates',20);
opts.adjacentDopplerBins = timed_get_opt(opts,'adjacentDopplerBins',-2:2);
opts.tradRangeNeighborhood = timed_get_opt(opts,'tradRangeNeighborhood',-2:2);
opts.tradDopplerNeighborhood = timed_get_opt(opts,'tradDopplerNeighborhood',-8:8);

mergeRule.angleDeg = 3;
mergeRule.rangeBin = 2;
mergeRule.dopplerBin = 3;
mergeRule.sidebandHarmonics = -3:3;
mergeRule.spacingCandidates = [5 6 7 8];
mergeRule.maxGroupSize = inf;
opts.uavMergeRule = timed_get_opt(opts,'uavMergeRule',mergeRule);

opts.bodyAmp = timed_get_opt(opts,'bodyAmp',1.0);
opts.betaMD = timed_get_opt(opts,'betaMD',0.8);
opts.numSidebandOrder = timed_get_opt(opts,'numSidebandOrder',3);
opts.mdToBody_dB = timed_get_opt(opts,'mdToBody_dB',-10);
opts.uavSidebandAmps = timed_get_opt(opts,'uavSidebandAmps',timed_make_bessel_sideband_amps(opts.bodyAmp, opts.betaMD, opts.numSidebandOrder, opts.mdToBody_dB));

rankRule.minDeltaR = 0.005;
rankRule.consecutiveRequired = 1;
rankRule.retryOnResidualIncrease = true;
rankRule.maxRetryRounds = 3;
rankRule.retryRestarts = opts.numRestarts;
rankRule.hardMaxRank = 48;
if ~isfield(opts,'rankSelectionRule') || isempty(opts.rankSelectionRule)
    opts.rankSelectionRule = rankRule;
else
    ruleFields = fieldnames(rankRule);
    for ii = 1:numel(ruleFields)
        field = ruleFields{ii};
        if ~isfield(opts.rankSelectionRule,field)
            opts.rankSelectionRule.(field) = rankRule.(field);
        end
    end
end

rule.frCandidates = 1:10;
rule.searchHalfWidth = 2;
rule.peakRelThreshold = 0.04;
rule.minPeakDistance = 2;
rule.minMatchedPeaks = 3;
rule.spacingTolerance = 1;
rule.matchedEnergyHalfWidth = 1;
rule.minPeriodicScore = 0.30;
rule.maxPeriodicityError = 0.95;
rule.minWidthBins = 5;
rule.maxWidthBins = 30;
rule.widthPowerFraction = 0.90;
opts.periodicRule = timed_get_opt(opts,'periodicRule',rule);
end

function uavSidebandAmps = timed_make_bessel_sideband_amps(bodyAmp, betaMD, numSidebandOrder, mdToBody_dB)
% Body amplitude is fixed, while all micro-Doppler sidebands are scaled so
% that their total energy has the target MD-to-body energy ratio.
if numSidebandOrder ~= 3
    error('This simulation currently expects numSidebandOrder = 3.');
end
J1 = abs(besselj(1, betaMD));
J2 = abs(besselj(2, betaMD));
J3 = abs(besselj(3, betaMD));
baseSidebands = [J1, J1, J2, J2, J3, J3];
P0 = sum(baseSidebands.^2);
if P0 <= eps
    sidebands = zeros(size(baseSidebands));
else
    alpha = sqrt(10^(mdToBody_dB/10) * bodyAmp^2 / P0);
    sidebands = alpha * baseSidebands;
end
uavSidebandAmps = [bodyAmp, sidebands];
end
function v = timed_get_opt(s, name, defaultValue)
if isfield(s,name)
    v = s.(name);
else
    v = defaultValue;
end
end

function one = timed_run_one_trial(Nu, Nc, Nn, SNR_dB, opts)
M = opts.M; NR = opts.NR; ND = opts.ND;
theta_grid = opts.theta_grid;

scene = timed_f_make_sim_scene_local(Nu, Nc, Nn, opts);
trueUAV = table((1:Nu).', scene.theta_u_list(:), scene.Ru_list(:), scene.d0_u_list(:), scene.fr_u_list(:), scene.clusterID_u(:), true(Nu,1), ...
    'VariableNames', {'ID','AngleDeg','RangeBin','DopplerBin','MicroDopplerSpacing','ClusterID','IsUAV'});
trueClutter = table((1:Nc).', scene.theta_c_list(:), scene.Rc_list(:), scene.Dc_list(:), scene.clusterID_c(:), false(Nc,1), ...
    'VariableNames', {'ID','AngleDeg','RangeBin','DopplerBin','ClusterID','IsUAV'});

X_clean=zeros(M,opts.raw.nFast,ND);
for uu=1:Nu
    a=timed_steering_ula(M,scene.theta_u_list(uu));
    b=raw_range_tone_local(opts.raw.nFast,scene.Ru_list(uu));
    d0=scene.d0_u_list(uu); fr=scene.fr_u_list(uu);
    bins=[d0 d0-fr d0+fr d0-2*fr d0+2*fr d0-3*fr d0+3*fr];
    g=zeros(ND,1);
    for hh=1:numel(bins)
        g=g+scene.uav_sideband_amps(hh)*raw_doppler_tone_local(ND,bins(hh));
    end
    g=g/max(norm(g),eps);
    X_clean=X_clean+timed_outer3(scene.alpha_u_list(uu)*a,b,g);
end
for cc=1:Nc
    X_clean=X_clean+timed_outer3(scene.alpha_c_list(cc)*timed_steering_ula(M,scene.theta_c_list(cc)),...
        raw_range_tone_local(opts.raw.nFast,scene.Rc_list(cc)),...
        raw_doppler_tone_local(ND,scene.Dc_list(cc)));
end
signal_power=mean(abs(X_clean(:)).^2);
noise_power=signal_power/10^(SNR_dB/10);
noiseStream=RandStream('mt19937ar','Seed',opts.noiseSeed);
whiteNoise=(randn(noiseStream,size(X_clean))+1j*randn(noiseStream,size(X_clean)))/sqrt(2);
Noise=sqrt(noise_power)*whiteNoise; X=X_clean+Noise;
if isfield(opts,'solverSeed'), rng(opts.solverSeed,'twister'); end

traditionalTimer = tic;
fftTimer=tic; Xcfar=raw_process_tensor_local(X,opts,'cfar'); cfarFFTSeconds=toc(fftTimer);
[tradResult, tradResultAll, tradCandidates] = timed_run_traditional_chain(Xcfar, theta_grid, opts);
traditionalSeconds = toc(traditionalTimer);

musicTimer=tic; Xmusic=raw_process_tensor_local(X,opts,'rect'); musicFFTSeconds=toc(musicTimer);
tensorSeconds = NaN;
if opts.doTensor
    tensorTimer = tic;
    [tensorResult, tensorResultAll, tensorRankInfo] = timed_run_tensor_chain(X, tradCandidates, theta_grid, opts);
    tensorSeconds = toc(tensorTimer);
else
    tensorResultAll = table();
    tensorResult = table();
    tensorRankInfo = timed_empty_rank_info();
end

one.trueUAV = trueUAV;
one.trueClutter = trueClutter;
one.sceneDefinition = scene;
one.X_cfar=Xcfar; one.X_music=Xmusic;
one.cfarFFTSeconds=cfarFFTSeconds; one.musicFFTSeconds=musicFFTSeconds;
one.noiseAudit = struct('whiteFirst',whiteNoise(1),'whiteEnergy',sum(abs(whiteNoise(:)).^2), ...
    'signalPower',signal_power,'noisePower',noise_power,'requestedSNRdB',SNR_dB,...
    'rawSize',size(X),'cfarSize',size(Xcfar),...
    'rectMeanSignalPower',mean(abs(raw_process_tensor_local(X_clean,opts,'rect')).^2,'all'),...
    'cfarMeanSignalPower',mean(abs(raw_process_tensor_local(X_clean,opts,'cfar')).^2,'all'),...
    'expectedProcessedNoisePower',noise_power);
if timed_get_opt(opts, 'saveDataTensor', false)
    one.X = X;
    one.X_clean = X_clean;
end
traditionalOutputTimer = tic;
one.traditional.runtimeSeconds = traditionalSeconds;
one.traditional.candidateCount = size(tradCandidates,1);
one.traditional.candidates = tradCandidates;
one.traditional.allEstimate = tradResultAll;
one.traditional.afterNoiseRemoval = tradResult;
one.traditional.uavEstimateRaw = tradResult(tradResult.IsUAV,:);
one.traditional.uavEstimate = timed_merge_duplicate_uav_estimates(one.traditional.uavEstimateRaw, opts.uavMergeRule);
one.traditional.runtimeSeconds = traditionalSeconds + toc(traditionalOutputTimer);
tensorOutputTimer = tic;
one.tensor.runtimeSeconds = one.traditional.runtimeSeconds + tensorSeconds;
one.tensor.tensorOnlySeconds = tensorSeconds;
if ~isfield(tensorRankInfo,'elapsedSeconds'), tensorRankInfo.elapsedSeconds=tensorSeconds; end
one.tensor.allEstimate = tensorResultAll;
one.tensor.rankInfo = tensorRankInfo;
one.tensor.uavEstimateRaw = tensorResult;
one.tensor.uavEstimate = timed_merge_duplicate_uav_estimates(tensorResult, opts.uavMergeRule);
one.tensor.rankInfo.inputDomain="raw unwindowed fast/slow time";
one.tensor.rankInfo.inputSize=size(X);
one.tensor.rankInfo.postCPDDopplerFFT=true;
one.tensor.rankMetrics.selectedRank = one.tensor.rankInfo.selectedRank;
one.tensor.rankMetrics.K0 = one.tensor.rankInfo.K0;
one.tensor.rankMetrics.noiseCount = one.tensor.rankInfo.selectedNoiseCount;
one.tensor.rankMetrics.objectCount = one.tensor.rankInfo.selectedObjectCount;
one.tensor.rankMetrics.deltaRAtSelected = one.tensor.rankInfo.selectedDeltaR;
one.tensor.runtimeSeconds = one.tensor.runtimeSeconds + toc(tensorOutputTimer);
end



function [tradResult, tradResultAll, tradCandidates] = timed_run_traditional_chain(X, theta_grid, opts, candidateOverride)
% Classify at the detected peak. Classification never rewrites peak coordinates.
[M,~,ND]=size(X);
RV=squeeze(sum(abs(X).^2,1));
cfar=struct('guardR',2,'guardD',2,'trainR',6,'trainD',8,'Pfa',1e-4,...
    'maxCandidates',timed_get_opt(opts,'cfarMaxCandidates',inf),...
    'minRangeDistance',2,'minDopplerDistance',3,'thresholdScale',opts.rawCFARCalibration.caScale);
if nargin<4
    [tradCandidates,~]=timed_cfar_2d_candidates(RV,cfar);
else
    tradCandidates=candidateOverride;
end
K0=size(tradCandidates,1);
angle=zeros(K0,1); range=tradCandidates(:,1); doppler=tradCandidates(:,2);
score=zeros(K0,1); spacing=zeros(K0,1); matched=zeros(K0,1);
width=nan(K0,1); reason=strings(K0,1); isUAV=false(K0,1);
for kk=1:K0
    rr=range(kk); dd=doppler(kk);
    P=timed_angle_spectrum(X(:,rr,dd),theta_grid);
    [~,it]=max(P); angle(kk)=theta_grid(it);
    a=timed_steering_ula(M,angle(kk));
    Y=reshape(X(:,rr,:),M,ND);
    g=(a'*Y).';
    decisionRule=opts.periodicRule; decisionRule.modelWindow=opts.raw.cfarDopplerWindow;
    [isUAV(kk),score(kk),spacing(kk),matched(kk),width(kk),reason(kk)]=...
        timed_classify_hybrid_peaks_adjacent(g,dd,opts.adjacentDopplerBins,decisionRule);
end
tradResultAll=table((1:K0).',angle,range,doppler,score,spacing,matched,width,reason,isUAV,...
    'VariableNames',{'ID','AngleDeg','RangeBin','DopplerBin','PeriodicScore',...
    'BestSpacing','MatchedPeaks','SpectrumWidth','DecisionReason','IsUAV'});
tooWide=contains(reason,["too wide before periodic test","model-unstructured"]);
label=repmat("Object",K0,1); label(tooWide)="Rejected"; label(~tooWide & isUAV)="UAV";
tradResultAll.ClassLabel=label;
tradResult=tradResultAll(~tooWide,:);
end

function mergedTable = timed_merge_duplicate_uav_estimates(estTable, rule)
rule = timed_fill_merge_rule_defaults(rule);
if ~rule.enable
    mergedTable = estTable;
    return;
end
% Merge detections that are likely from the same UAV micro-Doppler pattern.
% A single UAV can create several RV peaks at d0 +/- k*fr; these should be
% counted as one object instead of several UAVs.
if isempty(estTable) || height(estTable) <= 1
    mergedTable = estTable;
    return;
end

score = timed_get_table_score(estTable);
[~, order] = sort(score, 'descend');
used = false(height(estTable),1);
keepRows = [];
mergedCount = zeros(0,1);
mergedIDs = strings(0,1);

for oo = 1:numel(order)
    seedIdx = order(oo);
    if used(seedIdx)
        continue;
    end

    same = false(height(estTable),1);
    for jj = 1:height(estTable)
        if used(jj)
            continue;
        end
        if timed_is_same_uav_detection(estTable(seedIdx,:), estTable(jj,:), rule)
            same(jj) = true;
        end
    end

    groupIdx = find(same);
    [~, localBest] = max(score(groupIdx));
    keepIdx = groupIdx(localBest);
    used(groupIdx) = true;
    keepRows(end+1,1) = keepIdx; %#ok<AGROW>
    mergedCount(end+1,1) = numel(groupIdx); %#ok<AGROW>
    mergedIDs(end+1,1) = strjoin(string(estTable.ID(groupIdx).'), ','); %#ok<AGROW>
end

mergedTable = estTable(keepRows,:);
mergedTable.MergedCount = mergedCount;
mergedTable.MergedIDs = mergedIDs;
mergedTable.ID = (1:height(mergedTable)).';
end

function rule = timed_fill_merge_rule_defaults(rule)
if nargin < 1 || isempty(rule)
    rule = struct();
end
if ~isfield(rule,'enable'), rule.enable = false; end
if ~isfield(rule,'angleDeg'), rule.angleDeg = 3; end
if ~isfield(rule,'rangeBin'), rule.rangeBin = 2; end
if ~isfield(rule,'dopplerBin'), rule.dopplerBin = 3; end
if ~isfield(rule,'sidebandHarmonics'), rule.sidebandHarmonics = -3:3; end
if ~isfield(rule,'spacingCandidates'), rule.spacingCandidates = [5 6 7 8]; end
end
function tf = timed_is_same_uav_detection(a, b, rule)
angleClose = abs(a.AngleDeg - b.AngleDeg) <= rule.angleDeg;
rangeClose = abs(a.RangeBin - b.RangeBin) <= rule.rangeBin;
if ~angleClose || ~rangeClose
    tf = false;
    return;
end

spacingCandidates = unique([rule.spacingCandidates(:).', round(a.BestSpacing), round(b.BestSpacing)]);
spacingCandidates = spacingCandidates(isfinite(spacingCandidates) & spacingCandidates > 0);
if isempty(spacingCandidates)
    spacingCandidates = 1;
end

dopplerClose = abs(a.DopplerBin - b.DopplerBin) <= rule.dopplerBin;
for ss = spacingCandidates
    centers = a.DopplerBin + rule.sidebandHarmonics * ss;
    if min(abs(b.DopplerBin - centers)) <= rule.dopplerBin
        dopplerClose = true;
        break;
    end
end
tf = dopplerClose;
end

function score = timed_get_table_score(T)
score = zeros(height(T),1);
if ismember('PeriodicScore', T.Properties.VariableNames)
    score = score + T.PeriodicScore;
end
if ismember('MatchedPeaks', T.Properties.VariableNames)
    score = score + 0.05 * T.MatchedPeaks;
end
if ismember('SpectrumWidth', T.Properties.VariableNames)
    score = score - 0.001 * abs(T.SpectrumWidth - 12);
end
score(~isfinite(score)) = -inf;
end

function [tensorResult, tensorResultAll, rankInfo] = timed_run_tensor_chain(X, tradCandidates, theta_grid, opts)
K0 = max(1, size(tradCandidates,1));
rule = opts.rankSelectionRule;
validateattributes(rule.minDeltaR, {'numeric'}, {'scalar','real','finite','positive','<',1});
validateattributes(rule.consecutiveRequired, {'numeric'}, {'scalar','integer','>=',1});
validateattributes(rule.hardMaxRank, {'numeric'}, {'scalar','integer','>=',K0});
validateattributes(rule.retryRestarts, {'numeric'}, {'scalar','integer','positive'});
validateattributes(rule.maxRetryRounds, {'numeric'}, {'scalar','integer','positive'});
rankList = K0:rule.hardMaxRank;
cpd_options = struct();
cpd_options.Compression = false;
cpd_options.Algorithm = @cpd_nls;
cpd_options.AlgorithmOptions.Display = 0;
cpd_options.AlgorithmOptions.MaxIter = 180;
cpd_options.AlgorithmOptions.TolFun = 1e-9;
cpd_options.AlgorithmOptions.TolX = 1e-7;
cpd_options.AlgorithmOptions.CGMaxIter = 40;

rankInfo = timed_empty_rank_info();
rankInfo.K0 = K0;
rankInfo.cfarCandidateCount = size(tradCandidates,1);
rankInfo.rankList = rankList(:);
rankInfo.testedRanks = [];
rankInfo.residualThreshold = rule.minDeltaR;
rankInfo.consecutiveRequired = rule.consecutiveRequired;
rankInfo.hardMaxRank = rule.hardMaxRank;
rankInfo.stopTriggeredRank = NaN;
rankInfo.stopWindowRanks = [];
rankInfo.budgetReached = false;
rankInfo.stopReason = "hard rank budget reached without joint stopping";
prev = [];
anchor = [];
selected = [];
streak = 0;

for K = rankList
    fitTimer = tic;
    [Utmp, relres] = timed_run_cpd_best_of_restarts(X, size(X), K, ...
        tradCandidates, theta_grid, cpd_options, opts.numRestarts);
    [Utmp, relres, retryInfo] = ensure_monotone_cpd_local(X, Utmp, prev, K, ...
        tradCandidates, theta_grid, cpd_options, rule.retryRestarts, rule.maxRetryRounds);
    retried = retryInfo.Retried;
    fitSeconds = toc(fitTimer);
    if isempty(Utmp) || ~isfinite(relres)
        streak = 0;
        anchor = [];
        prev = [];
        rankInfo = append_joint_rank_diagnostic_local(rankInfo, K, NaN, NaN, ...
            0, 0, 0, "CPD failed; joint streak reset", false, false, streak, ...
            retried, fitSeconds, retryInfo.RetryRounds, retryInfo.UsedEmbeddedFit);
        continue;
    end
    summaryTable = timed_interpret_cpd_components(Utmp, theta_grid, opts.periodicRule);
    summaryTable = mark_zero_weight_components_local(summaryTable, Utmp);
    [uavCount, objectCount, noiseCount] = timed_count_component_classes(summaryTable);
    current = struct('K',K, 'U',{Utmp}, 'summaryTable',summaryTable, ...
        'relres',relres, 'deltaR',NaN, 'usedEmbeddedFit',retryInfo.UsedEmbeddedFit, ...
        'uavCount',uavCount, ...
        'objectCount',objectCount, 'noiseCount',noiseCount);
    [streak, anchor, shouldStop, deltaR, physicalCondition, smallGain] = ...
        update_joint_rank_stop_local(prev, current, rule, streak, anchor);
    current.deltaR = deltaR;
    if isfinite(deltaR) && deltaR < 0
        error('MonotoneCPD:ResidualIncrease', 'Monotone residual invariant failed at rank %d.', K);
    end
    status = "tested";
    if retryInfo.UsedEmbeddedFit
        status = "retry budget exhausted; exact previous-fit embedding; joint streak reset";
    elseif retryInfo.Retried
        status = "re-solved current rank; monotone residual accepted";
    end
    selected = current;
    prev = current;
    if shouldStop
        selected = anchor;
        status = "joint condition confirmed; rolled back to anchor";
        rankInfo.stopReason = sprintf("%d noise-only growth step(s) with small residual gains", rule.consecutiveRequired);
        rankInfo.stopTriggeredRank = K;
        rankInfo.stopWindowRanks = (anchor.K:K).';
    end
    rankInfo = append_joint_rank_diagnostic_local(rankInfo, K, relres, deltaR, ...
        uavCount, objectCount, noiseCount, status, physicalCondition, smallGain, ...
        streak, retried, fitSeconds, retryInfo.RetryRounds, retryInfo.UsedEmbeddedFit);
    if shouldStop
        break;
    end
end
rankInfo.testedRanks = rankInfo.diagnostics.Rank;
rankInfo.budgetReached = isnan(rankInfo.stopTriggeredRank) && ...
    ~isempty(rankInfo.testedRanks) && rankInfo.testedRanks(end) == rule.hardMaxRank;
if isempty(selected)
    tensorResultAll = table();
    tensorResult = table();
    rankInfo.stopReason = "all CPD ranks failed";
    return;
end
rankInfo.selectedRank = selected.K;
rankInfo.selectedRelres = selected.relres;
rankInfo.selectedDeltaR = selected.deltaR;
rankInfo.selectedUAVCountRaw = selected.uavCount;
rankInfo.selectedObjectCount = selected.objectCount;
rankInfo.selectedNoiseCount = selected.noiseCount;
tensorResultAll = selected.summaryTable;
tensorResult = tensorResultAll(logical(tensorResultAll.IsUAV),:);
end

function [streak, anchor, shouldStop, deltaR, physicalCondition, smallGain] = ...
        update_joint_rank_stop_local(prev, current, rule, streak, anchor)
shouldStop = false;
deltaR = NaN;
physicalCondition = false;
smallGain = false;
if isempty(prev) || current.K ~= prev.K + 1
    streak = 0;
    anchor = [];
    return;
end
deltaR = (prev.relres - current.relres) / max(prev.relres, eps);
physicalCondition = current.noiseCount > prev.noiseCount && ...
    current.uavCount <= prev.uavCount && current.objectCount <= prev.objectCount;
numericalFallback = (isfield(current,'usedEmbeddedFit') && current.usedEmbeddedFit) || ...
    (isfield(prev,'usedEmbeddedFit') && prev.usedEmbeddedFit);
smallGain = isfinite(deltaR) && deltaR >= 0 && deltaR < rule.minDeltaR && ~numericalFallback;
if physicalCondition && smallGain
    if streak == 0
        % Retain the complete fit before the first unsuccessful rank growth.
        anchor = prev;
    end
    streak = streak + 1;
    shouldStop = streak >= rule.consecutiveRequired;
else
    streak = 0;
    anchor = [];
end
end

function rankInfo = append_joint_rank_diagnostic_local(rankInfo, K, relres, deltaR, ...
        uavCount, objectCount, noiseCount, status, physicalCondition, smallGain, ...
        streak, retried, fitSeconds, retryRounds, usedEmbeddedFit)
row = table(K, relres, deltaR, uavCount, objectCount, noiseCount, string(status), ...
    logical(physicalCondition), logical(smallGain), streak, logical(retried), fitSeconds, ...
    retryRounds, logical(usedEmbeddedFit), ...
    'VariableNames', {'Rank','RelResidual','DeltaR','UAVCount','ObjectCount', ...
    'NoiseTooWideCount','Status','NoiseOnlyGrowth','SmallResidualGain', ...
    'JointStreak','Retried','CPDFitSeconds','RetryRounds','UsedEmbeddedFit'});
rankInfo.diagnostics = [rankInfo.diagnostics; row];
end

function rankInfo = timed_empty_rank_info()
rankInfo = struct();
rankInfo.K0 = NaN;
rankInfo.rankList = [];
rankInfo.diagnostics = table();
rankInfo.selectedRank = NaN;
rankInfo.selectedRelres = NaN;
rankInfo.selectedDeltaR = NaN;
rankInfo.selectedUAVCountRaw = NaN;
rankInfo.selectedObjectCount = NaN;
rankInfo.selectedNoiseCount = NaN;
rankInfo.stopReason = "not run";
end

function rankInfo = timed_append_rank_diagnostic(rankInfo, K, relres, deltaR, uavCount, objectCount, noiseCount, statusText)
row = table(K, relres, deltaR, uavCount, objectCount, noiseCount, string(statusText), ...
    'VariableNames', {'Rank','RelResidual','DeltaR','UAVCount','ObjectCount','NoiseTooWideCount','Status'});
rankInfo.diagnostics = [rankInfo.diagnostics; row]; %#ok<AGROW>
end

function [uavCount, objectCount, noiseCount] = timed_count_component_classes(T)
if isempty(T) || height(T) == 0
    uavCount = 0; objectCount = 0; noiseCount = 0; return;
end
isNoise = contains(string(T.DecisionReason),["too wide before periodic test","model-unstructured"]) | ...
    contains(string(T.DecisionReason), "zero-weight nonphysical component");
uavCount = nnz(T.IsUAV & ~isNoise);
objectCount = nnz(~T.IsUAV & ~isNoise);
noiseCount = nnz(isNoise);
end

function nSuccess = timed_count_detection_success_sideband(estTable, trueUAV, thr)
% Traditional success: angle/range must match, and Doppler can match the
% UAV body Doppler or any micro-Doppler sideband d0 +/- k*fr, k=0..3.
nSuccess = 0;
if isempty(estTable) || height(estTable) == 0
    return;
end
usedTruth = false(height(trueUAV),1);
for ii = 1:height(estTable)
    da = abs(estTable.AngleDeg(ii) - trueUAV.AngleDeg);
    dr = abs(estTable.RangeBin(ii) - trueUAV.RangeBin);
    dd = zeros(height(trueUAV),1);
    for uu = 1:height(trueUAV)
        sidebandCenters = trueUAV.DopplerBin(uu) + (-3:3) * trueUAV.MicroDopplerSpacing(uu);
        dd(uu) = min(abs(estTable.DopplerBin(ii) - sidebandCenters));
    end
    valid = da < thr.angleDeg & dr < thr.rangeBin & dd < thr.dopplerBin & ~usedTruth;
    if any(valid)
        score = da/max(thr.angleDeg,eps) + dr/max(thr.rangeBin,eps) + dd/max(thr.dopplerBin,eps);
        score(~valid) = inf;
        [~, idx] = min(score);
        usedTruth(idx) = true;
        nSuccess = nSuccess + 1;
    end
end
end
function nSuccess = timed_count_detection_success(estTable, trueUAV, thr)
nSuccess = 0;
if isempty(estTable) || height(estTable) == 0
    return;
end
usedTruth = false(height(trueUAV),1);
for ii = 1:height(estTable)
    da = abs(estTable.AngleDeg(ii) - trueUAV.AngleDeg);
    dr = abs(estTable.RangeBin(ii) - trueUAV.RangeBin);
    dd = abs(estTable.DopplerBin(ii) - trueUAV.DopplerBin);
    valid = da < thr.angleDeg & dr < thr.rangeBin & dd < thr.dopplerBin & ~usedTruth;
    if any(valid)
        score = da/3 + dr/2 + dd/3;
        score(~valid) = inf;
        [~, idx] = min(score);
        usedTruth(idx) = true;
        nSuccess = nSuccess + 1;
    end
end
end

function scene = timed_f_make_sim_scene_local(Nu, Nc, Nn, opts) %#ok<INUSD>
% Every group obeys the same bounded uniform-offset rule; no truth enters estimators.
cfg = timed_get_opt(opts,'spacing',struct());
scale = timed_get_opt(cfg,'scale',1);
bounds = timed_get_opt(cfg,'baseBounds',[3 0.6 3]);
centers = timed_get_opt(cfg,'centers',[-30 30 48; 0 48 64; 30 66 80]);
counts = timed_get_opt(opts,'clusterUAVCounts',[1 2 3]);
validateattributes(scale,{'numeric'},{'scalar','finite','positive'});
validateattributes(bounds,{'numeric'},{'size',[1 3],'finite','positive'});
if numel(counts)~=Nc || sum(counts)~=Nu || any(counts<0 | counts~=fix(counts))
    error('SpacingScene:Counts','clusterUAVCounts must contain Nc nonnegative integers summing to Nu.');
end
if size(centers,2)~=3 || size(centers,1)<Nc || any(~isfinite(centers(:)))
    error('SpacingScene:Centers','Supply at least Nc finite [angle,range,Doppler] center rows.');
end
if isfield(opts,'offGrid') && timed_get_opt(opts.offGrid,'enable',false)
    error('SpacingScene:ExtraJitter','Disable extra offGrid jitter; positions already have bounded fractional offsets.');
end
centers=centers(1:Nc,:);
unitOffsets=2*rand(Nu,3)-1;
offsets=unitOffsets.*(scale*bounds);
ids=repelem((1:Nc).',counts(:));
positions=centers(ids,:)+offsets;
frDict=[5 6 7 8];
fr=frDict(randi(numel(frDict),Nu,1));
uavAmpRange=timed_get_opt(cfg,'uavAmplitudeRange',[0.55 0.90]);
objectAmpRange=timed_get_opt(cfg,'objectAmplitudeRange',[1.25 2.20]);
validateattributes(uavAmpRange,{'numeric'},{'size',[1 2],'finite','positive','nondecreasing'});
validateattributes(objectAmpRange,{'numeric'},{'size',[1 2],'finite','positive','nondecreasing'});
ampU=uavAmpRange(1)+diff(uavAmpRange)*rand(Nu,1);
ampC=objectAmpRange(1)+diff(objectAmpRange)*rand(Nc,1);
allPos=[positions;centers];
if any(allPos(:,1)<min(opts.theta_grid) | allPos(:,1)>max(opts.theta_grid)) || ...
        any(allPos(:,2)<1 | allPos(:,2)>opts.NR) || ...
        any(allPos(:,3)<1 | allPos(:,3)>opts.ND)
    error('SpacingScene:OutOfBounds','A scaled target leaves the observation domain; adjust centers or spacing bounds.');
end
if any(positions(:,3)-3*fr<1 | positions(:,3)+3*fr>opts.ND)
    error('SpacingScene:SidebandClipping','A retained sideband leaves the Doppler domain; adjust centers or spacing scale.');
end
scene=struct();
scene.theta_u_list=positions(:,1).'; scene.Ru_list=positions(:,2).';
scene.d0_u_list=positions(:,3).'; scene.fr_u_list=fr(:).';
scene.alpha_u_list=ampU(:).';
scene.theta_c_list=centers(:,1).'; scene.Rc_list=centers(:,2).';
scene.Dc_list=centers(:,3).'; scene.alpha_c_list=ampC(:).';
scene.clusterID_u=ids(:).'; scene.clusterID_c=1:Nc;
scene.clusterUAVCounts=counts(:).'; scene.K_true=Nu+Nc;
scene.spacingScale=scale; scene.baseBounds=bounds; scene.centers=centers;
scene.normalizedOffsets=unitOffsets; scene.actualOffsets=offsets;
scene.uavRangeMeters=(scene.Ru_list-1)*opts.raw.rangeBinMeters;
scene.nonUAVRangeMeters=(scene.Rc_list-1)*opts.raw.rangeBinMeters;
scene.uavBodyDopplerHz=(scene.d0_u_list-1-floor(opts.ND/2))*opts.raw.dopplerBinHz;
scene.nonUAVBodyDopplerHz=(scene.Dc_list-1-floor(opts.ND/2))*opts.raw.dopplerBinHz;
scene.uavVelocityMps=scene.uavBodyDopplerHz*opts.raw.wavelength/2;
scene.uav_sideband_amps=timed_make_bessel_sideband_amps(opts.bodyAmp,opts.betaMD, ...
    opts.numSidebandOrder,opts.mdToBody_dB);
end

function s = timed_sign_nonzero_local(x)
s = sign(x);
s(s == 0) = 1;
end

function out = timed_randsample_local(values, n)
idx = randperm(numel(values), n);
out = values(idx);
end
function scene = timed_apply_off_grid_perturbation(scene, opts)
if ~isfield(opts, 'offGrid') || isempty(opts.offGrid) || ~timed_get_opt(opts.offGrid, 'enable', false)
    return;
end
og = opts.offGrid;
angleJitterDeg = timed_get_opt(og, 'angleJitterDeg', 0.45);
rangeJitterBin = timed_get_opt(og, 'rangeJitterBin', 0.45);
dopplerJitterBin = timed_get_opt(og, 'dopplerJitterBin', 0.45);
spacingJitterBin = timed_get_opt(og, 'spacingJitterBin', 0.35);
applyToClutter = timed_get_opt(og, 'applyToClutter', true);

scene.theta_u_list = scene.theta_u_list + timed_centered_uniform(size(scene.theta_u_list), angleJitterDeg);
scene.Ru_list = scene.Ru_list + timed_centered_uniform(size(scene.Ru_list), rangeJitterBin);
scene.d0_u_list = scene.d0_u_list + timed_centered_uniform(size(scene.d0_u_list), dopplerJitterBin);
scene.fr_u_list = scene.fr_u_list + timed_centered_uniform(size(scene.fr_u_list), spacingJitterBin);

if applyToClutter
    scene.theta_c_list = scene.theta_c_list + timed_centered_uniform(size(scene.theta_c_list), angleJitterDeg);
    scene.Rc_list = scene.Rc_list + timed_centered_uniform(size(scene.Rc_list), rangeJitterBin);
    scene.Dc_list = scene.Dc_list + timed_centered_uniform(size(scene.Dc_list), dopplerJitterBin);
end

scene.Ru_list = timed_clamp_values(scene.Ru_list, 3, opts.NR - 2);
scene.Rc_list = timed_clamp_values(scene.Rc_list, 3, opts.NR - 2);
scene.fr_u_list = timed_clamp_values(scene.fr_u_list, 2, 10);
loBody = 2 + 3 * scene.fr_u_list;
hiBody = opts.ND - 1 - 3 * scene.fr_u_list;
scene.d0_u_list = min(max(scene.d0_u_list, loBody), hiBody);
scene.Dc_list = timed_clamp_values(scene.Dc_list, 3, opts.ND - 2);
end

function x = timed_centered_uniform(sz, halfWidth)
if halfWidth <= 0
    x = zeros(sz);
else
    x = (2 * rand(sz) - 1) * halfWidth;
end
end

function x = timed_clamp_values(x, lo, hi)
x = min(max(x, lo), hi);
end

function a = timed_steering_ula(M, theta_deg)
m = (0:M-1).'; a = exp(1j*pi*m*sind(theta_deg)); a = a / norm(a);
end
function v = timed_gaussian_response(N, center, sigma)
n = (1:N).'; v = exp(-0.5*((n-center)/sigma).^2); v = v / norm(v);
end
function X = timed_outer3(a,b,c)
X = zeros(numel(a),numel(b),numel(c));
for kk = 1:numel(c), X(:,:,kk) = a * (b.' * c(kk)); end
end
function P = timed_angle_spectrum(x, theta_grid)
M = numel(x); P = zeros(numel(theta_grid),1);
for ii = 1:numel(theta_grid), P(ii) = abs(timed_steering_ula(M, theta_grid(ii))' * x)^2; end
end
function [candidateList, cfarMask, info] = timed_robust_rv_candidates(RV, opts)
[cfarCand, cfarMask] = timed_cfar_2d_candidates(RV, opts); info.rawCfarPeaks = size(cfarCand,1); info.usedFallback = false;
if size(cfarCand,1) >= min(opts.fallbackCandidates, opts.maxCandidates), candidateList = cfarCand; return; end
info.usedFallback = true; peakCand = timed_top_local_peaks_2d(RV, opts.maxCandidates*4); candidateList = timed_select_separated_candidates([cfarCand; peakCand], opts.maxCandidates, opts.minRangeDistance, opts.minDopplerDistance);
end
function [candidateList, cfarMask] = timed_cfar_2d_candidates(RV, opts)
[NR,ND] = size(RV); cfarMask = false(NR,ND); gR=opts.guardR; gD=opts.guardD; tR=opts.trainR; tD=opts.trainD; winR=tR+gR; winD=tD+gD;
numTrain = (2*winR+1)*(2*winD+1)-(2*gR+1)*(2*gD+1); alpha = timed_get_opt(opts,'thresholdScale',numTrain*(opts.Pfa^(-1/numTrain)-1));
for rr=(winR+1):(NR-winR)
    for dd=(winD+1):(ND-winD)
        block=RV(rr-winR:rr+winR,dd-winD:dd+winD); guard=false(size(block)); guard((winR-gR+1):(winR+gR+1),(winD-gD+1):(winD+gD+1))=true;
        if RV(rr,dd)>alpha*mean(block(~guard)) && timed_is_local_max(RV,rr,dd), cfarMask(rr,dd)=true; end
    end
end
[rIdx,dIdx]=find(cfarMask); if isempty(rIdx), candidateList=zeros(0,3); return; end
candidateList = timed_select_separated_candidates([rIdx,dIdx,RV(sub2ind(size(RV),rIdx,dIdx))], opts.maxCandidates, opts.minRangeDistance, opts.minDopplerDistance);
end
function candidateList = timed_top_local_peaks_2d(RV,maxPeaks)
[NR,ND]=size(RV); tmp=[];
for rr=2:(NR-1), for dd=2:(ND-1), if timed_is_local_max(RV,rr,dd), tmp=[tmp; rr,dd,RV(rr,dd)]; end, end, end %#ok<AGROW>
if isempty(tmp), candidateList=zeros(0,3); return; end
[~,ord]=sort(tmp(:,3),'descend'); candidateList=tmp(ord(1:min(maxPeaks,numel(ord))),:);
end
function selected = timed_select_separated_candidates(cand,maxCandidates,minRangeDistance,minDopplerDistance)
if isempty(cand), selected=zeros(0,3); return; end
[~,ord]=sort(cand(:,3),'descend'); cand=cand(ord,:); selected=[];
for ii=1:size(cand,1)
    if isempty(selected) || all(abs(selected(:,1)-cand(ii,1))>=minRangeDistance | abs(selected(:,2)-cand(ii,2))>=minDopplerDistance)
        selected=[selected; cand(ii,:)]; %#ok<AGROW>
    end
    if size(selected,1)>=maxCandidates, break; end
end
end
function tf = timed_is_local_max(A,rr,dd), block=A(rr-1:rr+1,dd-1:dd+1); tf=A(rr,dd)==max(block(:)); end

function [isUAV,score,spacing,matched,width,reason]=timed_classify_hybrid_peaks_adjacent(g,d0,offsets,rule) %#ok<INUSD>
[isUAV,score,spacing,matched,width,reason]=timed_classify_hybrid_peaks(g,rule,d0);
end

function [isUAV,bestScore,bestSpacing,matchedPeaks,widthBins,reason]=timed_classify_hybrid_peaks(g,rule,forcedCenter)
if nargin<3, forcedCenter=[]; end
[isUAV,bestScore,bestSpacing,matchedPeaks,widthBins,reason]=model_decision_1542_local(g,rule,forcedCenter);
end

function widthBins=timed_spectral_width_bins(g,powerFraction)
p=abs(g(:)).^2; p=p/(sum(p)+eps); [~,peakIdx]=max(p); left=peakIdx; right=peakIdx; captured=p(peakIdx);
while captured<powerFraction && (left>1 || right<numel(p))
    lp=-inf; rp=-inf; if left>1, lp=p(left-1); end; if right<numel(p), rp=p(right+1); end
    if lp>=rp, left=left-1; captured=captured+p(left); else, right=right+1; captured=captured+p(right); end
end
widthBins=right-left+1;
end
function [isUAV,bestScore,bestSpacing,matchedPeaks,reason]=timed_classify_periodic_peaks(g,rule,forcedCenter)
if nargin<3, forcedCenter=[]; end
[isUAV,bestScore,bestSpacing,matchedPeaks,reason]=classify_periodic_unique_local(g,rule,forcedCenter);
end

function [peakIdx,peakVal]=timed_simple_find_peaks(y,relThreshold,minDistance)
y=y(:); peakIdx=[]; peakVal=[]; threshold=relThreshold*max(y+eps);
for ii=2:(numel(y)-1), if y(ii)>=threshold && y(ii)>=y(ii-1) && y(ii)>y(ii+1), peakIdx(end+1,1)=ii; peakVal(end+1,1)=y(ii); end, end %#ok<AGROW>
if isempty(peakIdx), return; end
[peakVal,ord]=sort(peakVal,'descend'); peakIdx=peakIdx(ord); keepIdx=[]; keepVal=[];
for ii=1:numel(peakIdx), if isempty(keepIdx)||all(abs(peakIdx(ii)-keepIdx)>=minDistance), keepIdx(end+1,1)=peakIdx(ii); keepVal(end+1,1)=peakVal(ii); end, end %#ok<AGROW>
[peakIdx,ord]=sort(keepIdx,'ascend'); peakVal=keepVal(ord);
end
function [tooWideCount,summaryTable]=timed_count_too_wide_components_hybrid(U,theta_grid,rule)
summaryTable=timed_interpret_cpd_components(U,theta_grid,rule); tooWideCount=nnz(summaryTable.DecisionReason=="too wide before periodic test");
end
function T=timed_interpret_cpd_components(U,theta_grid,rule)
[cached,T]=shared_cpd_1542_local('interpretGet',U);
if cached, return; end
interpretTimer=tic;
[U_n,lambda]=timed_normalize_cpd_factors(U);
A=U_n{1}; B=U_n{2}; G=U_n{3}; K=size(A,2); NF=size(B,1); ND=size(G,1);
modelDiagnostics=cell(K,1);
angle=zeros(K,1); range=zeros(K,1); dop=zeros(K,1); score=zeros(K,1);
spacing=zeros(K,1); matched=zeros(K,1); width=nan(K,1); reason=strings(K,1); isUAV=false(K,1);
for kk=1:K
    P=timed_angle_spectrum(A(:,kk),theta_grid); [~,it]=max(P); angle(kk)=theta_grid(it);
    % A raw fast-time tone is flat in magnitude: estimate its frequency.
    spectrum=fft(B(:,kk))/sqrt(NF); [~,coarse]=max(abs(spectrum(1:NF/2)).^2);
    grid=max(1,coarse-1):.02:min(NF/2,coarse+1);
    dictionary=exp(1j*2*pi*(0:NF-1).'*(grid-1)/NF)/sqrt(NF);
    [~,ir]=max(abs(dictionary'*B(:,kk)).^2); range(kk)=grid(ir);
    % Only this 1D fitted slow-time factor is Fourier transformed.
    gd=fftshift(fft(lambda(kk)*G(:,kk)))/sqrt(ND); [~,dop(kk)]=max(abs(gd).^2);
    [isUAV(kk),score(kk),spacing(kk),matched(kk),width(kk),reason(kk),modelDiagnostics{kk}]=...
        model_decision_1542_local(gd,rule,[]);
end
T=table((1:K).',angle,range,dop,score,spacing,matched,width,reason,isUAV,...
 'VariableNames',{'ID','AngleDeg','RangeBin','DopplerBin','PeriodicScore',...
 'BestSpacing','MatchedPeaks','SpectrumWidth','DecisionReason','IsUAV'});
T.ModelDiagnostics=modelDiagnostics;
shared_cpd_1542_local('interpretPut',U,T,toc(interpretTimer));
end

function [bestU,bestRelres]=timed_run_cpd_best_of_restarts(X,size_tens,K,candidateList,theta_grid,cpd_options,numRestarts) %#ok<INUSD>
[bestU,bestRelres]=shared_cpd_1542_local('fit',X,K,candidateList,theta_grid,cpd_options);
end

function Uinit=timed_init_from_candidates(size_tens,K,candidateList,theta_grid)
L=size_tens(1); NF=size_tens(2); ND=size_tens(3);
Uinit={complex(randn(L,K),randn(L,K))/sqrt(L),...
    complex(randn(NF,K),randn(NF,K))/sqrt(NF),...
    complex(randn(ND,K),randn(ND,K))/sqrt(ND)};
for kk=1:min(K,size(candidateList,1))
    theta=theta_grid(randi(numel(theta_grid)));
    Uinit{1}(:,kk)=timed_steering_ula(L,theta)+.05*complex(randn(L,1),randn(L,1))/sqrt(L);
    Uinit{2}(:,kk)=raw_range_tone_local(NF,candidateList(kk,1))+.05*complex(randn(NF,1),randn(NF,1))/sqrt(NF);
    Uinit{3}(:,kk)=raw_doppler_tone_local(ND,candidateList(kk,2))+.05*complex(randn(ND,1),randn(ND,1))/sqrt(ND);
end
end

function [Un,lambda]=timed_normalize_cpd_factors(U)
Nmode=numel(U); R=size(U{1},2); Un=U; lambda=ones(1,R);
for r=1:R, for n=1:Nmode, sc=norm(Un{n}(:,r)); if sc<eps, sc=1; end; Un{n}(:,r)=Un{n}(:,r)/sc; lambda(r)=lambda(r)*sc; end, end
end































% Bounded CFAR-initialized variant of the installed Tensorlab rankest.
function [R,L_lb,L_cpd,cornerInfo] = rankest_cfar_local(T,varargin)
% Local Tensorlab rankest copy: respect explicit MinR and report fallback.
% Original authors and algorithm are retained below.
%   rankest(T) plots an L-curve of number of rank-one terms in a canonical
%   polyadic decomposition. The x-axis corresponds to the number of
%   rank-one terms, and the y-axis corresponds to the relative error of the
%   CPD in that many rank-one terms. Additionally, the corner R of the
%   resulting L-curve is estimated. The rank of a tensor can be different
%   when computed over the real field or the complex field. (See options
%   below.)
%
%   R = rankest(T) does not plot anything and instead returns the number of
%   rank-one terms R corresponding to the corner of the L-curve.
%
%   [R,L_lb,L_cpd] = rankest(T) also returns the L-curve ranks L_lb(:,1)
%   and L_cpd(:,1) and the corresponding lower bound on the truncation
%   error L_lb(:,2) and relative error of the CPD approximation L_cpd(:,2),
%   respectively.
%
%   rankest(T,options) may be used to set the following options:
%
%      options.MaxR =           - Maximum number of rank-one terms to try.
%      numel(T)/max(size_tens)
%      options.MinR = 1         - Minimum number of rank-one terms to try.
%                                 Only used if explicitly given, otherwise
%                                 MinR is chosen based on MaxRelErr, see
%                                 below. 
%      options.MaxRelErr = 1e-1 - Determines a lower threshold for the
%                                 number of rank-one terms R to try, based
%                                 on a lower bound of the relative error.
%      options.MinRelErr = 1e-2 - Determines an upper threshold for the
%                                 number of rank-one terms R to try.
%      options.Solver = @cpd    - The solver used to compute the CPD for
%                                 each number of rank-one terms R. Called
%                                 as options.Solver(T,R, ...
%                                 options.SolverOptions), where
%                                 options.SolverOptions is an options
%                                 structure passed to the solver.
%      options.XMultiplier = 1  - The importance of the number of rank-one
%                                 terms in determining the L-curve corner,
%                                 relative to the importance of the
%                                 relative error of the approximation.
%      options.Complex =        - Compute the rank over the real or the
%         [{'auto'}, true]        complex field. If 'auto', the rank is
%                                 computed over the real field if the tensor
%                                 is real-valued, and over the complex field
%                                 if the tensor is complex-valued. If equal
%                                 to true, the rank is computed over the
%                                 complex field.
%
%   See also mlrankest.

%   Authors: Laurent Sorber      (Laurent.Sorber@cs.kuleuven.be)
%            Nico Vervliet       (Nico.Vervliet@esat.kuleuven.be)
%            Marc Van Barel      (Marc.VanBarel@cs.kuleuven.be)
%            Lieven De Lathauwer (Lieven.DeLathauwer@kuleuven-kulak.be)
%
%   References:
%   [1] J.L. Castellanos, S. Gomez, V. Guerra, "The triangle method for
%       finding the corner of the L-curve," Applied Numerical Mathematics,
%       Vol. 43, No. 4, 2002, pp. 359-373.
%
% Version History:
% - 2016/03/14   NV      Restored MaxRelErr option
% - 2015/10/14   NV      Added explicit option for complex tensors

type = getstructure(T);
if any(strcmpi(type, {'full', 'incomplete', 'sparse'}))
    T = fmt(T,true);
    type = getstructure(T);
end 
size_tens = getsize(T);

% Parse options
p = inputParser();
p.addOptional('MaxR', prod(size_tens)/max(size_tens));
p.addOptional('MinR', 1);
p.addOptional('MaxRelErr', 1e-1);
p.addOptional('MinRelErr', 1e-2);
p.addOptional('Complex', 'auto');
p.addOptional('Solver', @cpd);
p.addOptional('SolverOptions', {});
p.addOptional('XMultiplier', 1);
p.addOptional('StopTest', []);
p.parse(varargin{:});
options = p.Results;

% Update some options
if isstruct(options.SolverOptions)
    fn = fieldnames(options.SolverOptions);
    fields = struct2cell(options.SolverOptions);
    tmp = [fn(:).'; fields(:).'];
    options.SolverOptions = tmp(:).';
end
fn = options.SolverOptions(1:2:end);
if ~any(strcmpi(fn,'ExploitStructure'))
    options.SolverOptions{end+1} = 'ExploitStructure';
    options.SolverOptions{end+1} = false;
end
if ~any(strcmpi(fn,'Display'))
    options.SolverOptions{end+1} = 'Display';
    options.SolverOptions{end+1} = false;
end
if ~any(strcmpi(fn,'Complex'))
    options.SolverOptions{end+1} = 'Complex';
    options.SolverOptions{end+1} = options.Complex;
end
if ~any(strcmpi(fn,'TolFun'))
    if options.MinRelErr < 1e-6, 
        TolFun = max(options.MinRelErr^2, eps^2);
        if options.MinRelErr < 1e-14
            TolFun = eps^2;
        end
        options.SolverOptions{end+1} = 'TolFun';
        options.SolverOptions{end+1} = TolFun;
    end
end
if ~any(strcmpi(fn,'TolX'))
    if options.MinRelErr < 1e-6, 
        TolX = max(options.MinRelErr, eps/10);
        if options.MinRelErr < 1e-13
            TolX = 0;
        end
        options.SolverOptions{end+1} = 'TolX';
        options.SolverOptions{end+1} = TolX;
    end
end

% Compute lower bound on truncation error.
frobT = frob(T);
if any(strcmpi(type, {'full', 'sparse'}))
    if isstruct(T)
        [~,~,sv] = mlsvds(T);
    else 
        [~,~,sv] = mlsvd(T);
    end
    Rmax = max(cellfun(@length,sv))-1;
    lb = max(cell2mat(cellfun( ...
             @(s)[sqrt(flipud(cumsum(flipud(s(:).^2)))).'/frobT ...
             zeros(1,Rmax+1-length(s))],sv(:),'UniformOutput',false)));
    lb = lb(2:end);
else
    Rmax = 0;
    lb = [];
end

% Determine the range of rank-one terms to test.
if ~isempty(lb) && any(strcmpi(p.UsingDefaults, 'MinR'))
    %R = find(lb(options.MinR:end)<=options.MinRelErr,1,'first')+ ...
    R = find(lb(options.MinR:end)<=options.MaxRelErr,1,'first') + ...
        options.MinR-1;
    if isempty(R), R = max(options.MinR,Rmax+1); end
    R = R:options.MaxR;
else
    R = options.MinR:options.MaxR;
end

cornerInfo = struct('searchStopReason', "rank search budget reached", 'stopTriggeredRank', NaN);
% Compute the relative error for each number of rank-one terms R(r).
relerr = zeros(1,length(R));
warningstate = warning('query', 'MATLAB:nearlySingularMatrix');
warning('off', 'MATLAB:nearlySingularMatrix')
for r = 1:length(R)
    
    % Compute the CPD in R rank-one terms.    
    [U,output] = options.Solver(T,R(r),options.SolverOptions{:});
    if isfield(output,'Refinement') && ...
            isfield(output.Refinement, 'relerr')
        relerr(r) = output.Refinement.relerr;
    elseif isfield(output,'Refinement') && ...
       isfield(output.Refinement,'fval')
        relerr(r) = sqrt(2*output.Refinement.fval(end))/frobT;
    elseif isfield(output,'Algorithm') && ...
            isfield(output.Algorithm, 'relerr')
        relerr(r) = output.Algorithm.relerr;
    elseif isfield(output,'Algorithm') && ...
           isfield(output.Algorithm,'fval')
        relerr(r) = sqrt(2*output.Algorithm.fval(end))/frobT;
    elseif isfield(output,'fval')
        relerr(r) = sqrt(2*output.fval(end))/frobT;
    else
        relerr(r) = frobcpdres(T,U)/frobT;
    end
    
    if ~isempty(options.StopTest) && options.StopTest(R(1:r), relerr(1:r))
        cornerInfo.searchStopReason = "consecutive small residual gains";
        cornerInfo.stopTriggeredRank = R(r);
        R = R(1:r);
        relerr = relerr(1:r);
        break;
    end
    % Stop is options.MinRelErr has been reached.
    if relerr(r) <= options.MinRelErr
        cornerInfo.searchStopReason = "minimum relative residual reached";
        cornerInfo.stopTriggeredRank = R(r);
        R = R(1:r);
        relerr = relerr(1:r);
        break;
    end
    
    % Update the plot.
    if r > 1 && r < length(R) && nargout == 0, 
        if r == 2, clf; end
        Lcurve(true); 
    end

end
warning(warningstate.state, 'MATLAB:nearlySingularMatrix')

% Compute L-curve corner using the triangle method [1].
logx = options.XMultiplier*[R(:);R(end)+1];
logy = [log10(relerr(:));log10(relerr(end))];
if R(1) ~= 1
    logx = [options.XMultiplier;logx];
    if ~isempty(lb), logy = [log10(lb(1));logy];
    else logy = [0;logy]; end
end
ab = cat(3,bsxfun(@minus,logx,logx.'),bsxfun(@minus,logy,logy.'));
ac = cat(3,logx(end)-logx.',logy(end)-logy.');
area = bsxfun(@times,ab(:,:,1),ac(:,:,2)) - ...
       bsxfun(@times,ab(:,:,2),ac(:,:,1));
cosa = bsxfun(@times,ab(:,:,1),ac(:,:,1)) + ...
       bsxfun(@times,ab(:,:,2),ac(:,:,2));
cosa = bsxfun(@rdivide,cosa./sqrt(ab(:,:,1).^2+ab(:,:,2).^2), ...
                       sqrt(ac(:,:,1).^2+ac(:,:,2).^2));
cosa(area >= 0 | tril(true(size(cosa))) | cosa <= cos(7*pi/8)) = -1;
[a,opt] = max(max(cosa));
cornerInfo.fallbackToFirstRank = isempty(a) || a == -1;
if isempty(a) || a == -1, opt = 1;
elseif R(1) ~= 1, opt = opt-1; end

% Display output.
L_lb = [(1:Rmax).' lb(:)];
L_cpd = [R(:) relerr(:)];
if nargout == 0, Lcurve(false); end
R = R(opt);

function Lcurve(update)
    if R(r) <= 1, return; end
    style = {'Marker','+','MarkerSize',2.5};
    if ~update
        semilogy(R(opt),relerr(opt),'rs','LineStyle','none'); hold on;
    end
    semilogy(R(1:length(relerr)),relerr,'r',style{:}); hold on;
    semilogy(1:length(lb),lb,style{:});
    semilogy([1 R(r)],options.MaxRelErr*[1 1],'k:');
    semilogy([1 R(r)],options.MinRelErr*[1 1],'k:');
    text(1,options.MaxRelErr,'MaxRelErr','VerticalAlignment','Top');
    text(1,options.MinRelErr,'MinRelErr','VerticalAlignment','Top');
    hold off;
    if isempty(lb), lb1 = options.MaxRelErr*10^0.5; else lb1 = lb(1); end
    ylim([min(options.MinRelErr/(10^0.5),min(relerr(1:r))) ...
          max(options.MaxRelErr*10^0.5,lb1)]);
    %ylim([min(options.MinRelErr/(10^0.5),min(relerr(1:r))) 1]);
    xlim([1 R(r)]);
    ylabel('frob(cpdres(T,U))/frob(T)'); xlabel('R');
    xt = get(gca,'XTick'); set(gca,'XTick',xt(mod(xt,1) == 0));
    if update
        if ~isempty(lb)
            legend(['CPD error (trying R = ' int2str(R(r+1)) '...)'], ...
                'Lower bound on error','Location','NE');
        else
            legend(['CPD error (trying R = ' int2str(R(r+1)) '...)'], ...
                'Location','NE');
        end
    else
        if ~isempty(lb)
            legend(['L-curve corner at R = ' int2str(R(opt))], ...
                'CPD error','Lower bound on error','Location','NE');
        else
            legend(['L-curve corner at R = ' int2str(R(opt))], ...
                'CPD error','Location','NE');
        end
    end
    set(datacursormode(gcf),'UpdateFcn',@datacursor);
    drawnow;
end

function txt = datacursor(~,event_obj)
    pos = get(event_obj,'Position');
    txt = {['R: ' int2str(pos(1))], ...
           ['relative error: ' num2str(pos(2))]};
end

end





function [Ubest, bestResidual, audit] = direct_monotone_1542_local(X, Ucandidate, previous, R, ...
        candidates, thetaGrid, solverOptions, retryRestarts, maxRetryRounds)
audit = struct('Retried',false,'RetryRounds',0,'UsedEmbeddedFit',false);
Ubest = Ucandidate;
bestResidual = stable_cpd_relative_residual_local(X, Ucandidate);
if isempty(previous)
    return;
end
reference = previous.relres;
if ~isempty(Ubest) && isfinite(bestResidual) && bestResidual <= reference
    return;
end
audit.Retried = true;
% A zero-weight extra term gives a feasible rank-at-most-R representation
% of the previous fit. Its residual is recomputed from its actual factors.
Ubest = expand_previous_cpd_local(previous.U, R, X);
bestResidual = stable_cpd_relative_residual_local(X, Ubest);
if bestResidual > reference
    error('MonotoneCPD:EmbeddingResidual', ...
        'The embedded previous fit does not reproduce its reference residual.');
end
audit.UsedEmbeddedFit = true;
for attempt = 1:maxRetryRounds
    audit.RetryRounds = attempt;
    warmStart = residual_augmented_cpd_local(previous.U, R, X);
    try
        Utry = cpd(X, warmStart, solverOptions);
        trialResidual = stable_cpd_relative_residual_local(X, Utry);
        if isfinite(trialResidual) && trialResidual < bestResidual
            Ubest = Utry;
            bestResidual = trialResidual;
            audit.UsedEmbeddedFit = false;
        end
    catch
        % A failed warm start is followed by independent random restarts.
    end
    if ~audit.UsedEmbeddedFit
        break;
    end
    [Utry, ~] = independent_fit_1542_local(X, R, ...
        candidates, thetaGrid, solverOptions, retryRestarts);
    trialResidual = stable_cpd_relative_residual_local(X, Utry);
    if ~isempty(Utry) && isfinite(trialResidual) && trialResidual < bestResidual
        Ubest = Utry;
        bestResidual = trialResidual;
        audit.UsedEmbeddedFit = false;
        break;
    end
end
end

function Uextended = expand_previous_cpd_local(Uprevious, R, X)
previousRank = size(Uprevious{1},2);
if R <= previousRank
    error('MonotoneCPD:RankOrder', 'The requested rank must exceed the previous rank.');
end
Uextended = Uprevious;
for n = 1:numel(Uprevious)
    additional = randn(size(Uprevious{n},1),R-previousRank) + ...
        1j*randn(size(Uprevious{n},1),R-previousRank);
    additional = additional ./ max(vecnorm(additional),eps);
    if n == 1
        % Only one factor is zero: gradients can activate the added term.
        additional = zeros(size(additional),'like',X);
    end
    Uextended{n} = [Uprevious{n}, additional];
end
end

function Uextended = residual_augmented_cpd_local(Uprevious, R, X)
% Remove numerical padding before optimization, then add residual directions.
active = true(1,size(Uprevious{1},2));
for n = 1:numel(Uprevious)
    active = active & vecnorm(Uprevious{n}) > 0;
end
Uextended = cellfun(@(factor) factor(:,active), Uprevious, 'UniformOutput',false);
[~, Xhat] = stable_cpd_relative_residual_local(X, Uextended);
residual = X - Xhat;
while size(Uextended{1},2) < R
    b = randn(size(X,2),1) + 1j*randn(size(X,2),1);
    c = randn(size(X,3),1) + 1j*randn(size(X,3),1);
    b = b / max(norm(b),eps);
    c = c / max(norm(c),eps);
    a = reshape(residual,size(X,1),[]) * conj(kron(c,b));
    if norm(a) == 0
        a = eps * (randn(size(X,1),1) + 1j*randn(size(X,1),1));
    end
    Uextended{1}(:,end+1) = a;
    Uextended{2}(:,end+1) = b;
    Uextended{3}(:,end+1) = c;
    residual = residual - reshape(a*b.',size(X,1),size(X,2),1) .* ...
        reshape(c,1,1,size(X,3));
end
end

function [relres, Xhat] = stable_cpd_relative_residual_local(X, U)
relres = inf;
Xhat = [];
if isempty(U) || numel(U) ~= 3
    return;
end
for n = 1:3
    if any(~isfinite(U{n}(:)))
        return;
    end
end
% Fixed summation order preserves the residual exactly when zero-weight
% columns are appended, avoiding artificial negative gains from reordering.
Xhat = zeros(size(X),'like',X);
for r = 1:size(U{1},2)
    spatialRange = U{1}(:,r) * U{2}(:,r).';
    Xhat = Xhat + reshape(spatialRange,size(X,1),size(X,2),1) .* ...
        reshape(U{3}(:,r),1,1,size(X,3));
end
relres = norm(Xhat(:)-X(:)) / max(norm(X(:)),eps);
end

function T = mark_zero_weight_components_local(T, U)
if isempty(T)
    return;
end
zeroWeight = false(size(U{1},2),1);
for n = 1:numel(U)
    zeroWeight = zeroWeight | (vecnorm(U{n}).' == 0);
end
T.IsUAV(zeroWeight) = false;
T.PeriodicScore(zeroWeight) = 0;
T.MatchedPeaks(zeroWeight) = 0;
T.SpectrumWidth(zeroWeight) = NaN;
T.DecisionReason(zeroWeight) = "zero-weight nonphysical component";
end


function [streak, stop] = update_residual_plateau_local(errors, eligible, streak, threshold, required)
% Numerical fallback fits are ineligible evidence for a residual plateau.
small = false;
if eligible && numel(errors) >= 2
    gain = (errors(end-1)-errors(end))/max(errors(end-1),eps);
    small = isfinite(gain) && gain >= 0 && gain < threshold;
end
if small, streak = streak + 1; else, streak = 0; end
stop = streak >= required;
end

function one = run_os_cfar_framework_local(X, opts)
opts=timed_fill_default_opts(opts);
RV=squeeze(sum(abs(X).^2,1));
[candidates,info]=os_candidates_from_map_local(RV,opts,size(X,1),false(size(RV)));
one=classify_os_candidates_local(X,candidates,opts);
one.frameworkKey="os_cfar"; one.cfarInfo=info;
end

function one=run_os_cfar_clean_framework_local(X,opts)
% Power-domain CLEAN with actual windowed FFT point responses, not truth positions.
opts=timed_fill_default_opts(opts);
cfg=get_field_default_local(opts,'osClean',struct());
gain=get_field_default_local(cfg,'loopGain',0.8);
maxIterations=get_field_default_local(cfg,'maxIterations',256);
% The full FFT response is used, including its sidelobes.
validateattributes(gain,{'numeric'},{'scalar','positive','<=',1});
validateattributes(maxIterations,{'numeric'},{'scalar','integer','positive'});
RV=squeeze(sum(abs(X).^2,1)); residual=RV; blocked=false(size(RV));
candidates=zeros(0,3); iterations=0;
stopReason="iteration budget";
cap=timed_get_opt(opts,'cfarMaxCandidates',inf);
history=zeros(maxIterations,4);
for ii=1:maxIterations
    [pool,info]=os_candidates_from_map_local(residual,opts,size(X,1),blocked);
    if isempty(pool), stopReason="no residual OS-CFAR peaks"; break; end
    rr=pool(1,1); dd=pool(1,2); peak=residual(rr,dd);
    candidates(end+1,:)=[rr dd RV(rr,dd)]; %#ok<AGROW>
    r=(1:size(RV,1)).'; d=1:size(RV,2);
    br=raw_processed_range_atom_local(size(RV,1),rr,opts,'cfar');
    bd=raw_processed_doppler_atom_local(size(RV,2),dd,opts,'cfar');
    psf=(abs(br).^2)*(abs(bd.').^2);
    psf=psf/max(psf(rr,dd),eps);
    subtraction=min(residual,gain*peak*psf);
    residual=residual-subtraction;
    iterations=ii; history(ii,:)=[rr dd peak sum(subtraction(:))];
    % Same candidate-separation rule as plain OS, not output target merging.
    rBlock=max(1,rr-1):min(size(RV,1),rr+1);
    dBlock=max(1,dd-2):min(size(RV,2),dd+2);
    blocked(rBlock,dBlock)=true;
    if size(candidates,1)>=cap, stopReason="candidate budget"; break; end
end
one=classify_os_candidates_local(X,candidates,opts);
one.frameworkKey="os_cfar_clean"; one.cfarInfo=info;
one.cleanInfo=struct('loopGain',gain,'maxIterations',maxIterations,...
    'iterations',iterations,'responseModel',"actual windowed finite-length DFT point response",...
    'history',history(1:iterations,:),'stopReason',stopReason,...
    'domain',"range-Doppler power map",'classificationData',"original received tensor",...
    'initialPower',sum(RV(:)),'finalResidualPower',sum(residual(:)));
end

function one=classify_os_candidates_local(X,candidates,opts)
[physical,allRows]=timed_run_traditional_chain(X,opts.theta_grid,opts,candidates);
one=struct('allEstimate',allRows,'afterNoiseRemoval',physical,...
    'uavEstimateRaw',physical(logical(physical.IsUAV),:),...
    'candidateCount',size(candidates,1),'candidates',candidates);
one.uavEstimate=timed_merge_duplicate_uav_estimates(one.uavEstimateRaw,opts.uavMergeRule);
end

function [candidates,info]=os_candidates_from_map_local(RV,opts,shape,blocked)
cfg=get_field_default_local(opts,'osCfar',struct());
pfa=get_field_default_local(cfg,'Pfa',1e-4);
fraction=get_field_default_local(cfg,'orderFraction',0.75);
matchCA=get_field_default_local(cfg,'matchCAEffectivePfa',true);
validateattributes(pfa,{'numeric'},{'scalar','positive','<',1});
validateattributes(fraction,{'numeric'},{'scalar','positive','<=',1});
gR=2; gD=2; wR=8; wD=10;
mask=true(2*wR+1,2*wD+1);
mask(wR-gR+1:wR+gR+1,wD-gD+1:wD+gD+1)=false;
n=nnz(mask); k=ceil(fraction*n);
alpha=opts.rawCFARCalibration.osScale; targetPfa=opts.rawCFARCalibration.targetPfa;
candidates=zeros(0,3);
for rr=wR+1:size(RV,1)-wR
    for dd=wD+1:size(RV,2)-wD
        if blocked(rr,dd) || ~timed_is_local_max(RV,rr,dd), continue; end
        block=RV(rr-wR:rr+wR,dd-wD:dd+wD); ref=sort(block(mask));
        if RV(rr,dd)>alpha*ref(k)
            candidates(end+1,:)=[rr dd RV(rr,dd)]; %#ok<AGROW>
        end
    end
end
candidates=timed_select_separated_candidates(candidates,...
    timed_get_opt(opts,'cfarMaxCandidates',inf),2,3);
info=struct('orderIndex',k,'referenceCells',n,'noiseShape',shape,...
    'thresholdScale',alpha,'nominalPfa',pfa,'effectiveTargetPfa',targetPfa,...
    'matchCAEffectivePfa',false,'calibration',opts.rawCFARCalibration);
end

function [alpha,target] = os_threshold_scale_local(n,k,shape,pfa,matchCA)
% Sum of independent channel powers is Gamma(shape,1), not exponential.
persistent keys values targets
key=sprintf('%d/%d/%d/%.16g/%d',n,k,shape,pfa,matchCA);
idx=find(strcmp(keys,key),1);
if ~isempty(idx), alpha=values(idx); target=targets(idx); return; end
target=pfa;
if matchCA
    caAlpha=n*(pfa^(-1/n)-1);
    target=betainc(caAlpha/(n+caAlpha),shape,n*shape,'upper');
end
target=max(realmin,target);
hi=1;
while os_noise_pfa_local(hi,n,k,shape,target)>target
    hi=hi*2;
    if hi>1e6, error('OSCFAR:Calibration','Cannot bracket threshold multiplier.'); end
end
alpha=fzero(@(a) log(max(realmin,os_noise_pfa_local(a,n,k,shape,target)))-log(target),[0 hi]);
keys{end+1}=key; values(end+1)=alpha; targets(end+1)=target;
end

function p = os_noise_pfa_local(alpha,n,k,shape,toleranceScale)
coefficient=gammaln(n+1)-gammaln(k)-gammaln(n-k+1);
integrand=@(z) os_order_integrand_local(z,alpha,n,k,shape,coefficient);
p=integral(integrand,0,Inf,'RelTol',1e-6, ...
    'AbsTol',max(realmin,toleranceScale*1e-5));
end

function out = os_order_integrand_local(z,alpha,n,k,shape,coefficient)
z=max(z,realmin);
F=max(gammainc(z,shape,'lower'),realmin);
S=max(gammainc(z,shape,'upper'),realmin);
logDensity=coefficient+(k-1)*log(F)+(n-k)*log(S) ...
    +(shape-1)*log(z)-z-gammaln(shape);
out=gammainc(alpha*z,shape,'upper').*exp(logDensity);
end

function one = run_joint_music_framework_local(X, opts)
% Adapted MUSIC-LS baseline on rectangular-FFT data with matched complex response.
opts=timed_fill_default_opts(opts);
cfg=get_field_default_local(opts,'jointMusic',struct());
cap=get_field_default_local(cfg,'maxSources',32);
angleStep=get_field_default_local(cfg,'angleStepDeg',0.5);
rangeStep=get_field_default_local(cfg,'rangeStepBin',0.25);
ridge=get_field_default_local(cfg,'ridge',1e-6);
validateattributes(cap,{'numeric'},{'scalar','integer','positive'});
validateattributes(angleStep,{'numeric'},{'scalar','finite','positive'});
validateattributes(rangeStep,{'numeric'},{'scalar','finite','positive'});
validateattributes(ridge,{'numeric'},{'scalar','finite','nonnegative'});
[M,NR,ND]=size(X); Y=reshape(X,M*NR,ND);
[left,S,~]=svd(Y,'econ');
lambda=diag(S).^2/(M*NR);
% Dual covariance avoids the identically zero sample eigenvalues when M*NR>ND.
% Its sensor-range rows are structured: MDL here is an adapted order criterion.
[K,orders,mdl]=joint_music_mdl_local(lambda,M*NR,cap);
T=empty_estimate_table_local();
info=struct('selectedRank',K,'estimatedSourceCount',K,'mdlCurve',[orders mdl], ...
    'squaredSingularValues',lambda,'effectiveSnapshots',M*NR, ...
    'orderCriterion',"adapted dual-Gram MDL; no true-count or CFAR prior", ...
    'locatedSourceCount',0,'dictionaryCondition',NaN);
if K>0
    Us=left(:,1:K);
    angles=min(opts.theta_grid):angleStep:max(opts.theta_grid);
    ranges=1:rangeStep:NR;
    A=exp(1j*pi*(0:M-1).'*sind(angles))/sqrt(M);
    B=zeros(NR,numel(ranges));
    for jj=1:numel(ranges), B(:,jj)=raw_processed_range_atom_local(NR,ranges(jj),opts,'rect'); end
    Q=reshape(A'*reshape(Us,M,NR*K),numel(angles),NR,K);
    projection=zeros(numel(angles),numel(ranges));
    for jj=1:K, projection=projection+abs(Q(:,:,jj)*conj(B)).^2; end
    spectrum=1./max(1-projection,1e-12);
    loc=joint_music_peaks_local(spectrum,angles,ranges,K);
    if get_field_default_local(cfg,'refine',true)
        searchOptions=optimset('Display','off','MaxIter',80,'TolX',1e-4,'TolFun',1e-9);
        for jj=1:size(loc,1)
            objective=@(v) joint_music_objective_local(v,Us,M,NR,opts, ...
                [angles(1) angles(end)]);
            refined=fminsearch(objective,loc(jj,:),searchOptions);
            if objective(refined)<=objective(loc(jj,:))
                loc(jj,:)=refined;
            end
        end
    end
    % Remove only numerically duplicate locations, not nearby physical targets.
    keep=true(size(loc,1),1);
    for jj=2:size(loc,1)
        keep(jj)=~any(abs(loc(1:jj-1,1)-loc(jj,1))<1e-3 & ...
            abs(loc(1:jj-1,2)-loc(jj,2))<1e-3);
    end
    loc=loc(keep,:); L=size(loc,1); D=zeros(M*NR,L);
    for jj=1:L
        D(:,jj)=kron(raw_processed_range_atom_local(NR,loc(jj,2),opts,'rect'), ...
            timed_steering_ula(M,loc(jj,1)));
    end
    if L>0
        G=(D'*D+ridge*eye(L))\(D'*Y);
        for jj=1:L
            g=G(jj,:).'; [~,dop]=max(abs(g));
            [isUAV,score,spacing,matched,width,reason]=timed_classify_hybrid_peaks(g,opts.periodicRule);
            label="Object";
            if contains(reason,["too wide","model-unstructured"]), label="Rejected";
            elseif isUAV, label="UAV"; end
            T=[T;table(jj,loc(jj,1),loc(jj,2),dop,score,spacing,matched,width, ...
                string(reason),logical(isUAV),label,'VariableNames',T.Properties.VariableNames)]; %#ok<AGROW>
        end
        info.dictionaryCondition=cond(D);
    end
    info.locatedSourceCount=L;
end
physical=T(~contains(T.DecisionReason,["too wide","model-unstructured"]),:);
one=struct('allEstimate',T,'afterNoiseRemoval',physical, ...
    'uavEstimateRaw',T(logical(T.IsUAV),:),'rankInfo',info);
one.uavEstimate=merge_duplicate_uav_estimates_local(one.uavEstimateRaw,opts.uavMergeRule);
one.frameworkKey="mdl_joint_music";
end



function [K,orders,score] = joint_music_mdl_local(lambda,nSnap,cap)
% Wax-Kailath MDL penalty, adapted to the dual Gram spectrum used above.
lambda=max(real(lambda(:)),realmin);
dim=numel(lambda); maxK=max(0,min([cap,dim-2,nSnap-1]));
orders=(0:maxK).'; score=zeros(size(orders));
for jj=1:numel(orders)
    k=orders(jj); tail=lambda(k+1:end);
    likelihood=nSnap*(dim-k)*max(0,log(mean(tail))-mean(log(tail)));
    score(jj)=likelihood+0.5*k*(2*dim-k)*log(max(nSnap,2));
end
[~,best]=min(score); K=orders(best);
end

function loc = joint_music_peaks_local(P,angles,ranges,K)
local=true(size(P));
for da=-1:1
    for dr=-1:1
        if da==0 && dr==0, continue; end
        shifted=-inf(size(P));
        ia=max(1,1-da):min(size(P,1),size(P,1)-da);
        ir=max(1,1-dr):min(size(P,2),size(P,2)-dr);
        shifted(ia,ir)=P(ia+da,ir+dr);
        local=local & P>=shifted;
    end
end
[aa,rr]=find(local); strength=P(sub2ind(size(P),aa,rr));
[~,order]=sort(strength,'descend'); order=order(1:min(K,numel(order)));
loc=[reshape(angles(aa(order)),[],1),reshape(ranges(rr(order)),[],1)];
end

function value = joint_music_objective_local(v,Us,M,NR,opts,angleBounds)
if any(~isfinite(v)) || v(1)<angleBounds(1) || v(1)>angleBounds(2) || v(2)<1 || v(2)>NR
    value=1e3+sum(abs(v)); return;
end
d=kron(raw_processed_range_atom_local(NR,v(2),opts,'rect'),timed_steering_ula(M,v(1)));
value=max(0,1-sum(abs(Us'*d).^2));
end

function one = run_redundant_tensor_framework_local(X, trad, trueCount, snrDb, mc, opts)
% Controlled oracle-assisted ablation, not an unknown-count estimator.
opts = rk_fill_default_opts(opts);
cfg = get_field_default_local(opts,'redundantBaseline',struct());
offset = get_field_default_local(cfg,'rankOffset',2);
validateattributes(offset,{'numeric'},{'scalar','integer','positive'});
oracleCfg = get_field_default_local(opts,'oracleBaseline',struct());
% Same solver, restart budget, seed policy and postprocessing as oracle CPD.
oracleCfg.numRestarts = get_field_default_local(cfg,'numRestarts', ...
    get_field_default_local(oracleCfg,'numRestarts',opts.numRestarts));
oracleCfg.seedOffset = get_field_default_local(cfg,'seedOffset', ...
    get_field_default_local(oracleCfg,'seedOffset',920000));
localOpts = opts;
localOpts.oracleBaseline = oracleCfg;
one = run_oracle_tensor_framework_local(X,trad,trueCount+offset,snrDb,mc,localOpts);
one.frameworkKey = "redundant_rank_tensor";
one.rankInfo.truePhysicalCount = trueCount;
one.rankInfo.rankOffset = offset;
one.rankInfo.usesTrueCount = true;
one.rankInfo.stopReason = "fixed true physical count plus redundant rank offset";
end





function [isUAV,bestScore,bestSpacing,matchedPeaks,reason]=classify_periodic_unique_local(g,rule,forcedCenter)
p=abs(g(:)).^2; p=p/(max(p)+eps); ND=numel(p);
[peakIdx,peakVal]=timed_simple_find_peaks(p,rule.peakRelThreshold,rule.minPeakDistance);
if isempty(peakIdx)
    isUAV=false; bestScore=0; bestSpacing=0; matchedPeaks=0; reason="no peaks"; return;
end
if isempty(forcedCenter), [~,ii]=max(peakVal); center=peakIdx(ii);
else, center=min(max(round(forcedCenter),1),ND); end
bestScore=-inf; bestSpacing=0; matchedPeaks=0; bestErr=inf;
halfWidth=get_field_default_local(rule,'matchedEnergyHalfWidth',1);
validateattributes(halfWidth,{'numeric'},{'scalar','integer','nonnegative'});
for fr=rule.frCandidates
    expected=center+(-3:3)*fr; expected=expected(expected>=1 & expected<=ND);
    [ei,pi]=unique_ordered_peak_match_local(expected(:),peakIdx,rule.spacingTolerance);
    matched=numel(pi);
    if matched>0
        % Force column shapes regardless of input orientation.
        e=expected(ei); e=e(:); q=peakIdx(pi); q=q(:); avgErr=mean(abs(e-q));
    else, avgErr=inf; end
    lo=max(1,center-3*fr-rule.searchHalfWidth); hi=min(ND,center+3*fr+rule.searchHalfWidth);
    total=sum(p(lo:hi))+eps;
    energyMask=false(ND,1);
    for jj=pi(:).'
        left=max(lo,peakIdx(jj)-halfWidth); right=min(hi,peakIdx(jj)+halfWidth);
        energyMask(left:right)=true;
    end
    % Union of peak neighborhoods counts each energy bin at most once.
    combined=(sum(p(energyMask))/total)*(matched/max(1,numel(expected)))/(1+avgErr);
    % Prefer the largest equally supported spacing over its subharmonics.
    if combined>bestScore+1e-12 || (abs(combined-bestScore)<=1e-12 && fr>bestSpacing)
        bestScore=combined; bestSpacing=fr; matchedPeaks=matched; bestErr=avgErr;
    end
end
if matchedPeaks<rule.minMatchedPeaks, isUAV=false; reason="few unique periodic peaks";
elseif bestScore<rule.minPeriodicScore, isUAV=false; reason="weak periodicity";
elseif bestErr>rule.maxPeriodicityError, isUAV=false; reason="irregular spacing";
else, isUAV=true; reason="unique periodic peaks"; end
end

function [expectedIndices,peakIndices]=unique_ordered_peak_match_local(expected,peaks,tolerance)
% Ordered DP maximizes unique matches, then minimizes total bin error.
expected=expected(:); peaks=peaks(:); ne=numel(expected); np=numel(peaks);
count=zeros(ne+1,np+1); cost=zeros(ne+1,np+1); choice=zeros(ne+1,np+1,'uint8');
for i=1:ne
    for j=1:np
        bestN=count(i,j+1); bestC=cost(i,j+1); action=uint8(1);
        n=count(i+1,j); c=cost(i+1,j);
        if n>bestN || (n==bestN && c<bestC)
            bestN=n; bestC=c; action=uint8(2);
        end
        distance=abs(expected(i)-peaks(j));
        if distance<=tolerance
            n=count(i,j)+1; c=cost(i,j)+distance;
            if n>bestN || (n==bestN && c<=bestC)
                bestN=n; bestC=c; action=uint8(3);
            end
        end
        count(i+1,j+1)=bestN; cost(i+1,j+1)=bestC; choice(i+1,j+1)=action;
    end
end
expectedIndices=zeros(0,1); peakIndices=zeros(0,1); i=ne; j=np;
while i>0 && j>0
    action=choice(i+1,j+1);
    if action==3
        expectedIndices(end+1,1)=i; peakIndices(end+1,1)=j; %#ok<AGROW>
        i=i-1; j=j-1;
    elseif action==1, i=i-1;
    else, j=j-1; end
end
expectedIndices=flipud(expectedIndices); peakIndices=flipud(peakIndices);
end




function opts=raw_fill_default_opts_local(opts)
cfg=get_field_default_local(opts,'raw',struct());
cfg.nFast=get_field_default_local(cfg,'nFast',2*opts.NR);
cfg.carrierHz=get_field_default_local(cfg,'carrierHz',24e9);
cfg.sampleRateHz=get_field_default_local(cfg,'sampleRateHz',2e6);
cfg.chirpSlopeHzPerSec=get_field_default_local(cfg,'chirpSlopeHzPerSec',1e12);
cfg.chirpRepetitionSec=get_field_default_local(cfg,'chirpRepetitionSec',100e-6);
cfg.tensorWindow=get_field_default_local(cfg,'tensorWindow','none');
cfg.cfarRangeWindow=lower(char(get_field_default_local(cfg,'cfarRangeWindow','hann')));
cfg.cfarDopplerWindow=lower(char(get_field_default_local(cfg,'cfarDopplerWindow','hann')));
cfg.calibrationFrames=get_field_default_local(cfg,'calibrationFrames',128);
cfg.calibrationValidationFrames=get_field_default_local(cfg,'calibrationValidationFrames',16);
cfg.calibrationSeed=get_field_default_local(cfg,'calibrationSeed',24681357);
validateattributes(cfg.nFast,{'numeric'},{'scalar','integer','positive'});
validateattributes(cfg.sampleRateHz,{'numeric'},{'scalar','finite','positive'});
validateattributes(cfg.carrierHz,{'numeric'},{'scalar','finite','positive'});
validateattributes(cfg.chirpSlopeHzPerSec,{'numeric'},{'scalar','finite','positive'});
validateattributes(cfg.chirpRepetitionSec,{'numeric'},{'scalar','finite','positive'});
validateattributes(cfg.calibrationFrames,{'numeric'},{'scalar','integer','positive'});
validateattributes(cfg.calibrationValidationFrames,{'numeric'},{'scalar','integer','positive'});
if cfg.nFast~=2*opts.NR, error('RawFMCW:Size','nFast must equal 2*NR for positive-range retention.'); end
if ~strcmpi(cfg.tensorWindow,'none'), error('RawFMCW:CPDWindow','CPD input must be raw and unwindowed.'); end
if cfg.nFast/cfg.sampleRateHz>cfg.chirpRepetitionSec
    error('RawFMCW:Timing','Fast-time sampling interval exceeds chirp repetition interval.');
end
cfg.c0=299792458; cfg.wavelength=cfg.c0/cfg.carrierHz;
cfg.rangeBinMeters=cfg.c0*cfg.sampleRateHz/(2*cfg.chirpSlopeHzPerSec*cfg.nFast);
cfg.dopplerBinHz=1/(opts.ND*cfg.chirpRepetitionSec);
cfg.chirpSampledDurationSec=cfg.nFast/cfg.sampleRateHz;
cfg.sampledBandwidthHz=cfg.chirpSlopeHzPerSec*cfg.chirpSampledDurationSec;
opts.raw=cfg;
if ~isfield(opts,'energyAssist'), opts.energyAssist=struct(); end
if get_field_default_local(opts.energyAssist,'enable',false)
    error('RawFMCW:Rescue','Disable legacy energyAssist; its truth-count/SNR-gated rescue is not used in this version.');
end
opts.energyAssist.enable=false; opts.energyAssist.lowSNREnable=false;
if ~isfield(opts,'osCfar'), opts.osCfar=struct(); end
opts.osCfar.matchCAEffectivePfa=false;
key=raw_calibration_key_local(opts);
if ~isfield(opts,'rawCFARCalibration') || ~isfield(opts.rawCFARCalibration,'key') || ...
        ~strcmp(opts.rawCFARCalibration.key,key)
    opts.rawCFARCalibration=raw_calibrate_cfar_local(opts,key);
end
end

function v=raw_range_tone_local(NF,r)
v=exp(1j*2*pi*(r-1)*(0:NF-1).'/NF)/sqrt(NF);
end

function v=raw_doppler_tone_local(ND,d)
v=exp(1j*2*pi*(d-1-floor(ND/2))*(0:ND-1).'/ND)/sqrt(ND);
end

function w=raw_window_local(N,name)
switch lower(char(name))
    case {'none','rect','rectangular'}, w=ones(N,1);
    case 'hann', w=.5-.5*cos(2*pi*(0:N-1).'/N);
    case 'hamming', w=.54-.46*cos(2*pi*(0:N-1).'/N);
    otherwise, error('RawFMCW:Window','Window must be none, hann or hamming.');
end
w=w*sqrt(N)/max(norm(w),eps); % Unit RMS: preserve expected marginal noise power.
end

function Y=raw_process_tensor_local(X,opts,branch)
if strcmp(branch,'cfar')
    wr=raw_window_local(opts.raw.nFast,opts.raw.cfarRangeWindow);
    wd=raw_window_local(opts.ND,opts.raw.cfarDopplerWindow);
else
    wr=ones(opts.raw.nFast,1); wd=ones(opts.ND,1);
end
Y=X.*reshape(wr,1,[],1).*reshape(wd,1,1,[]);
Y=fft(Y,[],2)/sqrt(opts.raw.nFast);
Y=Y(:,1:opts.NR,:);
Y=fftshift(fft(Y,[],3),3)/sqrt(opts.ND);
end

function v=raw_processed_range_atom_local(NR,r,opts,branch)
tone=raw_range_tone_local(opts.raw.nFast,r);
if strcmp(branch,'cfar'), tone=tone.*raw_window_local(opts.raw.nFast,opts.raw.cfarRangeWindow); end
v=fft(tone)/sqrt(opts.raw.nFast); v=v(1:NR); v=v/max(norm(v),eps);
end

function v=raw_processed_doppler_atom_local(ND,d,opts,branch)
tone=raw_doppler_tone_local(ND,d);
if strcmp(branch,'cfar'), tone=tone.*raw_window_local(ND,opts.raw.cfarDopplerWindow); end
v=fftshift(fft(tone))/sqrt(ND); v=v/max(norm(v),eps);
end

function key=raw_calibration_key_local(opts)
pfa=get_field_default_local(opts.osCfar,'Pfa',1e-4);
fraction=get_field_default_local(opts.osCfar,'orderFraction',.75);
key=sprintf('%d/%d/%d/%d/%s/%s/%.12g/%.12g/%d/%d/%d',...
    opts.M,opts.raw.nFast,opts.NR,opts.ND,opts.raw.cfarRangeWindow,...
    opts.raw.cfarDopplerWindow,pfa,fraction,opts.raw.calibrationFrames,...
    opts.raw.calibrationValidationFrames,opts.raw.calibrationSeed);
end

function info=raw_calibrate_cfar_local(opts,key)
% Noise-only calibration includes window-induced correlation; no target data.
timer=tic; pfa=get_field_default_local(opts.osCfar,'Pfa',1e-4);
fraction=get_field_default_local(opts.osCfar,'orderFraction',.75);
validateattributes(pfa,{'numeric'},{'scalar','positive','<',1});
validateattributes(fraction,{'numeric'},{'scalar','positive','<=',1});
[rr,dd]=ndgrid(9:opts.NR-8,11:opts.ND-10);
cut=sub2ind([opts.NR opts.ND],rr(:),dd(:));
if isempty(cut), error('RawFMCW:CalibrationSize','NR and ND are too small for the CFAR reference window.'); end
[dr,dc]=ndgrid(-8:8,-10:10); mask=~(abs(dr)<=2 & abs(dc)<=2);
offset=dr(mask)+dc(mask)*opts.NR;
indices=offset(:)+cut(:).'; k=ceil(fraction*numel(offset));
nCut=numel(cut); frames=opts.raw.calibrationFrames;
ca=zeros(nCut,frames); os=ca;
stream=RandStream('mt19937ar','Seed',opts.raw.calibrationSeed);
fprintf('Noise-only CFAR calibration: %d frames, %d CUTs/frame; windows=%s/%s.\n',...
    frames,nCut,opts.raw.cfarRangeWindow,opts.raw.cfarDopplerWindow);
for j=1:frames
    X=(randn(stream,opts.M,opts.raw.nFast,opts.ND)+...
        1j*randn(stream,opts.M,opts.raw.nFast,opts.ND))/sqrt(2);
    Z=raw_process_tensor_local(X,opts,'cfar'); RV=squeeze(sum(abs(Z).^2,1));
    ref=RV(indices); ca(:,j)=RV(cut)./mean(ref,1).';
    ref=sort(ref,1); os(:,j)=RV(cut)./ref(k,:).';
    if mod(j,max(1,floor(frames/4)))==0 || j==frames
        fprintf('  Calibration frame %d/%d complete.\n',j,frames);
    end
end
c=sort(ca(:)); o=sort(os(:)); index=max(1,min(numel(c),ceil((1-pfa)*numel(c))));
caScale=c(index); osScale=o(index); clear ca os c o ref
validCA=0; validOS=0; samples=0;
stream=RandStream('mt19937ar','Seed',opts.raw.calibrationSeed+1);
for j=1:opts.raw.calibrationValidationFrames
    X=(randn(stream,opts.M,opts.raw.nFast,opts.ND)+...
        1j*randn(stream,opts.M,opts.raw.nFast,opts.ND))/sqrt(2);
    Z=raw_process_tensor_local(X,opts,'cfar'); RV=squeeze(sum(abs(Z).^2,1));
    ref=RV(indices); validCA=validCA+nnz(RV(cut)>caScale*mean(ref,1).');
    ref=sort(ref,1); validOS=validOS+nnz(RV(cut)>osScale*ref(k,:).');
    samples=samples+nCut;
end
info=struct('key',key,'caScale',caScale,'osScale',osScale,'targetPfa',pfa,...
    'orderIndex',k,'referenceCells',numel(offset),'frames',frames,...
    'sampleCount',nCut*frames,'validationSampleCount',samples,...
    'validationCA',validCA/max(samples,1),'validationOS',validOS/max(samples,1),...
    'expectedTailSamples',nCut*frames*pfa,'seed',opts.raw.calibrationSeed,...
    'elapsedSeconds',toc(timer),'definition',"noise-only cell ratios before local-peak selection");
if info.expectedTailSamples<50
    warning('RawFMCW:SmallCalibration','Only %.1f expected tail samples; increase calibrationFrames for production.',info.expectedTailSamples);
end
fprintf('Calibration complete: CA=%g, OS=%g; validation rates=%g / %g; setup %.2f s.\n',...
    caScale,osScale,info.validationCA,info.validationOS,info.elapsedSeconds);
end

function report=raw_selftest_local(opts)
% Actual MATLAB smoke test; no full sweep or figures are generated.
a=timed_steering_ula(opts.M,17.3);
b=raw_range_tone_local(opts.raw.nFast,30.37);
bins=[64.2 57.2 71.2 50.2 78.2 43.2 85.2];
amps=timed_make_bessel_sideband_amps(1,.8,3,-8);
g=zeros(opts.ND,1);
for j=1:7, g=g+amps(j)*raw_doppler_tone_local(opts.ND,bins(j)); end
g=g/norm(g);
U={a,b,g}; X=timed_outer3(a,b,g);
T=timed_interpret_cpd_components(U,opts.theta_grid,opts.periodicRule);
assert(abs(T.RangeBin-30.37)<.025);
assert(abs(T.DopplerBin-64.2)<.6);
assert(T.MatchedPeaks<=7);
Y=raw_process_tensor_local(X,opts,'rect');
br=fft(b)/sqrt(numel(b)); br=br(1:opts.NR);
gd=fftshift(fft(g))/sqrt(numel(g));
expected=timed_outer3(a,br,gd);
relativeFFTError=norm(Y(:)-expected(:))/norm(expected(:));
assert(relativeFFTError<1e-12);
assert(max(abs(abs(b)-1/sqrt(numel(b))))<1e-12);
cfg=opts; cfg.clusterUAVCounts=1; cfg.spacing.centers=[0 45 64];
cfg.spacing.baseBounds=[20 10 10]; cfg.numRestarts=1;
cfg.rankSelectionRule.retryRestarts=1; cfg.rankSelectionRule.maxRetryRounds=1;
cfg.rankSelectionRule.hardMaxRank=20; cfg.rankestBaseline.numRestarts=1;
cfg.rankestBaseline.maxRank=12; cfg.rankestBaseline.maxRetryRounds=1;
cfg.rankestPlateauBaseline.hardMaxRank=20;
cfg.oracleBaseline.numRestarts=1; cfg.redundantBaseline.numRestarts=1;
cfg.energyAssist.enable=false; cfg.sharedCPD.numRestarts=1; cfg.sharedCPD.maxRetryRounds=1;
result=f_newtype_202610261542(1,1,0,10,1,cfg);
assert(numel(result.methodKeys)==8);
for key={'proposed','rankestTensor','rankestPlateauTensor','oracleTensor','redundantTensor'}
    item=result.methods.(key{1}){1};
    assert(isequal(item.rankInfo.inputSize,[opts.M opts.raw.nFast opts.ND]));
    assert(contains(item.rankInfo.inputDomain,'raw'));
    assert(isequaln(item.uavEstimate,item.uavEstimateRaw));
end
for key={'osCfar','osCfarClean'}
    item=result.methods.(key{1}){1};
    assert(isequal(item.allEstimate.RangeBin,item.candidates(:,1)));
    assert(isequal(item.allEstimate.DopplerBin,item.candidates(:,2)));
end
report=struct('passed',true,'relativeFFTError',relativeFFTError,...
    'rawSize',size(X),'factorRangeBin',T.RangeBin,'factorDopplerBin',T.DopplerBin,...
    'calibration',opts.rawCFARCalibration,'runtimeTable',result.runtimePerMC);
assert(height(result.sharedAudit{1}.fits)==numel(unique(result.sharedAudit{1}.fits.Rank)));
cpdKeys={'proposed','rankestTensor','rankestPlateauTensor','oracleTensor','redundantTensor'};
for aIndex=1:numel(cpdKeys)
 for bIndex=aIndex+1:numel(cpdKeys)
  first=result.methods.(cpdKeys{aIndex}){1}; second=result.methods.(cpdKeys{bIndex}){1};
  if first.rankInfo.selectedRank==second.rankInfo.selectedRank
   fields={'AngleDeg','RangeBin','DopplerBin','PeriodicScore','SpectrumWidth','IsUAV','DecisionReason'};
   assert(isequaln(first.allEstimate(:,fields),second.allEstimate(:,fields)));
  end
 end
end
disp('SELFTEST PASSED: raw extraction, FFT identity, eight-method trial and shared-rank consistency.');
disp(report.runtimeTable);
end



function [Ubest,bestResidual,audit]=ensure_monotone_cpd_local(X,Ucandidate,previous,R,candidates,angles,solverOptions,numRestarts,maxRetryRounds) %#ok<INUSD>
[Ubest,bestResidual,audit]=shared_cpd_1542_local('fit',X,R,candidates,angles,solverOptions);
end

% Shared-fit protocol and continuous-frequency model interpretation (1542).
function opts=model_defaults_1542_local(opts)
cfg=get_field_default_local(opts,'sharedCPD',struct());
cfg.numRestarts=get_field_default_local(cfg,'numRestarts',opts.numRestarts);
cfg.maxRetryRounds=get_field_default_local(cfg,'maxRetryRounds',3);
validateattributes(cfg.numRestarts,{'numeric'},{'scalar','integer','positive'});
validateattributes(cfg.maxRetryRounds,{'numeric'},{'scalar','integer','nonnegative'});
opts.sharedCPD=cfg;
rule=opts.periodicRule;
rule.modelDecision=model_rule_1542_local(rule);
opts.periodicRule=rule;
end

function cfg=model_rule_1542_local(rule)
cfg=get_field_default_local(rule,'modelDecision',struct());
defaults=struct('maxHarmonicOrder',3,'minBICGain',10, ...
 'minRelativeImprovement',0.25,'minHarmonicFit',0.75,'minToneFit',0.75, ...
 'minSidebandEnergy',0.01,'minSideCoefficientRatio',0.01,'minSideCount',2, ...
 'requireBothSides',true,'refineStarts',2,'maxIter',45, ...
 'centerHalfWidth',0.8,'centerGuard',0.65,'residualFloor',1e-10);
names=fieldnames(defaults);
for j=1:numel(names)
 name=names{j}; cfg.(name)=get_field_default_local(cfg,name,defaults.(name));
end
validateattributes(cfg.maxHarmonicOrder,{'numeric'},{'scalar','integer','positive'});
validateattributes(cfg.refineStarts,{'numeric'},{'scalar','integer','positive'});
validateattributes(cfg.maxIter,{'numeric'},{'scalar','integer','positive'});
for name={'minRelativeImprovement','minHarmonicFit','minToneFit','minSidebandEnergy','minSideCoefficientRatio'}
 validateattributes(cfg.(name{1}),{'numeric'},{'scalar','real','finite','>=',0,'<=',1});
end
validateattributes(cfg.minBICGain,{'numeric'},{'scalar','real','finite','nonnegative'});
validateattributes(cfg.residualFloor,{'numeric'},{'scalar','real','finite','positive','<',1});
end

function varargout=shared_cpd_1542_local(action,varargin)
persistent S
switch action
 case 'reset'
  cfg=varargin{1};
  S=struct('opts',cfg,'entries',{{}},'actor','','fitRanks',[], ...
   'interpretRanks',[],'newComputeSeconds',0,'cacheHits',0,'baseRank',NaN, ...
   'seed',get_field_default_local(cfg,'solverSeed',cfg.seed));
 case 'clear'
  S=[];
 case 'begin'
  if isempty(S), return; end
  S.actor=char(varargin{1}); S.fitRanks=[]; S.interpretRanks=[];
  S.newComputeSeconds=0; S.cacheHits=0;
 case 'fit'
  if isempty(S), error('SharedCPD:Inactive','Initialize a per-trial cache first.'); end
  X=varargin{1}; R=varargin{2}; candidates=varargin{3}; angles=varargin{4}; solver=varargin{5};
  internal=numel(varargin)>5 && varargin{6};
  if isnan(S.baseRank)
   S.baseRank=max(1,size(candidates,1)); S.candidates=candidates;
  end
  if ~internal, S.fitRanks=unique([S.fitRanks R]); end
  if R<=numel(S.entries) && ~isempty(S.entries{R})
   entry=S.entries{R}; S.cacheHits=S.cacheHits+1;
  else
   % A canonical rank chain makes factors independent of which selector asks.
   % Ranks below the CFAR start (oracle diagnostics) are fitted independently.
   previous=[];
   if R>S.baseRank
    [Up,rp]=shared_cpd_1542_local('fit',X,R-1,S.candidates,angles,solver,true);
    if ~isempty(Up) && isfinite(rp), previous=struct('U',{Up},'relres',rp); end
   end
   state=rng; clean=onCleanup(@() rng(state));
   rng(mod(double(S.seed)+104729*R,2^32-1),'twister');
   timer=tic;
   [U,r]=independent_fit_1542_local(X,R,S.candidates,angles,solver,S.opts.sharedCPD.numRestarts);
   [U,r,audit]=direct_monotone_1542_local(X,U,previous,R,S.candidates,angles, ...
    solver,S.opts.sharedCPD.numRestarts,S.opts.sharedCPD.maxRetryRounds);
   seconds=toc(timer);
   entry=struct('U',{U},'residual',r,'audit',audit,'fitSeconds',seconds, ...
    'table',table(),'interpretSeconds',0,'hasInterpretation',false);
   S.entries{R}=entry; S.newComputeSeconds=S.newComputeSeconds+seconds;
   clear clean;
  end
  varargout={entry.U,entry.residual,entry.audit};
 case 'interpretGet'
  U=varargin{1}; hit=false; T=table();
  if ~isempty(S) && ~isempty(U)
   R=size(U{1},2);
   if R<=numel(S.entries) && ~isempty(S.entries{R}) && isequal(U,S.entries{R}.U)
    S.interpretRanks=unique([S.interpretRanks R]);
    hit=S.entries{R}.hasInterpretation;
    if hit, T=S.entries{R}.table; S.cacheHits=S.cacheHits+1; end
   end
  end
  varargout={hit,T};
 case 'interpretPut'
  U=varargin{1}; R=size(U{1},2);
  if ~isempty(S) && R<=numel(S.entries) && ~isempty(S.entries{R}) && isequal(U,S.entries{R}.U)
   S.entries{R}.table=varargin{2}; S.entries{R}.interpretSeconds=varargin{3};
   S.entries{R}.hasInterpretation=true;
   S.interpretRanks=unique([S.interpretRanks R]);
   S.newComputeSeconds=S.newComputeSeconds+varargin{3};
  end
 case 'ledger'
  fitSeconds=0; interpretSeconds=0;
  for R=S.fitRanks, fitSeconds=fitSeconds+S.entries{R}.fitSeconds; end
  for R=S.interpretRanks, interpretSeconds=interpretSeconds+S.entries{R}.interpretSeconds; end
  varargout={struct('actor',string(S.actor),'requestedFitRanks',S.fitRanks, ...
   'interpretedRanks',S.interpretRanks,'fitSeconds',fitSeconds, ...
   'interpretSeconds',interpretSeconds,'nominalSeconds',fitSeconds+interpretSeconds, ...
   'newComputeSeconds',S.newComputeSeconds,'cacheHits',S.cacheHits, ...
   'definition',"Conditional common-fit cost, not standalone timing; predecessor fits can inform monotone repair.")};
 case 'audit'
  ranks=find(~cellfun(@isempty,S.entries)); n=numel(ranks);
  fit=zeros(n,1); interpret=fit; residual=fit; retry=fit; embedded=false(n,1);
  for j=1:n
   e=S.entries{ranks(j)}; fit(j)=e.fitSeconds; interpret(j)=e.interpretSeconds;
   residual(j)=e.residual; retry(j)=e.audit.RetryRounds; embedded(j)=e.audit.UsedEmbeddedFit;
  end
  audit=struct('baseRank',S.baseRank,'seed',S.seed, ...
   'uniqueCPDSeconds',sum(fit),'uniqueInterpretSeconds',sum(interpret), ...
   'fits',table(ranks(:),fit,interpret,residual,retry,embedded, ...
   'VariableNames',{'Rank','FitSeconds','InterpretSeconds','Residual','RetryRounds','Embedded'}));
  varargout={audit};
 otherwise
  error('SharedCPD:Action','Unknown cache action.');
end
end

function [bestU,bestRelres]=independent_fit_1542_local(X,R,candidates,angles,solver,restarts)
bestU=[]; bestRelres=inf;
for j=1:restarts
 try
  initial=timed_init_from_candidates(size(X),R,candidates,angles);
  U=cpd(X,initial,solver); r=stable_cpd_relative_residual_local(X,U);
  if isfinite(r) && r<bestRelres, bestU=U; bestRelres=r; end
 catch err
  if j==restarts && isempty(bestU)
   warning('SharedCPD:FitFailed','Rank %d: %s',R,err.message);
  end
 end
end
end

function [isUAV,score,spacing,matched,width,reason,diagnostic]=model_decision_1542_local(g,rule,forcedCenter)
% Variable projection: optimize continuous frequencies, solve complex LS amplitudes.
if nargin<3, forcedCenter=[]; end
cfg=model_rule_1542_local(rule);
N=numel(g); width=timed_spectral_width_bins(g,rule.widthPowerFraction);
isUAV=false; score=0; spacing=0; matched=0;
reason="model-unstructured: no accepted physical model";
diagnostic=struct('toneError',NaN,'harmonicError',NaN,'BICGain',NaN, ...
 'relativeImprovement',NaN,'sidebandEnergy',NaN,'bodyBin',NaN, ...
 'spacing',NaN,'toneFit',NaN,'harmonicFit',NaN);
if N<16 || any(~isfinite(g)) || norm(g)<eps, return; end
y=ifft(ifftshift(g(:)))*sqrt(N); y=y/norm(y);
w=raw_window_local(N,get_field_default_local(rule,'modelWindow','none'));
[~,peak]=max(abs(g).^2);
if isempty(forcedCenter), center=peak; else, center=forcedCenter; end
center=max(1,min(N,center));
lo=max(1,center-cfg.centerHalfWidth); hi=min(N,center+cfg.centerHalfWidth);
search=optimset('Display','off','MaxIter',cfg.maxIter,'TolX',1e-4,'TolFun',1e-9);
toneObjective=@(f) model_fit_error_1542_local(y,w,f,0,0,N);
f0=fminbnd(toneObjective,lo,hi,search);
[E0,~]=model_fit_error_1542_local(y,w,f0,0,0,N);
orders=(-cfg.maxHarmonicOrder:cfg.maxHarmonicOrder).';
grid=double(rule.frCandidates(:));
assert(~isempty(grid) && all(isfinite(grid)) && all(grid>0),'ModelDecision:Spacing','Positive spacing candidates required.');
spacingLo=min(grid); spacingHi=max(grid);
if spacingLo==spacingHi, spacingHi=spacingLo+0.01; end
coarse=zeros(numel(grid),1);
for j=1:numel(grid), coarse(j)=model_fit_error_1542_local(y,w,f0,grid(j),orders,N); end
[~,order]=sort(coarse);
best=[f0 grid(order(1))]; E1=coarse(order(1));
objective=@(v) model_bounded_error_1542_local(v,y,w,orders,N,[lo hi],[spacingLo spacingHi]);
for j=1:min(cfg.refineStarts,numel(grid))
 start=[f0 grid(order(j))]; refined=fminsearch(objective,start,search);
 e=objective(refined);
 if e<E1, E1=e; best=refined; end
end
[E1,coef]=model_fit_error_1542_local(y,w,best(1),best(2),orders,N);
P=numel(orders); k0=3; k1=2*P+2;
% Approximate model-selection evidence. CPD-factor noise need not be iid;
% this is not a calibrated Bayesian probability or a guaranteed CFAR test.
bicGain=2*N*log(max(E0,cfg.residualFloor)/max(E1,cfg.residualFloor))-(k1-k0)*log(2*N);
improvement=(E0-E1)/max(E0,cfg.residualFloor);
power=abs(coef).^2; body=orders==0; side=~body;
sideEnergy=sum(power(side))/max(sum(power),eps);
supported=side & power>=cfg.minSideCoefficientRatio*max(power(body),eps);
matched=nnz(supported); both=any(supported & orders<0) && any(supported & orders>0);
centerDominant=power(body)>=max(power(side));
centerOK=abs(best(1)-f0)<=cfg.centerGuard;
if ~isempty(forcedCenter), centerOK=centerOK && abs(best(1)-forcedCenter)<=cfg.centerHalfWidth; end
physical=1-E1>=cfg.minHarmonicFit && centerOK && centerDominant;
isUAV=physical && bicGain>=cfg.minBICGain && improvement>=cfg.minRelativeImprovement ...
 && sideEnergy>=cfg.minSidebandEnergy && matched>=cfg.minSideCount ...
 && (~cfg.requireBothSides || both);
score=max(0,min(1,improvement))*max(0,1-E1);
spacing=best(2);
if isUAV
 reason="model-UAV: continuous harmonic evidence";
elseif 1-E0>=cfg.minToneFit
 reason="model-object: single-tone supported";
end
diagnostic=struct('toneError',E0,'harmonicError',E1,'BICGain',bicGain, ...
 'relativeImprovement',improvement,'sidebandEnergy',sideEnergy,'bodyBin',best(1), ...
 'spacing',best(2),'toneFit',1-E0,'harmonicFit',1-E1);
end

function e=model_bounded_error_1542_local(v,y,w,orders,N,centerBounds,spacingBounds)
if numel(v)~=2 || any(~isfinite(v)) || v(1)<centerBounds(1) || v(1)>centerBounds(2) ...
 || v(2)<spacingBounds(1) || v(2)>spacingBounds(2)
 e=1000; return;
end
e=model_fit_error_1542_local(y,w,v(1),v(2),orders,N);
end

function [e,c]=model_fit_error_1542_local(y,w,center,spacing,orders,N)
bins=center+orders(:).'*spacing;
frequencies=bins-1-floor(N/2);
D=w(:).*exp(1j*2*pi*(0:N-1).'*frequencies/N);
c=D\y;
e=max(0,real(sum(abs(y-D*c).^2)));
end

function report=model_selftest_1542_local(opts)
rule=opts.periodicRule; N=opts.ND;
passed=[]; cases=table();
for window={'none','hann'}
 rule.modelWindow=window{1};
 w=raw_window_local(N,window{1});
 for fr=[5 6 7 8]
  for offset=[-0.49 -0.35 0 0.35 0.49]
   center=64+offset; bins=center+[0 -fr fr -2*fr 2*fr -3*fr 3*fr];
   amplitudes=timed_make_bessel_sideband_amps(1,opts.betaMD,3,opts.mdToBody_dB);
   y=zeros(N,1);
   for j=1:numel(bins), y=y+amplitudes(j)*raw_doppler_tone_local(N,bins(j)); end
   g=fftshift(fft(w.*y))/sqrt(N);
   [u,~,~,~,~,reason,d]=model_decision_1542_local(g,rule,[]);
   passed(end+1)=u; %#ok<AGROW>
   cases=[cases;table(string(window{1}),fr,offset,u,d.harmonicFit,d.BICGain, ...
    string(reason),'VariableNames',{'Window','Spacing','Offset','IsUAV','Fit','BICGain','Reason'})]; %#ok<AGROW>
  end
 end
end
assert(all(passed),'ModelSelftest:TrueFactor','A noiseless UAV factor was rejected.');
rngState=rng; clean=onCleanup(@() rng(rngState)); rng(142857);
falseTone=0; falseNoise=0;
for window={'none','hann'}
 rule.modelWindow=window{1}; w=raw_window_local(N,window{1});
 for j=1:20
  tone=w.*raw_doppler_tone_local(N,64+rand-.5);
  noise=w.*(randn(N,1)+1j*randn(N,1));
  falseTone=falseTone+model_decision_1542_local(fftshift(fft(tone)),rule,[]);
  falseNoise=falseNoise+model_decision_1542_local(fftshift(fft(noise)),rule,[]);
 end
end
assert(falseTone==0 && falseNoise==0,'ModelSelftest:FalsePositive','Diagnostic controls failed.');
report=struct('cases',cases,'trueFactorPassRate',mean(passed), ...
 'toneFalsePositives',falseTone,'noiseFalsePositives',falseNoise, ...
 'controlTrialsPerClass',40,'warning',"Small deterministic diagnostic, not independent threshold calibration.");
end
