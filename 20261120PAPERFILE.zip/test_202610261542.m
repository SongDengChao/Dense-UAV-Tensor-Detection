%% test_202610261542.m
% Eight methods from common simulated FMCW I/Q observations.
% All CPD algorithms fit raw, unwindowed fast/slow-time tensors directly.
% No proximity merging of UAV outputs; truth matching remains one-to-one.
% CPD time is reconstructed under a common-fit protocol, not independently measured.
% Stop after one qualifying joint physical/residual condition.
clear; clc; close all;

codeFolder = fileparts(mfilename('fullpath'));
legacyFolder = 'E:\Academic Research\DoctorPeriod\MYPAPER\RANK1-APPROXIMATION-VDM-LOW-SNR-CALCULATING\CodeFile';
if exist(legacyFolder, 'dir'), addpath(legacyFolder); end
if exist(fullfile(legacyFolder, 'tensorlab'), 'dir'), addpath(fullfile(legacyFolder, 'tensorlab')); end
if exist(codeFolder, 'dir'), addpath(codeFolder); end
thisFolder = fileparts(mfilename('fullpath'));
if ~isempty(thisFolder), addpath(thisFolder); end

%% Basic experiment settings.
base.Nu = 6;
base.Nc = 3;
base.Nn = 0;
base.snr = 15;
numMC = 51; % New decision rule: pilot run first; increase to 51/200 after validation.
codeVersion = '202610261542';

opts = struct();
opts.clusterUAVCounts = [1 2 3];
opts.ospa.order = 2;
opts.ospa.cutoff = 3;
opts.successThreshold.angleDeg = 2;
opts.successThreshold.rangeBin = 1.5;
opts.successThreshold.dopplerBin = 2;
opts.verbose = false;
opts.seed = 5211314;
opts.numRestarts = 4;
opts.sharedCPD.enable=true;
opts.sharedCPD.numRestarts=opts.numRestarts;
opts.sharedCPD.maxRetryRounds=3;
opts.doTensor = true;

% Actual amplitudes match the old clustered-scene generator.
opts.spacing.uavAmplitudeRange = [0.55 0.90];
opts.spacing.objectAmplitudeRange = [1.25 2.20];
% Count only observed CFAR peaks, without truth-count fallback.
opts.cfarMaxCandidates = inf;

opts.uavMergeRule.enable = false; % Do not merge nearby classified UAV outputs.
% Legacy values below are inactive for output merging (also used by optional old baselines).
opts.uavMergeRule.angleDeg = 3;
opts.uavMergeRule.rangeBin = 2;
opts.uavMergeRule.dopplerBin = 3;
opts.uavMergeRule.sidebandHarmonics = -3:3;
opts.uavMergeRule.spacingCandidates = [4 5 6 7 8];

% Stop after ONE qualifying joint physical/residual condition.
opts.rankSelectionRule.minDeltaR = 0.005; % 0.5% relative residual improvement.
opts.rankSelectionRule.consecutiveRequired = 1;
% Monotonicity is enforced for every successful rank increase.
opts.rankSelectionRule.retryOnResidualIncrease = true;
opts.rankSelectionRule.maxRetryRounds = 3;
opts.rankSelectionRule.retryRestarts = opts.numRestarts;
opts.rankSelectionRule.hardMaxRank = 48; % Emergency budget, not a target-count prior.

opts.bodyAmp = 1.0;
opts.betaMD = 0.8;
opts.numSidebandOrder = 3;
opts.mdToBody_dB = -8;

% Energy-assisted tensor decision.
opts.energyAssist.enable = false; % No SNR-gated or truth-count rescue.
opts.energyAssist.scoreRelThreshold = 0.35;
opts.energyAssist.maxWeakCandidates = 2;
opts.energyAssist.minWidthBins = 3;
opts.energyAssist.maxWidthBins = 40;
opts.energyAssist.lowSNREnable = false;
opts.energyAssist.lowSNRThresholdDb = -5;
opts.energyAssist.lowSNRMinWidthBins = 4;
opts.energyAssist.lowSNRMaxWidthBins = 120;
opts.energyAssist.lowSNRNoiseWidthBins = 180;
opts.energyAssist.lowSNRScoreRelThreshold = 0.18;
opts.energyAssist.lowSNRMinMatchedPeaks = 2;
opts.energyAssist.lowSNRSoftScoreThreshold = 0.38;
% No true UAV count is passed to the detector's rescue logic.

% Rank selection uses observed data only, with a fixed search cap.
% MinRelErr = 0 scans the entire bounded rank interval (no true-noise input).
% Starting rank = max(1, observed CFAR candidate count).
opts.rankestBaseline.minScanRanks = 3;
opts.rankestBaseline.maxRank = 14;
opts.rankestBaseline.minRelErr = 0;
opts.rankestBaseline.maxRelErr = 1;
opts.rankestBaseline.xMultiplier = 0.1;
opts.rankestBaseline.seedOffset = 910000;
opts.rankestBaseline.numRestarts = opts.numRestarts;
opts.rankestBaseline.maxRetryRounds = opts.rankSelectionRule.maxRetryRounds;

% Independent residual-only early stopping; then select an L-curve corner.
opts.rankestPlateauBaseline.minDeltaR = 0.005;
opts.rankestPlateauBaseline.consecutiveRequired = 2;
opts.rankestPlateauBaseline.hardMaxRank = 48; % Safety budget, not a true-count prior.

% OS noise powers are sums of M exponential channel powers (Gamma shape M).
% Match the existing CA detector's effective noise-only Pfa by default.
opts.osCfar.Pfa = 1e-4;
opts.osCfar.orderFraction = 0.75;
opts.osCfar.matchCAEffectivePfa = false; % Calibrate actual noise-only cell ratios.

% Independent multi-source estimator: no CFAR count or true target count.
% Dual-Gram MDL is an adapted criterion for the structured spectral columns.
opts.jointMusic.maxSources = 32; % Computational cap, not a true-count prior.
opts.jointMusic.angleStepDeg = 0.5;
opts.jointMusic.rangeStepBin = 0.25;
opts.jointMusic.refine = true;
opts.jointMusic.ridge = 1e-6;

% Oracle knows the total generated component count, not UAV class labels.
opts.oracleBaseline.numRestarts = opts.numRestarts;
opts.oracleBaseline.seedOffset = 920000;

% Controlled oracle-assisted ablation, not a practical unknown-count estimator.
% Default rank is the true physical count plus 2: rank 11 for Nu=6,Nc=3.
opts.redundantBaseline.rankOffset = 2;
opts.redundantBaseline.numRestarts = opts.oracleBaseline.numRestarts;
opts.redundantBaseline.seedOffset = opts.oracleBaseline.seedOffset;


% Legacy peak fields below remain for compatibility; modelDecision is active.
% At Dmd=-8 dB and beta=0.8, first sideband power is about 0.076 of the body.
% 0.04 retains that evidence; repeated peak use is forbidden for every method.
opts.periodicRule=struct('frCandidates',1:10,'searchHalfWidth',2,...
    'peakRelThreshold',0.04,'minPeakDistance',2,'minMatchedPeaks',3,...
    'spacingTolerance',1,'matchedEnergyHalfWidth',1,'minPeriodicScore',0.30,'maxPeriodicityError',0.95,...
    'minWidthBins',5,'maxWidthBins',30,'widthPowerFraction',0.90);
opts.periodicRule.modelDecision=struct('maxHarmonicOrder',3, ...
    'minBICGain',10,'minRelativeImprovement',0.25,'minHarmonicFit',0.75, ...
    'minToneFit',0.75,'minSidebandEnergy',0.01,'minSideCoefficientRatio',0.01, ...
    'minSideCount',2,'requireBothSides',true,'refineStarts',2,'maxIter',45, ...
    'centerHalfWidth',0.8,'centerGuard',0.65,'residualFloor',1e-10);
% Engineering defaults, not independently calibrated decision thresholds.
opts.osClean.loopGain=0.8;
opts.osClean.maxIterations=256;
% CLEAN uses the complete windowed FFT point response, not a Gaussian radius.

%% Public radar and processing settings (not target truths).
opts.M=16; opts.NR=96; opts.ND=128;
opts.raw.nFast=2*opts.NR;
opts.raw.carrierHz=24e9;
opts.raw.sampleRateHz=2e6;
opts.raw.chirpSlopeHzPerSec=1e12;
opts.raw.chirpRepetitionSec=100e-6;
opts.raw.tensorWindow='none'; % Mandatory: CPD receives untouched raw I/Q.
opts.raw.cfarRangeWindow='hann'; % 'none', 'hann' or 'hamming'.
opts.raw.cfarDopplerWindow='hann';
opts.raw.calibrationFrames=128;
opts.raw.calibrationValidationFrames=16;
opts.raw.calibrationSeed=24681357;

%% Uniform within-group spacing; columns are [angle degrees, range bin, Doppler bin].
opts.spacing.scale = 1;
% opts.spacing.baseBounds = [3 0.6 3];
opts.spacing.baseBounds = [3 2 3];
opts.spacing.centers = [-30 30 48; 0 48 64; 30 66 80];
opts.offGrid.enable = false; % Already using continuous, strictly bounded offsets.

%% One joint computation, three optional visualization modes.
sweepModeList = {'joint'}; % Only 3D overlay FIGs; slice later from stored data.
snrValues = -30:2.5:25;
spacingValues = round(0.5:0.5:3,10);
sliceSpacing = opts.spacing.scale;
sliceSNR = base.snr;
maxWorkers = 20;
plotVisible = 'off';
surfaceAlpha = 0.32;
surfaceMetricList = {'Pd','Pm','avgFalseAlarmPerMC','precision','F1','angleRMSE','rangeRMSE','dopplerRMSE','meanRankError','rankAccuracy','componentF1','meanUAVCount','meanNoiseCount','meanPhysicalCount','meanTP_UAV','meanFN_UAV','meanFP_clutter_as_UAV','meanFP_ghost','meanTN_clutter','Pfa_UAV','Pd_UAV','OSPA_UAV','OSPA_UAV_loc','OSPA_UAV_card','selectedCPRank','rankSelectionSeconds','runtimeMedianSeconds'};

validateattributes(numMC,{'numeric'},{'scalar','integer','positive'});
validateattributes(maxWorkers,{'numeric'},{'scalar','integer','positive'});
validateattributes(surfaceAlpha,{'numeric'},{'scalar','>',0,'<',1});
if any(diff(snrValues)<=0) || any(diff(spacingValues)<=0) || numel(snrValues)<2 || numel(spacingValues)<2
    error('Both grid axes must contain at least two increasing values.');
end
set(groot,'defaultFigureVisible',plotVisible);
% Calibrate once on the client and broadcast small threshold metadata to workers.
opts=f_newtype_202610261542('prepare',opts);
pool=gcp('nocreate');
if isempty(pool), parpool('Processes',maxWorkers); end
nSpacing=numel(spacingValues); nSNR=numel(snrValues); nPoints=nSpacing*nSNR;
runTag=['version' codeVersion];
versionFolder=fullfile(codeFolder,'Figures',runTag);
figFolder=next_run_folder_local(versionFolder);
fprintf('Joint grid: %d SNR x %d spacing x %d MC = %d paired trials; 8 methods.\n', ...
    nSNR,nSpacing,numMC,nPoints*numMC);
fprintf('At most %d concurrent grid tasks. FIG files and README.txt will be saved.\n',maxWorkers);
gridResults=cell(nPoints,1);
parfor (point=1:nPoints,maxWorkers)
    [iSpacing,iSNR]=ind2sub([nSpacing,nSNR],point);
    pointOpts=opts;
    pointOpts.spacing.scale=spacingValues(iSpacing);
    % Do not add the grid-point index to this seed.
    result=f_newtype_202610261542(base.Nu,base.Nc,base.Nn,snrValues(iSNR),numMC,pointOpts);
    gridResults{point}=compact_grid_point_local(result,base.Nu,base.Nc,numMC, ...
        snrValues(iSNR),spacingValues(iSpacing));
    fprintf('Grid %d/%d finished: SNR=%g dB, s=%g\n',point,nPoints,snrValues(iSNR),spacingValues(iSpacing));
end
methodKeys=gridResults{1}.methodKeys; methodNames=gridResults{1}.methodNames;
metricsGrid=struct();
metricNames=fieldnames(gridResults{1}.metrics.(methodKeys{1}));
metricSummary=table();
for point=1:nPoints
    metricSummary=[metricSummary;gridResults{point}.summaryRows]; %#ok<AGROW>
end
for mm=1:numel(methodKeys)
    key=methodKeys{mm};
    for ff=1:numel(metricNames)
        field=metricNames{ff};
        values=cellfun(@(p) p.metrics.(key).(field),gridResults);
        metricsGrid.(key).(field)=reshape(values,nSpacing,nSNR);
    end
end
gridMeta=struct('codeVersion',codeVersion,'snrValues',snrValues,'spacingValues',spacingValues, ...
    'sliceSNR',sliceSNR,'sliceSpacing',sliceSpacing,'numMC',numMC, ...
    'baseBounds',opts.spacing.baseBounds,'centers',opts.spacing.centers, ...
    'seed',opts.seed,'surfaceAlpha',surfaceAlpha, ...
    'pairingProtocol',"Same normalized positions, amplitudes, harmonics and unit noise per MC across the whole grid", ...
    'snrDefinition',"Mean clean RAW I/Q power / expected raw-sample noise power at each grid node");
gridMeta.outputFolder=figFolder;
gridMeta.rawConfiguration=opts.raw;
gridMeta.cfarCalibration=opts.rawCFARCalibration;
gridMeta.cpdInputDomain='unwindowed raw fast/slow-time I/Q';
gridMeta.outputMergeEnabled=opts.uavMergeRule.enable;
gridMeta.cfarPositionRule='fixed detected peak on separately windowed FFT data; angle estimated at that peak';
gridMeta.periodicRule=opts.periodicRule;
gridMeta.runtimeDefinition="Reconstructed conditional common-fit cost, not independent wall-clock runtime";
gridMeta.sharedCPD=opts.sharedCPD;
gridMeta.classifier="Continuous single-tone versus harmonic variable projection; no spectral-width veto";
gridMeta.osClean=opts.osClean;
gridMeta.matrixConvention='rows=spacingValues, columns=snrValues';
gridMeta.maxWorkers=maxWorkers;
gridMeta.methodKeys=methodKeys;
gridMeta.methodNames=methodNames;
write_run_notes_local(figFolder,gridMeta,methodKeys,methodNames,opts,base,sweepModeList);
folder=fullfile(figFolder,'joint');
if ~exist(folder,'dir'), mkdir(folder); end
plot_joint_results_local(snrValues,spacingValues,metricsGrid,methodKeys,methodNames, ...
    surfaceMetricList,surfaceAlpha,folder,runTag,gridMeta);
append_run_complete_local(figFolder);
save(fullfile(figFolder,'results.mat'),'gridResults','metricsGrid','metricSummary','gridMeta','opts','base','numMC','-v7.3');
fprintf('\nComplete. FIG output and README.txt: %s\n',figFolder);
fprintf('Workspace results: gridResults, metricsGrid, metricSummary, gridMeta. Compact metrics, component diagnostics and shared-fit ledgers saved in results.mat. No raw tensors saved.\n');

%% Local functions.
function metrics = init_all_method_metric_vectors(methodKeys, n)
fields = {'Pd','Pd_UAV','Pm','avgFalseAlarmPerMC','precision','F1','angleRMSE','rangeRMSE','dopplerRMSE', ...
    'truePositive','falseAlarm','missed','meanRankError','rankAccuracy','uavCountAccuracy','uavCountMAE','componentPrecision','componentRecall','componentF1', ...
    'meanUAVCount','meanObjectCount','meanNoiseCount','meanPhysicalCount','meanTotalCandidateCount', ...
    'meanTP_UAV','meanFN_UAV','meanFP_clutter_as_UAV','meanFP_ghost','meanTN_clutter','Pfa_UAV', ...
    'OSPA_UAV','OSPA_UAV_loc','OSPA_UAV_card','selectedCPRank','rankSelectionSeconds','runtimeMedianSeconds','runtimeMeanSeconds'};
for mm = 1:numel(methodKeys)
    key = methodKeys{mm};
    for ff = 1:numel(fields)
        metrics.(key).(fields{ff}) = nan(1,n);
    end
end
end

function v = get_summary_field(s, name, defaultValue)
if isstruct(s) && isfield(s, name) && ~isempty(s.(name))
    v = s.(name);
else
    v = defaultValue;
end
end

function metrics = fill_all_method_metric_vectors(metrics, key, idx, s, ext)
metrics.(key).Pd(idx) = s.Pd;
metrics.(key).Pd_UAV(idx) = get_summary_field(s, 'Pd_UAV', s.Pd);
metrics.(key).Pm(idx) = s.Pm;
metrics.(key).avgFalseAlarmPerMC(idx) = s.avgFalseAlarmPerMC;
metrics.(key).precision(idx) = s.precision;
metrics.(key).F1(idx) = s.F1;
metrics.(key).angleRMSE(idx) = s.angleRMSE;
metrics.(key).rangeRMSE(idx) = s.rangeRMSE;
metrics.(key).dopplerRMSE(idx) = s.dopplerRMSE;
metrics.(key).truePositive(idx) = s.truePositive;
metrics.(key).falseAlarm(idx) = s.falseAlarm;
metrics.(key).missed(idx) = s.missed;
metrics.(key).Pfa_UAV(idx) = get_summary_field(s, 'Pfa_UAV', NaN);
metrics.(key).OSPA_UAV(idx) = get_summary_field(s, 'OSPA_UAV', NaN);
metrics.(key).OSPA_UAV_loc(idx) = get_summary_field(s, 'OSPA_UAV_loc', NaN);
metrics.(key).OSPA_UAV_card(idx) = get_summary_field(s, 'OSPA_UAV_card', NaN);

extFields = fieldnames(ext);
for ii = 1:numel(extFields)
    metrics.(key).(extFields{ii})(idx) = ext.(extFields{ii});
end
end

function ext = summarize_method_cells(methodCells, Nu, Nc, numMC)
rhat = zeros(numMC,1);
precision = nan(numMC,1);
recall = nan(numMC,1);
f1 = nan(numMC,1);
uavCount = zeros(numMC,1);
objectCount = zeros(numMC,1);
noiseCount = zeros(numMC,1);
physicalCount = zeros(numMC,1);
totalCandidateCount = zeros(numMC,1);
TP = zeros(numMC,1); FN = zeros(numMC,1); FPc = zeros(numMC,1); FPg = zeros(numMC,1); TN = zeros(numMC,1);
ospaUAV = nan(numMC,1); ospaLoc = nan(numMC,1); ospaCard = nan(numMC,1);

for mc = 1:numMC
    oneMethod = methodCells{mc};
    allT = table(); uavT = table();
    if isfield(oneMethod, 'allEstimate') && ~isempty(oneMethod.allEstimate), allT = oneMethod.allEstimate; end
    if isfield(oneMethod, 'uavEstimate') && ~isempty(oneMethod.uavEstimate), uavT = oneMethod.uavEstimate; end

    rhat(mc) = height(uavT);
    uavCount(mc) = height(uavT);
    totalCandidateCount(mc) = height(allT);
    noiseCount(mc) = count_too_wide_rows(allT);
    physicalCount(mc) = max(0, height(allT) - noiseCount(mc));
    objectCount(mc) = max(0, physicalCount(mc) - uavCount(mc));

    if isfield(oneMethod, 'metrics')
        precision(mc) = oneMethod.metrics.precision;
        recall(mc) = oneMethod.metrics.recall;
        f1(mc) = oneMethod.metrics.F1;
        ospaUAV(mc) = get_summary_field(oneMethod.metrics, 'OSPA_UAV', NaN);
        ospaLoc(mc) = get_summary_field(oneMethod.metrics, 'OSPA_UAV_loc', NaN);
        ospaCard(mc) = get_summary_field(oneMethod.metrics, 'OSPA_UAV_card', NaN);
    end
    if isfield(oneMethod, 'confusionMetrics')
        TP(mc) = oneMethod.confusionMetrics.TP_UAV;
        FN(mc) = oneMethod.confusionMetrics.FN_UAV;
        FPc(mc) = oneMethod.confusionMetrics.FP_clutter_as_UAV;
        FPg(mc) = oneMethod.confusionMetrics.FP_ghost;
        TN(mc) = oneMethod.confusionMetrics.TN_clutter;
    end
end

ext.meanRankError = mean_ignore_nan(abs(rhat - Nu));
ext.rankAccuracy = mean_ignore_nan(double(rhat == Nu));
ext.uavCountAccuracy = ext.rankAccuracy;
ext.uavCountMAE = mean_ignore_nan(abs(rhat - Nu));
ext.componentPrecision = mean_ignore_nan(precision);
ext.componentRecall = mean_ignore_nan(recall);
ext.componentF1 = mean_ignore_nan(f1);
ext.meanUAVCount = mean_ignore_nan(uavCount);
ext.meanObjectCount = mean_ignore_nan(objectCount);
ext.meanNoiseCount = mean_ignore_nan(noiseCount);
ext.meanPhysicalCount = mean_ignore_nan(physicalCount);
ext.meanTotalCandidateCount = mean_ignore_nan(totalCandidateCount);
ext.meanTP_UAV = mean_ignore_nan(TP);
ext.meanFN_UAV = mean_ignore_nan(FN);
ext.meanFP_clutter_as_UAV = mean_ignore_nan(FPc);
ext.meanFP_ghost = mean_ignore_nan(FPg);
ext.meanTN_clutter = mean_ignore_nan(TN);
ext.Pfa_UAV = sum_ignore_nan(FPc) / max(1, Nc * nnz(isfinite(FPc)));
ext.OSPA_UAV = mean_ignore_nan(ospaUAV);
ext.OSPA_UAV_loc = mean_ignore_nan(ospaLoc);
ext.OSPA_UAV_card = mean_ignore_nan(ospaCard);
end

function n = count_too_wide_rows(T)
if isempty(T) || height(T) == 0 || ~ismember('DecisionReason', T.Properties.VariableNames)
    n = 0;
    return;
end
reason = string(T.DecisionReason);
n = nnz(contains(reason, "too wide before periodic test") | ...
    contains(reason, "zero-weight nonphysical component"));
end

function y = mean_ignore_nan(x)
x = x(isfinite(x));
if isempty(x), y = NaN; else, y = mean(x); end
end

function y = sum_ignore_nan(x)
x = x(isfinite(x));
if isempty(x), y = 0; else, y = sum(x); end
end

function row = summary_to_row(xValue, sweepMode, Nu, Nc, Nn, snrNow, numMC, methodName, s, ext)
row = table(xValue, string(sweepMode), Nu, Nc, Nn, snrNow, numMC, string(methodName), ...
    s.trueTarget, s.estimateCount, s.truePositive, s.falseAlarm, s.missed, s.Pd, get_summary_field(s,'Pd_UAV',s.Pd), s.Pm, s.avgFalseAlarmPerMC, s.precision, s.F1, s.angleRMSE, s.rangeRMSE, s.dopplerRMSE, ...
    ext.meanRankError, ext.rankAccuracy, ext.uavCountMAE, ext.componentF1, ext.meanUAVCount, ext.meanNoiseCount, ext.meanPhysicalCount, ext.meanTP_UAV, ext.meanFN_UAV, ext.meanFP_clutter_as_UAV, ext.meanFP_ghost, ext.meanTN_clutter, ext.Pfa_UAV, ext.OSPA_UAV, ext.OSPA_UAV_loc, ext.OSPA_UAV_card, ...
    'VariableNames', {'XValue','SweepMode','Nu','Nc','Nn','SNR_dB','NumMC','Method','TrueTarget','EstimateCount','TruePositive','FalseAlarm','Missed','Pd','Pd_UAV','Pm','AvgFalseAlarmPerMC','Precision','F1','AngleRMSE','RangeRMSE','DopplerRMSE', ...
    'MeanUAVCountResidual','UAVCountAccuracy','UAVCountMAE','ComponentF1','MeanUAVCount','MeanNoiseCount','MeanPhysicalCount','MeanTP_UAV','MeanFN_UAV','MeanFP_ClutterAsUAV','MeanFP_Ghost','MeanTN_Clutter','Pfa_UAV','OSPA_UAV','OSPA_UAV_loc','OSPA_UAV_card'});
end

function [marker, color] = method_plot_style_local(key)
% CFAR: blue; subspace: orange/red; CPD: purple/magenta.
switch key
    case 'cfar', marker = 'o'; color = [0.05 0.35 0.72];
    case 'osCfar', marker = '>'; color = [0.05 0.65 0.85];
    case 'osCfarClean', marker = 's'; color = [0.05 0.35 0.65];
    case 'cfarClean', marker = '^'; color = [0.25 0.48 0.62];
    case 'cfarSubspace', marker = 's'; color = [0.95 0.52 0.12];
    case 'jointMusic', marker = 'p'; color = [0.75 0.18 0.08];
    case 'proposed', marker = 'd'; color = [0.55 0.08 0.78];
    case 'rankestTensor', marker = 'v'; color = [0.72 0.35 0.78];
    case 'oracleTensor', marker = '*'; color = [0.85 0.15 0.55];
    case 'rankestPlateauTensor', marker = 'h'; color = [0.38 0.26 0.63];
    case 'redundantTensor', marker = 'x'; color = [0.72 0.08 0.40];
    otherwise, error('Unknown method style: %s', key);
end
end

function point=compact_grid_point_local(out,Nu,Nc,numMC,snr,spacing)
keys=out.methodKeys; names=out.methodNames;
point=struct('methodKeys',{keys},'methodNames',{names},'SNRdB',snr,'spacing',spacing);
point.metrics=init_all_method_metric_vectors(keys,1);
point.summaryRows=table(); point.trialMetrics=out.metricPerMC; point.trialRuntimes=out.runtimePerMC;
point.sharedAudit=out.sharedAudit;
point.componentDiagnostics=struct();
point.rankDiagnostics=struct();
for mm=1:numel(keys)
    key=keys{mm}; summary=out.summary.methods.(key); cells=out.methods.(key);
    ext=summarize_method_cells(cells,Nu,Nc,numMC);
    point.metrics=fill_all_method_metric_vectors(point.metrics,key,1,summary,ext);
    ranks=nan(numMC,1); elapsed=nan(numMC,1); diag=cell(numMC,1);
    for mc=1:numMC
        if isfield(cells{mc},'rankInfo')
            info=cells{mc}.rankInfo;
            ranks(mc)=get_summary_field(info,'selectedRank',NaN);
            elapsed(mc)=get_summary_field(info,'elapsedSeconds',NaN);
            diag{mc}=info;
        end
    end
    point.rankDiagnostics.(key)=diag;
    point.componentDiagnostics.(key)=cellfun(@(item) item.allEstimate,cells,'UniformOutput',false);
    point.metrics.(key).selectedCPRank=mean_ignore_nan(ranks);
    point.metrics.(key).rankSelectionSeconds=mean_ignore_nan(elapsed);
    point.metrics.(key).runtimeMedianSeconds=summary.runtimeMedianSeconds;
    point.metrics.(key).runtimeMeanSeconds=summary.runtimeMeanSeconds;
    row=summary_to_row(spacing,'joint',Nu,Nc,0,snr,numMC,names{mm},summary,ext);
    row.SpacingScale=spacing;
    row.SelectedComponentCount=mean_ignore_nan(ranks);
    row.RuntimeMedianSeconds=summary.runtimeMedianSeconds;
    row.RuntimeMeanSeconds=summary.runtimeMeanSeconds;
    point.summaryRows=[point.summaryRows;row]; %#ok<AGROW>
end
% Small numeric pairing audits; no full received/clean tensor is retained.
point.pairingAudit=struct('unitOffsets',zeros(Nu,3,numMC),'positions',zeros(Nu,3,numMC), ...
    'uavAmplitudes',zeros(Nu,numMC),'objectAmplitudes',zeros(Nc,numMC), ...
    'harmonicSpacings',zeros(Nu,numMC),'whiteFirst',complex(zeros(numMC,1)), ...
    'whiteEnergy',zeros(numMC,1),'signalPower',zeros(numMC,1),'noisePower',zeros(numMC,1),...
    'rectSignalPower',zeros(numMC,1),'cfarSignalPower',zeros(numMC,1));
for mc=1:numMC
    sc=out.scene{mc}.definition; noise=out.scene{mc}.noiseAudit;
    point.pairingAudit.unitOffsets(:,:,mc)=sc.normalizedOffsets;
    point.pairingAudit.positions(:,:,mc)=[sc.theta_u_list(:),sc.Ru_list(:),sc.d0_u_list(:)];
    point.pairingAudit.uavAmplitudes(:,mc)=sc.alpha_u_list(:);
    point.pairingAudit.objectAmplitudes(:,mc)=sc.alpha_c_list(:);
    point.pairingAudit.harmonicSpacings(:,mc)=sc.fr_u_list(:);
    point.pairingAudit.whiteFirst(mc)=noise.whiteFirst;
    point.pairingAudit.whiteEnergy(mc)=noise.whiteEnergy;
    point.pairingAudit.signalPower(mc)=noise.signalPower;
    point.pairingAudit.noisePower(mc)=noise.noisePower;
    point.pairingAudit.rectSignalPower(mc)=noise.rectMeanSignalPower;
    point.pairingAudit.cfarSignalPower(mc)=noise.cfarMeanSignalPower;
end
end

function fig=paper_figure_local(sz)
fig=figure('Color','w','Units','centimeters','Position',[2 2 sz], ...
    'PaperUnits','centimeters','PaperSize',sz,'PaperPosition',[0 0 sz]);
end

function plot_joint_results_local(snr,spacing,grid,keys,names,fields,alpha,folder,tag,meta) %#ok<INUSD>
[X,Y]=meshgrid(snr,spacing);
for ff=1:numel(fields)
    field=fields{ff};
    keep=true(size(keys));
    if strcmp(field,'selectedCPRank'), keep=~ismember(keys,{'osCfar','osCfarClean'}); end
    if strcmp(field,'rankSelectionSeconds')
        keep=ismember(keys,{'rankestTensor','rankestPlateauTensor'});
    end
    for mm=1:numel(keys)
        values=grid.(keys{mm}).(field);
        keep(mm)=keep(mm) && any(isfinite(values(:)));
    end
    plotKeys=keys(keep); plotNames=names(keep);
    if isempty(plotKeys)
        warning('Overlay:NoData','No finite data for %s; no FIG was saved.',field);
        continue;
    end
    fig=paper_figure_local([18 12]); ax=axes(fig);
    limits=joint_zlimits_local(grid,plotKeys,field);
    draw_overlay_local(ax,X,Y,grid,plotKeys,plotNames,field,alpha,limits);
    title(ax,joint_label_local(field),'Interpreter','none','FontSize',10);
    figureMeta=meta; figureMeta.metric=field;
    figureMeta.methodKeys=plotKeys; figureMeta.methodNames=plotNames;
    figureMeta.excludedMethodKeys=keys(~keep);
    figureMeta.displayedValues=struct();
    figureMeta.matrixConvention='rows=spacingValues, columns=snrValues';
    figureMeta.zScale=ax.ZScale;
    for mm=1:numel(plotKeys)
        key=plotKeys{mm}; figureMeta.displayedValues.(key)=grid.(key).(field);
    end
    fig.UserData=figureMeta;
    file=[short_metric_stem_local(field) '_overlay.fig'];
    savefig(fig,fullfile(folder,file));
    append_figure_note_local(folder,file,field,'overlay',figureMeta);
    close(fig);
end
end

function draw_overlay_local(ax,X,Y,grid,keys,names,field,alpha,limits)
hold(ax,'on'); handles=gobjects(numel(keys),1);
rows=unique(round(linspace(1,size(X,1),3)));
marks=unique(round(linspace(1,size(X,2),5)));
allKeys={'osCfar','osCfarClean','jointMusic','proposed','rankestTensor','rankestPlateauTensor','oracleTensor','redundantTensor'};
lineStyles={'-','--','--',':','-.','--',':','-.'};
isLog=ismember(field,{'runtimeMedianSeconds','rankSelectionSeconds'});
for mm=1:numel(keys)
    key=keys{mm}; [marker,color]=method_plot_style_local(key);
    identity=find(strcmp(allKeys,key),1); lineStyle=lineStyles{identity};
    Z=grid.(key).(field); Z(~isfinite(Z))=NaN;
    if isLog, Z(Z<=0)=NaN; end % Raw values remain unchanged in UserData.
    h=surf(ax,X,Y,Z,'FaceColor',color,'FaceAlpha',alpha, ...
        'EdgeColor','none','HandleVisibility','off','DisplayName',names{mm},'Tag',key);
    h.UserData=struct('methodKey',key,'metric',field);
    handles(mm)=plot3(ax,NaN,NaN,NaN,'Color',color,'LineStyle',lineStyle, ...
        'Marker',marker,'MarkerSize',4,'LineWidth',1,'DisplayName',names{mm});
    for rr=rows
        plot3(ax,X(rr,:),Y(rr,:),Z(rr,:),'Color',color,'LineStyle',lineStyle, ...
            'LineWidth',0.9,'Marker',marker,'MarkerIndices',marks, ...
            'MarkerSize',3.5,'HandleVisibility','off');
    end
end
ax.XGrid='on'; ax.YGrid='on'; ax.ZGrid='on';
box(ax,'on'); view(ax,-48,27); axis(ax,'tight');
if isLog, ax.ZScale='log'; end
zlim(ax,limits); ax.FontSize=8; ax.GridAlpha=0.15; ax.SortMethod='depth';
xlabel(ax,'SNR (dB)','FontSize',9); ylabel(ax,'Spacing scale s','FontSize',9);
zlabel(ax,joint_label_local(field),'FontSize',9,'Interpreter','none');
legend(ax,handles,names,'Location','southoutside','NumColumns',3,'FontSize',7,'Interpreter','none');
end

function limits=joint_zlimits_local(grid,keys,field)
if ismember(field,{'Pd','Pd_UAV','Pm','F1','componentF1','precision','rankAccuracy','Pfa_UAV'})
    limits=[0 1]; return;
end
if startsWith(field,'OSPA'), limits=[0 3]; return; end
values=[];
for mm=1:numel(keys)
    v=grid.(keys{mm}).(field); values=[values;v(isfinite(v))]; %#ok<AGROW>
end
if ismember(field,{'runtimeMedianSeconds','rankSelectionSeconds'})
    values=values(values>0);
    if isempty(values), limits=[1e-3 1]; return; end
    limits=[min(values)/1.15,max(values)*1.15]; return;
end
if isempty(values), limits=[0 1]; return; end
lo=min(values); hi=max(values); pad=max(0.05*(hi-lo),0.01);
limits=[max(0,lo-pad),hi+pad];
end

function label=joint_label_local(field)
switch field
    case 'Pd', label='Detection probability';
    case 'Pm', label='Miss probability';
    case 'avgFalseAlarmPerMC', label='False alarms / MC';
    case 'precision', label='Precision';
    case 'F1', label='F1 score';
    case 'angleRMSE', label='Angle RMSE (deg)';
    case 'rangeRMSE', label='Range RMSE (bin)';
    case 'dopplerRMSE', label='Doppler RMSE (bin)';
    case 'meanRankError', label='Final UAV count MAE';
    case 'rankAccuracy', label='Final UAV count accuracy';
    case 'componentF1', label='Mean per-trial F1';
    case 'meanUAVCount', label='Estimated UAV count';
    case 'meanNoiseCount', label='Noise-like component count';
    case 'meanPhysicalCount', label='UAV + non-UAV count';
    case 'meanTP_UAV', label='True positives / MC';
    case 'meanFN_UAV', label='Missed UAVs / MC';
    case 'meanFP_clutter_as_UAV', label='Non-UAV classified as UAV / MC';
    case 'meanFP_ghost', label='Ghost detections / MC';
    case 'meanTN_clutter', label='Correctly rejected non-UAVs / MC';
    case 'Pfa_UAV', label='Non-UAV false classification rate';
    case 'Pd_UAV', label='UAV recall';
    case 'OSPA_UAV', label='OSPA';
    case 'OSPA_UAV_loc', label='OSPA localization';
    case 'OSPA_UAV_card', label='OSPA cardinality';
    case 'selectedCPRank', label='Selected component / subspace count';
    case 'rankSelectionSeconds', label='Rank search + classification time (s)';
    case 'runtimeMedianSeconds', label='Median reconstructed processing cost (s)';
    otherwise, label=strrep(field,'_',' ');
end
end

function folder=next_run_folder_local(versionFolder)
if ~isfolder(versionFolder)
    [ok,msg]=mkdir(versionFolder);
    if ~ok, error('OutputFolder:Create','%s',msg); end
end
run=1;
while true
    folder=fullfile(versionFolder,sprintf('run%02d',run));
    if ~exist(folder,'file'), break; end
    run=run+1;
end
[ok,msg]=mkdir(folder);
if ~ok, error('OutputFolder:Create','%s',msg); end
end

function stem=short_metric_stem_local(metric)
switch metric
    case 'Pd', stem='Pd';
    case 'Pm', stem='Pm';
    case 'avgFalseAlarmPerMC', stem='FA';
    case 'precision', stem='Precision';
    case 'F1', stem='F1';
    case 'angleRMSE', stem='RMSE_angle';
    case 'rangeRMSE', stem='RMSE_range';
    case 'dopplerRMSE', stem='RMSE_Doppler';
    case 'meanRankError', stem='UAV_count_MAE';
    case 'rankAccuracy', stem='UAV_count_acc';
    case 'componentF1', stem='Component_F1';
    case 'meanUAVCount', stem='UAV_count';
    case 'meanNoiseCount', stem='Noise_count';
    case 'meanPhysicalCount', stem='Physical_count';
    case 'meanTP_UAV', stem='TP';
    case 'meanFN_UAV', stem='FN';
    case 'meanFP_clutter_as_UAV', stem='FP_nonUAV';
    case 'meanFP_ghost', stem='FP_ghost';
    case 'meanTN_clutter', stem='TN';
    case 'Pfa_UAV', stem='Pfa_UAV';
    case 'Pd_UAV', stem='Pd_UAV';
    case 'OSPA_UAV', stem='OSPA';
    case 'OSPA_UAV_loc', stem='OSPA_loc';
    case 'OSPA_UAV_card', stem='OSPA_card';
    case 'selectedCPRank', stem='Selected_rank';
    case 'rankSelectionSeconds', stem='Rankest_time';
    case 'runtimeMedianSeconds', stem='Runtime_median';
    otherwise, stem=regexprep(char(metric),'[^A-Za-z0-9_]','_');
end
end

function meaning=metric_meaning_local(metric)
switch metric
    case 'Pd', meaning='UAV detection probability (recall); higher is better.';
    case 'Pm', meaning='Missed-UAV probability; lower is better.';
    case 'avgFalseAlarmPerMC', meaning='Average number of false UAV outputs per MC trial; lower is better.';
    case 'precision', meaning='Fraction of reported UAV detections that match true UAVs; higher is better.';
    case 'F1', meaning='Harmonic mean of precision and recall; higher is better.';
    case 'angleRMSE', meaning='Angle RMSE in degrees for correctly matched UAV detections; lower is better.';
    case 'rangeRMSE', meaning='Range RMSE in bins for correctly matched UAV detections; lower is better.';
    case 'dopplerRMSE', meaning='Doppler RMSE in bins for correctly matched UAV detections; lower is better.';
    case 'meanRankError', meaning='Mean absolute FINAL UAV-count error, not CP-rank error; lower is better.';
    case 'rankAccuracy', meaning='Probability that the FINAL UAV count equals the true UAV count; higher is better.';
    case 'componentF1', meaning='Mean per-trial detection F1 from method outputs; higher is better.';
    case 'meanUAVCount', meaning='Mean final UAV count without proximity merging; compare with the true UAV count.';
    case 'meanNoiseCount', meaning='Mean number of rejected too-wide or zero-weight nonphysical components.';
    case 'meanPhysicalCount', meaning='Mean estimated UAV plus non-UAV physical-component count.';
    case 'meanTP_UAV', meaning='Mean true-positive UAV count per MC trial; higher is better.';
    case 'meanFN_UAV', meaning='Mean missed-UAV count per MC trial; lower is better.';
    case 'meanFP_clutter_as_UAV', meaning='Mean number of non-UAV targets classified as UAVs per MC trial; lower is better.';
    case 'meanFP_ghost', meaning='Mean false UAV count not associated with a true UAV or non-UAV target; lower is better.';
    case 'meanTN_clutter', meaning='Mean correctly rejected non-UAV-target count per MC trial.';
    case 'Pfa_UAV', meaning='Non-UAV-to-UAV false classification rate; NOT nominal CFAR reference-window Pfa.';
    case 'Pd_UAV', meaning='UAV recall under one-to-one truth matching; higher is better.';
    case 'OSPA_UAV', meaning='Total normalized OSPA set error, including localization and cardinality; lower is better.';
    case 'OSPA_UAV_loc', meaning='OSPA localization contribution, including cutoff distances; lower is better.';
    case 'OSPA_UAV_card', meaning='OSPA cardinality contribution due to output-set size mismatch; lower is better.';
    case 'selectedCPRank', meaning='Mean selected decomposition rank or MUSIC subspace order; NOT final UAV count.';
    case 'rankSelectionSeconds', meaning='Mean rank-search plus classification stage time in seconds; rankest methods only.';
    case 'runtimeMedianSeconds', meaning='Median reconstructed common-fit cost, not independent runtime. See results.mat.';
    case 'Pd and OSPA', meaning='Double-column pair: panel (a) UAV detection probability; panel (b) total OSPA.';
    otherwise, meaning=['Metric field: ' char(metric) '.'];
end
end

function write_run_notes_local(folder,meta,keys,names,opts,base,modes)
[fid,msg]=fopen(fullfile(folder,'README.txt'),'w','n','UTF-8');
if fid<0, error('FigureNotes:Open','%s',msg); end
cleanup=onCleanup(@() fclose(fid)); %#ok<NASGU>
fprintf(fid,'FIGURE GUIDE AND RUN CONFIGURATION\n');
fprintf(fid,'Code version: %s\nCreated: %s\n',meta.codeVersion,char(datetime('now','Format','yyyy-MM-dd HH:mm:ss')));
fprintf(fid,'MATLAB: %s\nPlatform: %s\n',version,computer);
fprintf(fid,'Status: grid computation complete; figure generation in progress.\n');
fprintf(fid,'Output folder: %s\nModes: %s\n',folder,strjoin(modes,', '));
fprintf(fid,'MC trials per grid node: %d\nMaximum concurrent grid tasks: %d\n',meta.numMC,meta.maxWorkers);
fprintf(fid,'SNR nodes (dB): %s\nSpacing nodes s: %s\n',mat2str(meta.snrValues),mat2str(meta.spacingValues));

fprintf(fid,'Targets: %d UAVs, %d non-UAVs. UAVs per group: %s\n',base.Nu,base.Nc,mat2str(opts.clusterUAVCounts));
fprintf(fid,'Centers, one [angle_deg range_bin Doppler_bin] row per group:\n');
fprintf(fid,'  %g %g %g\n',meta.centers.');
fprintf(fid,'Uniform offset limits: |dtheta| <= %g*s deg, |dR| <= %g*s bin, |dD| <= %g*s bin.\n',meta.baseBounds);
fprintf(fid,'Larger s means more separated targets; s is not density itself.\n');
fprintf(fid,'UAV amplitude range: %s. Non-UAV amplitude range: %s.\n', ...
    mat2str(opts.spacing.uavAmplitudeRange),mat2str(opts.spacing.objectAmplitudeRange));
fprintf(fid,'Default micro-Doppler/body ratio: %g dB. Seed: %s.\n',opts.mdToBody_dB,mat2str(meta.seed));
fprintf(fid,'SNR definition: %s\nPairing: %s\n',meta.snrDefinition,meta.pairingProtocol);
fprintf(fid,'Detection tolerances: angle %g deg, range %g bins, Doppler %g bins (implementation uses strict inequalities).\n', ...
    opts.successThreshold.angleDeg,opts.successThreshold.rangeBin,opts.successThreshold.dopplerBin);
fprintf(fid,'CPD input: RAW, unwindowed [array x fast time x slow time] = [%d %d %d].\n',opts.M,opts.raw.nFast,opts.ND);
fprintf(fid,'Only fitted factor vectors are FFT-analyzed AFTER CPD; fast-time frequency gives range.\n');
fprintf(fid,'CPD range uses a local raw-tone matched-frequency grid at 0.02-bin spacing; Doppler uses the 1D slow-factor FFT.\n');
fprintf(fid,'Processed CFAR/MUSIC size: [%d %d %d]. CFAR windows: %s / %s; MUSIC: rectangular.\n',...
    opts.M,opts.NR,opts.ND,opts.raw.cfarRangeWindow,opts.raw.cfarDopplerWindow);
fprintf(fid,'fc=%g Hz; Fs=%g Hz; slope=%g Hz/s; Tr=%g s; range bin=%g m; Doppler bin=%g Hz.\n',...
    opts.raw.carrierHz,opts.raw.sampleRateHz,opts.raw.chirpSlopeHzPerSec,...
    opts.raw.chirpRepetitionSec,opts.raw.rangeBinMeters,opts.raw.dopplerBinHz);
fprintf(fid,'Raw noise is added before any branch processing. Windows have unit RMS; FFTs are unitary.\n');
fprintf(fid,'One-time noise calibration: %d frames, %d CUT samples; elapsed %.3f s (separate from method runtimes).\n',...
    opts.rawCFARCalibration.frames,opts.rawCFARCalibration.sampleCount,opts.rawCFARCalibration.elapsedSeconds);
fprintf(fid,'Target cell Pfa=%g before local-peak selection; CA scale=%g; OS scale=%g.\n',...
    opts.rawCFARCalibration.targetPfa,opts.rawCFARCalibration.caScale,opts.rawCFARCalibration.osScale);
fprintf(fid,'Independent noise validation: CA=%g, OS=%g (cell rates before local-peak selection).\n',...
    opts.rawCFARCalibration.validationCA,opts.rawCFARCalibration.validationOS);
fprintf(fid,'Energy-assisted rescue disabled; no true UAV-count rescue cap. Only explicitly oracle-labeled baselines use true total count.\n');
fprintf(fid,'Assumptions: dechirped narrowband stop-and-hop model; negligible migration/intra-chirp Doppler; simplified harmonic rotor response.\n');
fprintf(fid,'Gaussian spectral synthesis is NOT used. Raw-input SNR must not be equated to old processed-tensor SNR.\n');
fprintf(fid,'CFAR initialization may count sidebands as separate candidates; rank growth does not correct an initially excessive rank by downward search.\n');
fprintf(fid,'Output proximity merging enabled: %d (0 = disabled). No output merge tolerances are applied.\n',opts.uavMergeRule.enable);
fprintf(fid,'One-to-one matching to ground truth remains enabled for performance evaluation.\n');
fprintf(fid,'CFAR positions: detected R/D are fixed; angle is estimated at that peak. No classification-driven relocation.\n');
fprintf(fid,'Decision: continuous single-tone versus harmonic variable-projection models; no width veto.\n');
fprintf(fid,'Window-matched templates: CPD/MUSIC rectangular; CFAR uses its actual Doppler window.\n');
fprintf(fid,'Model defaults (not independently calibrated): %s\n',jsonencode(opts.periodicRule.modelDecision));
fprintf(fid,'Timing is reconstructed common-fit protocol cost, NOT independently measured per-method runtime.\n');
fprintf(fid,'ActualIncrementalSeconds depends on cache order. Shared audits report unique fits and real solver costs.\n');
fprintf(fid,'A canonical CFAR-started monotone fit chain is reused; oracle/redundant fits can benefit from that chain.\n');
fprintf(fid,'Thus reconstructed costs are conditional on available predecessor fits; run independent benchmarks for a paper.\n');
fprintf(fid,'OS-CFAR-CLEAN subtracts the actual windowed FFT point response in the power map; gain=%g, cap=%d.\n',...
    opts.osClean.loopGain,opts.osClean.maxIterations);
fprintf(fid,'CLEAN uses the same OS threshold calibration; classification reads original data, not the subtracted map.\n');
fprintf(fid,'Residual subtraction changes noise statistics; equal nominal calibration does not guarantee equal achieved false-alarm rates.\n');
fprintf(fid,'CLEAN subtraction is approximate; it does not associate body/sideband peaks or merge UAV outputs.\n');
fprintf(fid,'CPD restarts: %d. Proposed rank cap: %d. Residual-gain threshold: %g. Joint confirmations: %d.\n', ...
    opts.numRestarts,opts.rankSelectionRule.hardMaxRank,opts.rankSelectionRule.minDeltaR,opts.rankSelectionRule.consecutiveRequired);
fprintf(fid,'Rankest cap: %d. Plateau gain threshold: %g; confirmations: %d; safety cap: %d.\n', ...
    opts.rankestBaseline.maxRank,opts.rankestPlateauBaseline.minDeltaR, ...
    opts.rankestPlateauBaseline.consecutiveRequired,opts.rankestPlateauBaseline.hardMaxRank);
fprintf(fid,'Redundant-rank CPD uses true total count + %d (controlled oracle-assisted comparison).\n',opts.redundantBaseline.rankOffset);
fprintf(fid,'Overlay surface opacity: %g (0 transparent, 1 opaque).\n',meta.surfaceAlpha);
fprintf(fid,'Methods and fixed styles (RGB components are in [0,1]):\n');
for jj=1:numel(keys)
    [marker,color]=method_plot_style_local(keys{jj});
    fprintf(fid,'  %s | key=%s | marker=%s | RGB=%s\n',names{jj},keys{jj},marker,mat2str(color,4));
end
fprintf(fid,'\nDIRECTORY CONVENTIONS\n');
fprintf(fid,'  joint: one 3D overlay FIG per metric; x=SNR, y=s, z=metric.\n');
fprintf(fid,'  No 2D slices, facets, heatmaps or combined-panel FIGs are generated.\n');
fprintf(fid,'  Matrix convention: rows=spacingValues, columns=snrValues.\n');
fprintf(fid,'  Future slices at actual grid nodes are exact; other values require explicit interpolation.\n');
fprintf(fid,'\nFIG DATA AND LIMITATIONS\n');
fprintf(fid,'  Individual joint FIGs retain grid axes, method keys and displayed metric matrices in UserData.\n');
fprintf(fid,'  Surfaces have method-key Tags and UserData, plus XData/YData/ZData.\n');
fprintf(fid,'  Other metrics and individual MC trials cannot be reconstructed from a Pd-only or OSPA-only FIG.\n');
fprintf(fid,'  Compact numerical results are saved in results.mat; raw tensors and CPD factors are not retained.\n');
fprintf(fid,'  No checkpoint/resume data are saved. This output change does not add checkpointing.\n');
fprintf(fid,'\nSAVED FIGURE CATALOG\n');
end

function append_figure_note_local(folder,file,metric,kind,meta)
root=fileparts(folder); [~,subfolder]=fileparts(folder);
[fid,msg]=fopen(fullfile(root,'README.txt'),'a','n','UTF-8');
if fid<0, error('FigureNotes:Open','%s',msg); end
cleanup=onCleanup(@() fclose(fid)); %#ok<NASGU>
fprintf(fid,'\n[%s]\n  %s\n',fullfile(subfolder,file),metric_meaning_local(metric));
switch kind
    case 'snr'
        fprintf(fid,'  2D slice: x=SNR (dB); fixed s=%g; exact grid row %d.\n',meta.sliceSpacing,meta.sliceGridIndex);
    case 'spacing'
        fprintf(fid,'  2D slice: x=spacing scale s; fixed SNR=%g dB; exact grid column %d.\n',meta.sliceSNR,meta.sliceGridIndex);
    case 'overlay'
        fprintf(fid,'  %d overlaid method surfaces, opacity=%g; distinct colors, lines and markers.\n',numel(meta.methodKeys),meta.surfaceAlpha);
        fprintf(fid,'  Included algorithms: %s. Z-axis scale: %s.\n',strjoin(meta.methodNames,', '),meta.zScale);
    case 'facets'
        fprintf(fid,'  One 3D panel per method, with common coordinate and color limits.\n');
    case 'heatmap'
        fprintf(fid,'  One heatmap per method; x=SNR, y=s, common color limits encode the metric.\n');
    case 'double-column'
        fprintf(fid,'  Double-column layout: Pd and OSPA overlaid method surfaces; shared legend.\n');
end
if strcmp(metric,'runtimeMedianSeconds'), fprintf(fid,'  The height (z) time axis is logarithmic; original seconds are retained.\n'); end
if strcmp(metric,'selectedCPRank'), fprintf(fid,'  OS-CFAR and OS-CFAR-CLEAN are omitted because they do not select a CP rank or subspace order.\n'); end
end

function append_run_complete_local(folder)
files=dir(fullfile(folder,'**','*.fig'));
[fid,msg]=fopen(fullfile(folder,'README.txt'),'a','n','UTF-8');
if fid<0, error('FigureNotes:Open','%s',msg); end
cleanup=onCleanup(@() fclose(fid)); %#ok<NASGU>
fprintf(fid,'\nRUN COMPLETE\nSaved FIG files: %d\nFinished: %s\n', ...
    numel(files),char(datetime('now','Format','yyyy-MM-dd HH:mm:ss')));
end






